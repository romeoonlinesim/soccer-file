
#include <setplay/functions.h>

FuncSin funcSin;
FuncCos funcCos;
FuncSqrt funcSqrt;

