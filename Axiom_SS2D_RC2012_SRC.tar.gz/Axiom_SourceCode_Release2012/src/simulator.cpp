/**
 * This file is reached from PossibilityModel.cpp of WrightEagleBASE
 */

/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "simulator.h"
#include <rcsc/common/server_param.h>
#include <rcsc/player/player_object.h>
#include "axiom_pass.h"

PossibilityModel::PossibilityModel()
{
//     Assert(Parser::IsPlayerTypesReady()); // ÊÕµœÒì¹¹ÐÅÏ¢ºó²ÅÄÜ³õÊŒ»¯

    mCycleDifferFix.SetOutMinMax(1.0, 2.6);
    mCycleDifferFix.Interpolate(3.6, 2.6, 18.0, 1.6, 36.0, 1.0);
    mPassOutsideFix.SetOutMinMax(0.8, 1.0);
    mPassOutsideFix.Interpolate(0.0, 0.8, 4.0, 0.98, 6.0, 1.0);
    mKickMaxRandFix.SetOutMinMax(0.7, 1.01);//max_randµÄ·¶Î§ÊÇ0µœ0.4
    mKickMaxRandFix.Interpolate(0.0, 1.01, 0.06, 1.0, 0.4, 0.7);
    mPassKickSpeedFix.SetOutMinMax(0.0, 3.0);//¶Ô0µœ15Ã×µÄŽ«ÇòµÄ³öÇòËÙ¶ÈœøÐÐÏÞÖÆ
    mPassKickSpeedFix.Interpolate(0.0, 0.0, 5.0, 2.0, 15.0, 3.0);
    mPassLowStaminaFix.SetOutMinMax(0.0, 10.0);
    mPassLowStaminaFix.Interpolate(2000.0, 0.0, 3000.0, 3.0, 4000.0, 10.0);
    mDirectPassPoss.SetOutMinMax(0.0, 1.0);
    mDirectPassPoss.Interpolate(8.0, 1.0, 16.0, 0.8, 36.0, 0.0);

    mKickablePoss.SetOutMinMax(0.0, 1.0);
    mKickablePoss.Interpolate(0.0, 0.5, 0.5, 0.26, 1.0, 0.0);
    mDribbleAngleDecay.SetOutMinMax(0.86, 1.0);
    mDribbleAngleDecay.Interpolate(90.0, 0.76, 45.0, 0.9, 0.0, 1.0);
    mFastDribblePossDecay.SetOutMinMax(0.8, 1.0);
    mFastDribblePossDecay.Interpolate(0.0, 1.0, 20.0, 0.96, 36.0, 0.86);
    mFastDribbleLastPoint.SetOutMinMax(0.0, 1.0);
    mFastDribbleLastPoint.Interpolate(5.0, 1.0, 16.0, 0.5, 36.0, 0.0);
    mFastDribbleBreakPoss.SetOutMinMax(0.0, 3.0);
    mFastDribbleBreakPoss.Interpolate(60.0, 0.1, 90.0, 1.0, 180.0, 3.0);
    mTurnDribbleAvoidRate.SetOutMinMax(0.0, 1.0);
    mTurnDribbleAvoidRate.Interpolate(2.6, 1.0, 20.0, 0.5, 60.0, 0.0);

    mOutOfPitchRate.SetOutMinMax(0.0, 1.0);
    mOutOfPitchRate.Interpolate(-1.0, 1.0, 0.0, 0.5, 2.0, 0.0);
//     mOutOfPitchRate.Show("mOutOfPitchRate", -1.0, 2.0);

    for (int i = 0; i < rcsc::PlayerTypeSet::i().playerTypeMap().size() ; ++i)
    {
        const double & speed_max =  rcsc::PlayerTypeSet::i().playerTypeMap().at(i).realSpeedMax();

        mTeammateInfluence[i].SetOutMinMax(0.0, 1.0);
        mTeammateInfluence[i].Interpolate(0.0, 1.0, 8.0 * speed_max, 0.28, 16.0 * speed_max, 0.1);
        mOpponentInfluence[i].SetOutMinMax(-1.0, 0.0);
        mOpponentInfluence[i].Interpolate(0.0, -1.0, 8.0 * speed_max, -0.28, 16.0 * speed_max, -0.1);
    }
}





PossibilityModel::~PossibilityModel() {
}

PossibilityModel & PossibilityModel::instance()
{
        static PossibilityModel possibility_model;
        return possibility_model;
}

/**
 * Caculate the possibility from intercept cycles.
 * This function is for dribble or pass.
 * @param dist the distance for ball to move.
 * @param cycle_diff the difference of cycles needed
 * 	for ball to the target and the player to the target.
 * @param cycle_delay the cycle delay for player.
 * @param save_rate the rate to fix the cycle_delay, which
 * 	shows the decrease rate of possibility for increase
 * 	of cycle_delay.
 * @return the possibility.
 */
double PossibilityModel::Cycle2Possibility(double dist, double cycle_diff, int cycle_delay, double safe_rate)
{
        double k	=  mCycleDifferFix.GetOutput(dist);
        cycle_diff  *= k;
        cycle_delay = (int)std::ceil(cycle_delay * k);

        double poss     = 0.0;
        double rate     = 0.0;
        double cycle    = 0.0;
        for (int i = -cycle_delay; i <= cycle_delay; ++i)
        {
                cycle = cycle_diff + i;
                rate = (i < 0) ? safe_rate : 1.0;

                if (cycle < -5)
                {
                        poss += (0.04 - (1.0 + 1.0 / (cycle + 4.0)) * 0.04) * rate;
                }
                else if (cycle <= 5)
                {
                        poss += ((0.16 * cycle - 0.0024 * cycle * cycle * cycle) * 0.92 + 0.5) * rate;
                }
                else
                {
                        poss += (0.96 + (1.0 - 1.0 / (cycle - 4.0)) * 0.04) * rate;
                }
        }
        poss /= (cycle_delay * safe_rate + cycle_delay + 1);
        return poss;
}

/**
 * Caculate the possibility for player to run to the target position
 * to kick the ball in a certain number of cycles.
 * @param p the player to caculate.
 * @param target the target position.
 * @param cycle the cycles to caculate.
 * @param distance the ball distance at the final cycle.
 * @param saferete.
 * @retrun the possibility.
 */
double PossibilityModel::CalcPlayerGoToPointPoss(const rcsc::PlayerObject * obj , rcsc::Vector2D target, double cycle, double distance, double saferate)
{
    double player_cycle =  obj->playerTypePtr()->cyclesToReachDistance(obj->pos().dist(target)); //Dasher::instance().CalcPlayerGoToPointCycle(p, target);

        if ( obj->unum() > 0){
                return Cycle2Possibility(distance, cycle - player_cycle, obj->posCount() , saferate);
        }
        else{
                int cd = obj->posCount();
                if (cd > 2) saferate *= 1.5;
                return Cycle2Possibility(distance, cycle - player_cycle, cd, 1.0/saferate);
        }
}

/**
 * Caculate the direct pass success rate.
 * @param ballpt the ball position.
 * @param tmpt the teammate position.
 * @param oppt the opponent position.
 * @param cyclefix.
 * @return the success rate.
 */
double PossibilityModel::CalcDirectPassSuccessRate(const rcsc::Vector2D & ballpt, const rcsc::Vector2D & tmpt, const rcsc::Vector2D & oppt, double cyclefix)
{
        const double MAXDIS = (rcsc::ServerParam::instance().ballSpeedMax() - 0.3) / (1 - rcsc::ServerParam::instance().ballDecay());
        rcsc::Vector2D rel_tm = tmpt - ballpt;
        rcsc::Vector2D rel_op = oppt - ballpt;
        double l[2], dis[2];
        double ang =  fabs( rcsc::AngleDeg::normalize_angle ( rel_op.th().degree() - rel_tm.th().degree() ));
        l[0] = rel_op.r() * std::cos(ang);
        l[1] = rel_tm.r();
        if (l[0] >= MAXDIS || l[1] >= MAXDIS)
    {
                return 0.0;
    }

    dis[0] = rel_op.r() * std::sin(ang);
        dis[1] = tmpt.dist(oppt);
        int i;
        double c1, c2;
        double poss = 0.0;
        for (i = 0; i < 2; i++)
        {
                c1 = log(1.0 - l[i] / MAXDIS) / log(rcsc::ServerParam::instance().ballDecay());
                c2 = dis[i] + 1.5 - cyclefix;
                poss = std::max(poss, Cycle2Possibility(15, c1 - c2));
        }
        return 1.0 - poss;
}

// /**
//  * Caculate the direct pass success rate.
//  * @param prob PossibilityModelStruct input
//  * @param end_cycle finish time
//  * @param end_point predicted time
//  * @return reach cycle.
//  */
// void
// PossibilityModel::CalculatePossibilityModel( PossibilityModelStruct prob,  int &end_cycle, rcsc::Vector2D end_point)
// {
//
//    if (prob.player_no == 0)
//     {
// 	end_cycle = 1000;
// 	return;
//     }
//     float vx = prob.vel.x;
//     float vy = prob.vel.y;
//     float x = prob.pos.x;
//     float y = prob.pos.y;
//     int time = 0;
//     float rad = 1;
//     bool found = false;
//     while (!found)
//     {
// 	time++;
// 	x += vx;
// 	y += vy;
// 	vx *= rcsc::ServerParam::i().ballDecay();
// 	vy *= rcsc::ServerParam::i().ballDecay();
// 	if (time > 2)
// 	{
// 	    if (time == 3)
// 		rad += .6;
// 	    else if (time == 4)
// 		rad += .84;
// 	    else if (time == 5)
// 		rad += .96;
// 	    else
// 		rad += 1;
//
// 	}
// 	for (int i = 0; i < prob.player_no ; i++)
// 	{
// 	    float dist = hypot( prob.objs[i].y - x,
// 				prob.objs[i].y - y);
// 	    if (dist <= rad)
// 		found = true;
// 	}
//     }
//     end_cycle = time;
//     end_point.assign(x,y);
// }
//
