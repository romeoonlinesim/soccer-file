#ifndef BLOCK_H
#define BLOCK_H

#include <rcsc/geom/vector_2d.h>
#include <rcsc/player/soccer_action.h>
#include <rcsc/player/player_agent.h>

/**
 * bhv_block.h
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Authors :  Mohammad Mahdavi, Mostafa Zamani, Hossein Rahmatizade
 * Copyright 2012
 * Allright Reserved
 */

class axiom_block    : public rcsc::SoccerBehavior
{

  private:
        const rcsc::Vector2D M_home_pos;

        bool amIBlocker( rcsc::PlayerAgent * agent );
        bool getBack ( rcsc::PlayerAgent * agent );
        bool ifOppHasBall ( rcsc::PlayerAgent * agent );
        int area ( const rcsc::Vector2D );
        bool ourTeamOwnerBall ( rcsc::PlayerAgent * agent );

public:

    axiom_block( const rcsc::Vector2D & home_pos )
        : M_home_pos( home_pos )
      { }

    bool execute( rcsc::PlayerAgent * agent );
    bool doSideInterceptBall( rcsc::PlayerAgent * agent );
    bool doBlockMove2( rcsc::PlayerAgent * agent );

    bool doBlockMove( rcsc::PlayerAgent * agent );

    rcsc::Vector2D getBlockPoint( rcsc::PlayerAgent * agent );

    double getBlockDashPower( const rcsc::PlayerAgent * agent,
                         const rcsc::Vector2D & blockPos );
    bool doSideBlock( rcsc::PlayerAgent * agent );
    bool getBlockSubPoint( rcsc::Vector2D opttarget, rcsc::Vector2D opponent_pos, rcsc::Vector2D selfpos,
                                                          float ratio_speed,float predis, rcsc::Vector2D *blockpos );
    bool  getBlockPoint( rcsc::Vector2D posOpp,rcsc::Vector2D posAgent,float cycles,
                                                    float my_block_speed,float their_block_speed, rcsc::Vector2D *blockpos );
    bool
    getBlockPosition( rcsc::PlayerAgent * agent,const rcsc::PlayerObject * opp, rcsc::Vector2D *blockpos );
    const char* cout;

};
#endif
