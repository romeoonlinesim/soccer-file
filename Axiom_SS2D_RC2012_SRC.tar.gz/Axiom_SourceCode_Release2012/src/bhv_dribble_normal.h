/**
 * DribbleNormal class
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Authors :  Mohammad GHazanfari
 * Copyright 2011
 * Allright Reserved
 */

#ifndef DRIBBLE_NORMAL_H
#define DRIBBLE_NORMAL_H

#include <rcsc/geom/vector_2d.h>
#include <rcsc/player/soccer_action.h>
#include <rcsc/player/player_agent.h>
#include <rcsc/geom.h>


  class BhvDribble
  {
  public:
        BhvDribble ( ) { }

  bool execute( rcsc::PlayerAgent * agent );
  rcsc::Vector2D  pointExecuter( rcsc::PlayerAgent * agent );
  rcsc::Vector2D findBestVec( rcsc::PlayerAgent * agent );
  bool can_kick_after_dash( rcsc::PlayerAgent* agent , double & p );
  bool do_turn_without_ball( rcsc::PlayerAgent* agent , const rcsc::AngleDeg ang );
  bool kick_ball_avoid( rcsc::PlayerAgent * agent );
  rcsc::AngleDeg  find_avoid_angle( rcsc::PlayerAgent * agent );
  rcsc::Vector2D getTarget( rcsc::PlayerAgent * agent );
  rcsc::Vector2D get_avoid_point( rcsc::PlayerAgent * agent,double polar_dist );
  bool dribble_fast( rcsc::PlayerAgent* agent );
  bool doRelaxDribble( rcsc::PlayerAgent * agent);
  rcsc::Vector2D getFastTarget( rcsc::PlayerAgent * agent );

  private:

  };
#endif
