/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef POSSIBILITYMODEL_H_
#define POSSIBILITYMODEL_H_

#include "geometry.h"
#include <rcsc/geom/vector_2d.h>
#include <rcsc/player/player_object.h>
#include <rcsc/player/player_agent.h>
#define MAX_PLAYER_TYPES 18

struct
PossibilityModelStruct
{
    int player_no;
    rcsc::Vector2D pos;
    rcsc::Vector2D vel;
    rcsc::Vector2D *objs;
};


// VecPosition ballPos, VecPosition ballVel, int playerNums, VecPosition *predictPlayers,
// 				    int &finishTime, float &finalX, float &finalY

class PlayerState;

class PossibilityModel {
public:

        PossibilityModel();
        static PossibilityModel & instance();
        virtual ~PossibilityModel();

        /**
         * Caculate the possibility from intercept cycles.
         * This function is for dribble or pass.
         * @param dist the distance for ball to move.
         * @param cycle_diff the difference of cycles needed
         * 	for ball to the target and the player to the target.
         * @param cycle_delay the cycle delay for player.
         * @param save_rate the rate to fix the cycle_delay, which
         * 	shows the decrease rate of possibility for increase
         * 	of cycle_delay.
         * @return the possibility.
         */
        double Cycle2Possibility(double dist, double cycle_diff, int cycle_delay = 0, double safe_rate = 1.0);

        /**
         * Caculate the possibility for player to run to the target position
         * to kick the ball in a certain number of cycles.
         * @param p the player to caculate.
         * @param target the target position.
         * @param cycle the cycles to caculate.
         * @param distance the ball distance at the final cycle.
         * @param saferete.
         * @retrun the possibility.
         */
        double CalcPlayerGoToPointPoss(const rcsc::PlayerObject * obj, rcsc::Vector2D target, double cycle, double distance, double saferate = 2.0);

        /**
         * Caculate the position after some certain cycles, for shoot possibility.
         * @param ballpt the ball position.
         * @param glpos the goal position.
         * @param precyc the cycles to predict.
         * @param ourside.
         * @return double the shoot success rate.
         */
        double CalcShootSuccessRate(const Vector & ballpt, const Vector &glpos, double precyc = 0.0, bool ourside = true);

        /**
         * Caculate the direct pass success rate.
         * @param ballpt the ball position.
         * @param tmpt the teammate position.
         * @param oppt the opponent position.
         * @param cyclefix.
         * @return the success rate.
         */
        double CalcDirectPassSuccessRate(const rcsc::Vector2D & ballpt, const rcsc::Vector2D & tmpt, const rcsc::Vector2D & oppt, double cyclefix = 0);

          /**
            * Caculate the direct pass success rate.
            * @param prob PossibilityModelStruct input
            * @param end_cycle finish time
            * @param end_point predicted time
            * @return reach cycle.
            */
         void CalculatePossibilityModel( PossibilityModelStruct prob,  int &end_cycle, rcsc::Vector2D end_point);

        //==============================================================================
public:
        const ReciprocalCurve & GetCycleDifferfix() const       { return mCycleDifferFix; }
        const ReciprocalCurve & GetPassOutsideFix() const       { return mPassOutsideFix; }
        const ReciprocalCurve & GetKickMaxRandFix() const       { return mKickMaxRandFix; }
        const ReciprocalCurve & GetPassKickSpeedFix() const     { return mPassKickSpeedFix; }
        const ReciprocalCurve & GetPassLowStaminafix() const    { return mPassLowStaminaFix; }
        const ReciprocalCurve & GetDirectPassPoss() const       { return mDirectPassPoss; }

private:
        ReciprocalCurve mCycleDifferFix;    //
        ReciprocalCurve mPassOutsideFix;    //
        ReciprocalCurve mKickMaxRandFix;    //
        ReciprocalCurve mPassKickSpeedFix;  //
        ReciprocalCurve mPassLowStaminaFix; //
    ReciprocalCurve mDirectPassPoss;	//

public:
    const ReciprocalCurve & GetKickablePoss() const         { return mKickablePoss; }
    const ReciprocalCurve & GetDribbleAngleDecay() const    { return mDribbleAngleDecay; }
    const ReciprocalCurve & GetFastDribblePossDecay() const { return mFastDribblePossDecay; }
    const ReciprocalCurve & GetFastDribbleLastPoint() const { return mFastDribbleLastPoint; }
    const ReciprocalCurve & GetFastDribbleBreakPoss() const { return mFastDribbleBreakPoss; }
    const ReciprocalCurve & GetTurnDribbleAvoidRate() const { return mTurnDribbleAvoidRate; }

private:
    ReciprocalCurve mKickablePoss;      //
    ReciprocalCurve mDribbleAngleDecay;     //
    ReciprocalCurve mFastDribblePossDecay;  //
    ReciprocalCurve mFastDribbleLastPoint;  //
    ReciprocalCurve mFastDribbleBreakPoss;  //
    ReciprocalCurve mTurnDribbleAvoidRate;  //

public:
        const ReciprocalCurve & GetOutOfPitchRate() const { return mOutOfPitchRate; }

private:
    ReciprocalCurve mOutOfPitchRate;        //

public:
    const ReciprocalCurve & GetTeammateInfluence(const int & player_type) const
    {
//         Assert(player_type >= 0 && player_type < MAX_PLAYER_TYPES);
        return mTeammateInfluence[player_type];
    }

    const ReciprocalCurve & GetOpponentInfluence(const int & player_type) const
    {
//         Assert(player_type >= 0 && player_type < MAX_PLAYER_TYPES);
        return mOpponentInfluence[player_type];
    }

private:
    //caculate player influence of a point, while teammate
    //is above 0, and opponent is below 0.
    ReciprocalCurve mTeammateInfluence[MAX_PLAYER_TYPES]; //
    ReciprocalCurve mOpponentInfluence[MAX_PLAYER_TYPES];
};

#endif /* POSSIBILITYMODEL_H_ */
