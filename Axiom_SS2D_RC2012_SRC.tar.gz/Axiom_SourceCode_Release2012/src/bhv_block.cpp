
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "bhv_block.h"

#include <rcsc/action/body_advance_ball.h>
#include <rcsc/action/body_dribble.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/body_clear_ball2009.h>
#include <rcsc/action/body_intercept.h>
#include <rcsc/action/body_go_to_point.h>
#include <rcsc/action/body_turn_to_ball.h> 
#include <rcsc/action/body_turn_to_point.h>
#include <rcsc/action/body_pass.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>
#include <rcsc/action/neck_turn_to_ball_or_scan.h>
#include <rcsc/action/neck_turn_to_ball.h>
#include <rcsc/action/body_turn_to_angle.h>

#include <bhv_basic_tackle.h>

#include <rcsc/player/player_agent.h>
#include <rcsc/player/debug_client.h>
#include <rcsc/common/server_param.h>

#include <rcsc/common/logger.h>
#include <rcsc/common/server_param.h>
#include <rcsc/geom/sector_2d.h>
#include <rcsc/geom/circle_2d.h>
#include "bhv_danger_area_tackle.h"

#include <strategy.h>
#include "bhv_basic_move.h"
#include "neck_check_ball_owner.h"
#include <rcsc/player/free_message.h>


/**
 * bhv_block.cpp
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Authors :  Mohammad Mahdavi, Mostafa Zamani, Hossein Rahmatizadeh
 * Copyright 2012
 * Allright Reserved
 */


using namespace rcsc;
/*-------------------------------------------------------------------*/
/*!

 */
bool
axiom_block::execute( PlayerAgent * agent )
{

    // TODO in ke Dge be nearest narim ye jaye behtar berim :)




    if ( agent->world().existKickableTeammate()/* || agent->world().lastKickerSide() == agent->world().ourSide()*/ )
    {
	//std::cout <<" UNUM : "<< agent->world().self().unum() << " return false in Block.execute "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
        return false;
    }


    const Vector2D SELF_POS = agent->world().self().pos();
    const Vector2D BALL_POS = agent->world().ball().pos();

    int self_min = agent->world().interceptTable()->selfReachCycle();
    int mate_min = agent->world().interceptTable()->teammateReachCycle();

    if ( agent->world().existKickableOpponent()  || ifOppHasBall( agent ) )
    {
     // std::cout <<" UNUM : "<< agent->world().self().unum() << " exist opp  "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
        if ( amIBlocker( agent ) )
        {
         //   std::cout <<" UNUM : "<< agent->world().self().unum() << " going to block "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
            if ( doBlockMove(agent) )
                return true;
        }
    }

    if ( (BALL_POS.x < SELF_POS.x + 1.0) || agent->world().ball().inertiaPoint( self_min ).x < SELF_POS.x )
    {  
     // std::cout <<" UNUM : "<< agent->world().self().unum() << " first checked getBack "<< " in cycle : "<<agent->world().time().cycle()<<"\n";

        if ( ( self_min <= mate_min || area( BALL_POS ) > 3  ) && agent->world().self().unum() != 11
                && agent->world().self().unum() != 9 && agent->world().self().unum() != 10  )
        {
	//  std::cout <<" UNUM : "<< agent->world().self().unum() << " second getBack "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
            if ( getBack( agent ) )
            {
              //  std::cout <<" UNUM : "<< agent->world().self().unum() << " getBack "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
                return true;
            }
        }
    }

    return false;
}

bool
axiom_block::doBlockMove( PlayerAgent * agent )
{
    const WorldModel & wm = agent->world();
    Vector2D selfPos = wm.self().pos();
    Vector2D ballPos = wm.ball().pos();
    Vector2D posBlock;

    if ( wm.interceptTable()->fastestOpponent() ) // POINTER
        getBlockPosition( agent, wm.interceptTable()->fastestOpponent() , &posBlock ); // POINTER
	
      if(wm.interceptTable()->fastestOpponent())/// too in nahie mostafa mighe posBlock koja bashe : ARE!!
      {
	
	Vector2D oppPos = wm.interceptTable()->fastestOpponent()->pos();
	if( area( ballPos ) > 3  && (wm.self().unum() == 4 || wm.self().unum() == 5)  )
	{
	  if( fabs(selfPos.y- oppPos.y) > 3.0  )
	  {
	    posBlock.y = oppPos.y;
	    posBlock.x = selfPos.x;
	    //std::cout<<" YPOS  is: ( "<<posBlock.x << " ,  "<<posBlock.y<<" ) "<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<std::endl;
	  }
	  else
	  {
	    if( wm.self().distFromBall() > 8.0 )
	    {
	      posBlock = oppPos;
	      //std::cout<<" DIST>7 POS  is: ( "<<posBlock.x << " ,  "<<posBlock.y<<" ) "<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<std::endl;
	    }
	    else
	    {
	      posBlock = (oppPos + ballPos)/2.0;
	      //std::cout<<" MIDLLEPOS is: ( "<<posBlock.x << " ,  "<<posBlock.y<<" ) "<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<std::endl;
	    }
	  }
	 
	}
	
	if(Body_GoToPoint(posBlock, .3, ServerParam::i().maxDashPower() ).execute(agent) )
	{
	  //std::cout<<"IN DOBLOCKMOVE pos is: ( "<<posBlock.x << " ,  "<<posBlock.y<<" ) "<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<std::endl;
	  return true;
	}
	else
	{
	  if(Body_Intercept().execute( agent ))
	    return true;
    //   std::cout<<"ELSE doBlockMove BODY_INTERCEPT UNUM "<<agent->world().self().unum()<<" UNUM "<<agent->world().time().cycle()<<std::endl; 
  //       Body_TurnToPoint(posBlock ).execute(agent);
	}
      }
      else
      {
	if(Body_Intercept().execute(agent))
	  return true;
      }
    return false;
}


bool
axiom_block::getBlockPosition( PlayerAgent * agent,const PlayerObject * opp, Vector2D *blockpos )
{
    int cycles = 0;
    const WorldModel & wm = agent->world();
    Vector2D pos_agent = wm.self().pos();
    Vector2D posOpp = opp->pos();
    const PlayerObject * fasest_opp; // POINTER
    if ( posOpp.dist( wm.ball().pos() ) >  opp->playerTypePtr()->kickableMargin() )
    {
        fasest_opp = wm.interceptTable()->fastestOpponent(); // POINTER
        if (fasest_opp != NULL)
        {
            cycles = fasest_opp->playerTypePtr()->cyclesToReachDistance( fasest_opp->distFromBall() ); // POINTER
            posOpp = wm.ball().inertiaPoint(cycles);
        }
    }
    float my_block_speed = wm.self().playerType().playerSpeedMax();
    float their_block_speed = ServerParam::DEFAULT_PLAYER_SPEED_MAX * 0.8;

    getBlockPoint( posOpp, pos_agent, cycles, my_block_speed, their_block_speed, blockpos );

    float targetbdfc = (*blockpos - wm.self().pos()).th().degree();
    if (fabs( AngleDeg::normalize_angle ( ( targetbdfc - wm.self().body().degree() ))) < 25.0f)
    {
        float dist = wm.self().pos().dist( *blockpos ) + 2.0f;
//         *blockpos = wm.self().pos() + Vector2D::polar2vector ( 1.0, wm.self().body() ) * dist;
        *blockpos = wm.self().pos() + Vector2D::polar2vector ( 2.0, wm.self().body() ) * dist;
    }

    return true;
}

bool
axiom_block::getBlockPoint( Vector2D posOpp,Vector2D posAgent,float cycles,
                            float my_block_speed,float their_block_speed, Vector2D *blockpos )
{
    float predis = std::max( (double) (my_block_speed * cycles), 1.0 );
    float disleft = posOpp.dist( Vector2D( -52.5, -7.01 ) );
    float ratio = disleft/(disleft + posOpp.dist( Vector2D( -52.5, 7.01 )) );
    Vector2D opttarget = Vector2D( -52.5, 14.02 * ( ratio - 0.5 ));
    Vector2D opponent_pos = ( opttarget - posOpp);
    if ( (opponent_pos.x * opponent_pos.x + opponent_pos.y * opponent_pos.y ) != 0 )
        opponent_pos /= opponent_pos.r();
    opponent_pos = posOpp + opponent_pos * 1.0;

    Vector2D vec_me_opt = posAgent - opponent_pos;
    float dis_me_opt = vec_me_opt.r();

    if (dis_me_opt <= predis or their_block_speed < 1e-2)
    {
        *blockpos = opponent_pos;
        return true;
    }

    float ratio_speed = my_block_speed / their_block_speed;
    double lGoalAng = AngleDeg::normalize_angle( (Vector2D( -52.5, -7.01 ) - opponent_pos).dir().degree() );
    double rGoalAng = AngleDeg::normalize_angle( (Vector2D( -52.5, 7.01 ) - opponent_pos).dir().degree() );
    double goalstrechangle = AngleDeg::normalize_angle( std::fabs( lGoalAng - rGoalAng )  );
    double angDiffMeOpt=AngleDeg::normalize_angle(std::fabs(vec_me_opt.dir().degree() -(opttarget-opponent_pos).dir().degree()));


    if ( angDiffMeOpt < goalstrechangle / 4 and angDiffMeOpt < 10)
        return getBlockSubPoint(opttarget,opponent_pos,posAgent,ratio_speed,predis,blockpos);

    return getBlockSubPoint(opttarget,opponent_pos,posAgent,ratio_speed,predis,blockpos);

}

bool
axiom_block::getBlockSubPoint( Vector2D opttarget, Vector2D opponent_pos, Vector2D selfpos,
                               float ratio_speed,float predis, Vector2D *blockpos )
{

    Vector2D vec_me_opt = selfpos - opponent_pos ;
    float dis_me_opt = vec_me_opt.r();

    float interangle = vec_me_opt.dir().degree() - (opttarget-opponent_pos).dir().degree();
    float tempf,tempc;
    float tempa = 1.0f - ratio_speed * ratio_speed;
    if (std::fabs(tempa)<1e-2)
    {
        tempf = predis + dis_me_opt * (float)std::cos( AngleDeg::deg2rad (interangle));
        if (tempf <= 1e-2)
        {
            *blockpos = (opponent_pos + opttarget)/2;
            return false;
        }
        tempc = 0.5f*(dis_me_opt * dis_me_opt - predis*predis) / tempf;
    }
    else
    {
        tempf = 2*predis*ratio_speed + 2 * dis_me_opt * (float)std::cos(AngleDeg::deg2rad(interangle));
        float tempz = tempf * tempf - 4 * tempa * ( dis_me_opt * dis_me_opt - predis * predis );
        if (tempz < 0)
        {
            *blockpos = ( opponent_pos + opttarget ) / 2;
            return false;
        }
        tempz = (float)std::sqrt(tempz);
        float tempx1 = 0.5f * (-tempz + tempf)/tempa;
        float tempx2 = 0.5f * (tempz + tempf)/tempa;
        if (tempx1 < 0 and tempx2 < 0)
        {
            *blockpos = ( opponent_pos + opttarget ) / 2;
            return false;
        }
        else if (tempx1 > 0 and tempx2 > 0)
            tempc = std::min( tempx1, tempx2 );
        else tempc = std::max( tempx1, tempx2 );
    }
    float odist = opponent_pos.dist(opttarget);

    if ( tempc >= odist + 1e-2 )
    {
        *blockpos = ( opponent_pos + opttarget ) / 2;
        return false;
    }
    float ratio = tempc / odist;
    *blockpos = (opponent_pos * (1-ratio) + opttarget * ratio);
    return true;
}


bool axiom_block::amIBlocker(PlayerAgent* agent)
{
    /// mostafa change MIN_X_FRONT from 0.5 to 1
    const double MIN_X_FRONT = 1.0;
    const double DIST_TO_OFFSIDE_LINE = 12.0;

    const double RADIUS_BLOCK = 12.0;

    const WorldModel & wm = agent->world();
    int self_min = wm.interceptTable()->selfReachCycle();
    int mate_min = wm.interceptTable()->teammateReachCycle();

    const PlayerObject * neartmm = agent->world().interceptTable()->fastestTeammate();
    const PlayerObject * nearopp = agent->world().interceptTable()->fastestOpponent();

    if ( wm.self().goalie() )
    {
        return true;
    }

    if ( ( agent->world().self().unum() == 4 || agent->world().self().unum() == 5 ) && agent->world().ball().pos().x > (wm.ourDefensePlayerLineX() + DIST_TO_OFFSIDE_LINE ))
    {
	//std::cout <<" UNUM : "<< agent->world().self().unum() << " return false in offsideLine "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
        return false;
    }
    if (( agent->world().self().unum() == 2 || agent->world().self().unum() == 3 ) && agent->world().ball().pos().x >( wm.ourDefensePlayerLineX() + (DIST_TO_OFFSIDE_LINE / 1.5)) )
    {
	//std::cout <<" UNUM : "<< agent->world().self().unum() << " return false in offsideLine "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
        return false;
    }

   
    // inserted by hossein and mostafa
    
   // std::cout<<"my UMUM : "<<agent->world().self().unum() <<" CYCLE : "<<agent->world().time().cycle()<<" nearopp : "<<nearopp->unum()<<" neartmm : "<<neartmm->unum()<<std::endl;
    if (nearopp != NULL and neartmm != NULL)
    {
        if ( agent->world().self().unum() == 3 and agent->world().ball().pos().x < -41.0 and  agent->world().ball().pos().y > 7.0
                and  agent->world().ball().pos().y < 20.0 && ( (neartmm)->pos().y > (nearopp)->pos().y   )  )
        {
            return true;
        }

        if ( agent->world().self().unum() == 2 and agent->world().ball().pos().x < -41.0 and  agent->world().ball().pos().y < -7.0
                and  agent->world().ball().pos().y > -20.0 and (neartmm)->pos().y < (nearopp)->pos().y     )
        {
            return true;
        }
    }
    // inserted by hossein and mostafa



//////////////////////@@@


   // std::cout <<" UNUM : "<< agent->world().self().unum() << " self_min :  "<< self_min <<"\t"<< " mate_min :  "<< mate_min << " in cycle : "<<agent->world().time().cycle()<<"\n";
    
    if ( self_min <= mate_min  )
    {
        if (agent->world().self().stamina() > 200.0 )
        {
            if ( area( wm.ball().pos() ) == 2  )
            {
                return true;
            }


            if ( ( area( wm.ball().pos() ) == 1  ) and (agent->world().ball().pos().x < -44.0 )
                and wm.self().pos().x < wm.ball().pos().x + MIN_X_FRONT
                && agent->world().self().unum() != 2 && agent->world().self().unum() != 3 && agent->world().self().unum() != 5 )
            {
                return true;
            }

            /// mostafa$

            if ( ( area( wm.ball().pos() ) == 1  ) and (agent->world().ball().pos().x > -44.0 )
                and wm.self().pos().x < wm.ball().pos().x - MIN_X_FRONT 
                && agent->world().self().unum() != 2 && agent->world().self().unum() != 3 && agent->world().self().unum() != 5 )
            {
                return true;
            }

            if ( ( area( wm.ball().pos() ) == 3 )and (agent->world().ball().pos().x < -44.0 )
                    and wm.self().pos().x < wm.ball().pos().x + MIN_X_FRONT
                    && agent->world().self().unum() != 2 && agent->world().self().unum() != 3 && agent->world().self().unum() != 4 )

            {
                return true;
            }

            /// mostafa$
             if ( ( area( wm.ball().pos() ) == 3 )and (agent->world().ball().pos().x > -44.0 )
                    and wm.self().pos().x < wm.ball().pos().x - MIN_X_FRONT
                    && agent->world().self().unum() != 2 && agent->world().self().unum() != 3 && agent->world().self().unum() != 4 )

            {
                return true;
            }

            if ( ( area( wm.ball().pos() ) > 3 ) )// and wm.self().pos().x < wm.ball().pos().x + MIN_X_FRONT - 1.5 )
            {
              if( (agent->world().self().unum() == 4 || agent->world().self().unum() == 5)
                   and wm.self().pos().x < wm.ball().pos().x + MIN_X_FRONT - 2.0  )
              {
                return true;
              }
              else if( wm.self().pos().x < wm.ball().pos().x + MIN_X_FRONT
                  and agent->world().self().unum() != 4  and agent->world().self().unum() != 5)
              {

                return true;
              }
            }

        }/*else
      {
        return false;
      } */
    }


    if ( wm.self().distFromBall() < RADIUS_BLOCK && wm.self().pos().x < wm.ball().pos().x
      && (area(agent->world().ball().pos()) > 3 || area(agent->world().ball().pos()) == 2 ) )
    {

        std::vector<const PlayerObject *> list_of_tmms_in_circle;
        list_of_tmms_in_circle.clear();

        Circle2D c(wm.ball().pos(),RADIUS_BLOCK);

        const PlayerPtrCont::const_iterator tmm_end = wm.teammatesFromBall().end();
        for ( PlayerPtrCont::const_iterator tmm = wm.teammatesFromBall().begin();  tmm != tmm_end;    ++ tmm )
        {
            if ( (*tmm) ==  NULL )
                continue;

            if ( (*tmm)->isGhost() )
                continue;

            if ( (*tmm)->goalie() )
                continue;

            if ( c.contains( (*tmm)->pos() ) && (*tmm)->pos().x < wm.ball().pos().x )
            {
                list_of_tmms_in_circle.push_back(*tmm);
            }
        }
        if ( list_of_tmms_in_circle.size() == 0 )
            return true;
        else if ( list_of_tmms_in_circle.size() > 0 )
        {
            if (  agent->world().self().distFromBall() < list_of_tmms_in_circle[0]->distFromBall() )
            {
                return true;
            }
        }

    }



//     if ( area(wm.ball().pos() ) >  3 and ( wm.self().unum() == 7 || wm.self().unum() == 8 || wm.self().unum() == 6 ) )
//         return true;

//     else if( self_min > mate_min and agent->world().getTeammateNearestToBall(4,false)-stamina < 200 )
//     {
//        if ( agent->world().teammatesFromBall().size() >= 2
// 	      and agent->world().teammatesFromBall().at(0)->distFromBall() < agent->world().self().distFromBall()
// 	      and agent->world().teammatesFromBall().at(1)->distFromBall() > agent->world().self().distFromBall()  )
// 	{
// 	    return true;
// 	}
//     }
//

return false;

}

bool axiom_block::getBack( PlayerAgent* agent )
{
    /// mostafa chenge BAND_WIDTH from 10 to 15 $
    const double BAND_WIDTH = 15.0;

    int self_min = agent->world().interceptTable()->selfReachCycle();
    int mate_min = agent->world().interceptTable()->teammateReachCycle();
    
    
    Segment2D ball2goal( agent->world().ball().inertiaPoint(self_min) , Vector2D(-52.5 , 0.0) );
    Segment2D ball2goalnoinertia( agent->world().ball().pos() , Vector2D(-52.5 , 0.0) );
    
    Segment2D self2y( agent->world().self().pos()  , Vector2D(-52.5 , agent->world().self().pos().y )   );
    

    Vector2D vec_intersectpoint;
    
    if ( agent->world().ball().inertiaPoint(self_min).x < -52.5  ||  agent->world().ball().inertiaPoint(self_min).absY() > 34.0 )
    {
        vec_intersectpoint =   ball2goalnoinertia.intersection( self2y , false );
	if( agent->world().ball().pos().y > 0.0)
	  vec_intersectpoint.y += 1.0;
	else 
	  vec_intersectpoint.y += -1.0;
	
      //  std::cout<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<" vec_intersectpoint NOT valid out of field value is ( "<<vec_intersectpoint.x<<" , "<<vec_intersectpoint.y<<" ) "<<std::endl;
    }
    else
    {
        vec_intersectpoint =   ball2goal.intersection( self2y , false );
	if( agent->world().ball().pos().y > 0.0)
	  vec_intersectpoint.y += 1.0;
	else 
	  vec_intersectpoint.y += -1.0;
	
    }

    if ( !vec_intersectpoint.isValid() )
    {
      if( self_min > mate_min and (agent->world().self().unum() == 4 ||agent->world().self().unum() == 5)   )
	return false;


      //  std::cout<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<" vec_intersectpoint NOT valid && invalid value is ( "<<vec_intersectpoint.x<<" , "<<vec_intersectpoint.y<<" ) "<<std::endl;
        vec_intersectpoint = ball2goal.nearestPoint( agent->world().self().pos() );
	
// 	vec_intersectpoint.x =   (ball2goal.terminal().x + ball2goal.origin().x)/2.0;
// 	vec_intersectpoint.y =   (ball2goal.terminal().y + ball2goal.origin().y)/2.0;
	
	
     //   std::cout<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<" vec_intersectpoint NOT valid && nearest value is ( "<<vec_intersectpoint.x<<" , "<<vec_intersectpoint.y<<" ) "<<std::endl;
     }



    /// in band_width yekam moshkel dare !! agent ma ta ghable band_width get back mikone bad ke toop door mishe Dg vel mikone!!$
    if ( agent->world().ball().pos().y < agent->world().self().pos().y + BAND_WIDTH
            and  agent->world().ball().pos().y > agent->world().self().pos().y - BAND_WIDTH )
    {
      /// else in Body_GoToPoint ye body_turn_to_ball ezafe kardam!$
        if (Body_GoToPoint( vec_intersectpoint , .3, ServerParam::i().maxDashPower(), -1, 100, false ).execute(agent) )
        {
            agent->setNeckAction( new Neck_TurnToBall() );

          //  std::cout<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<" vec_intersectpoint in BODY_GO value is ( "<<vec_intersectpoint.x<<" , "<<vec_intersectpoint.y<<" ) "<<std::endl;

            return true;
        }
        else
        {
	  Body_TurnToPoint(vec_intersectpoint).execute(agent);
	 // std::cout<<" UNUM "<<agent->world().self().unum()<<" CYCLE "<<agent->world().time().cycle()<<" bodyGotoPoint is false in GET_BACK THEN body_turn_to_ball is OK! "<<std::endl;
          return true;
        }
    }

    return false;
}

int axiom_block::area( const Vector2D v )
{
   ///  mostafa change this from 12 to 21
    if ( v.x < -30.0 && v.absY() <= 21.0 )
        return 2;
    
    if ( v.x < -30.0 && v.y < -18.0 )
        return 1;

    if ( v.x < -30.0 && v.y > 18.0 )
        return 3;

    if ( v.x > -30.0 && v.x < -15.0 )
        return 4;

    return 5;
}

bool axiom_block::ifOppHasBall( PlayerAgent* agent )
{
    const double RADIUS = 2.0;
    const double MAX_CYCLE = 5.0;

    int self_min = agent->world().interceptTable()->selfReachCycle();
    int mate_min = agent->world().interceptTable()->teammateReachCycle();
    int opp_min = agent->world().interceptTable()->opponentReachCycle();
    const PlayerObject * opp = agent->world().interceptTable()->fastestOpponent();

    Circle2D ball_circle( agent->world().ball().pos() , RADIUS );

    if ( opp and ball_circle.contains( opp->pos() ) and opp_min < self_min  and opp_min < mate_min and opp_min < MAX_CYCLE )
        return true;

  //  std::cout <<" UNUM : "<< agent->world().self().unum() << " opp toop nadare "<< " in cycle : "<<agent->world().time().cycle()<<"\n";
    return false;
}


