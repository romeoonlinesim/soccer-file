/**********************************
** Authors: Farbod Samsamipour   **
**          Hossein Rahmatizadeh **
** Date   : 26 April 2012        **
**********************************/

#ifndef AXIOM_MARK_H
#define AXIOM_MARK_H

#include <rcsc/action/neck_turn_to_ball_and_player.h>
#include <rcsc/action/basic_actions.h>
#include <rcsc/action/body_go_to_point.h>
#include <rcsc/action/neck_turn_to_ball_or_scan.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/neck_turn_to_point.h>
#include <rcsc/action/body_intercept.h>

#include <rcsc/player/player_agent.h>
#include <rcsc/player/intercept_table.h>
#include <rcsc/player/player_object.h>
#include <rcsc/player/soccer_action.h>
#include <rcsc/player/world_model.h>

#include <rcsc/common/server_param.h>

#include <rcsc/geom/rect_2d.h>
#include <rcsc/geom/vector_2d.h>

#include "strategy.h"
#include "bhv_set_play.h"

using namespace std;
using namespace rcsc;

class Axiom_Mark
{
    public:
        Axiom_Mark() {}

        bool execute(PlayerAgent *agent);

};

#endif
