/**
 * axiom_positioning.h
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Author : Omid Shirkhorshidi
 * Copyright 2012
 * Allright Reserved
 */

#ifndef POSITIONING_H
#define POSITIONING_H

#include <cmath>
#include <rcsc/player/player_agent.h>
#include <rcsc/geom/vector_2d.h>
#include <rcsc/geom/rect_2d.h>
#include <rcsc/geom/ray_2d.h>
#include <rcsc/geom/circle_2d.h>
#include <rcsc/geom/angle_deg.h>
#include <rcsc/geom/line_2d.h>
#include <rcsc/geom/sector_2d.h>
#include <rcsc/geom/polygon_2d.h>

using namespace std;
using namespace rcsc;


class axiom_positioning
{
public:
  axiom_positioning ()
  {}
  bool execute(PlayerAgent* agent);
  bool is_oppIntheRay(PlayerAgent* agent , rcsc::Sector2D _ball_sec);
  bool temp(PlayerAgent* agent);
  
private:
  vector<rcsc::Sector2D> ball_sectores;
  
};

#endif