#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <rcsc/geom/angle_deg.h>

#include <rcsc/player/player_agent.h>
#include <rcsc/common/server_param.h>

#include "analysis.h"

/**
 * This function returns pair's player
 *
 * */

std::vector<int>
Analysis::getPairPlayer(rcsc::PlayerAgent* agent)
{
  const rcsc::WorldModel & wm = agent->world();
  int self_no = wm.self().unum();
  std::vector<int> numbers;
/*  if ( self_no == 9 and Strategy::i().getPosition( self_no ) == Strategy::BA_Cross )
  {
   numbers.push_back(11);
   numbers.push_back(10);
   numbers.push_back(7);
  }
  if ( self_no == 9 and Strategy::i().getPosition( self_no ) == Strategy::BA_DribbleAttack )
  {
   numbers.push_back(11);
   numbers.push_back(7);
  }
  if ( self_no == 10 and Strategy::i().getPosition( self_no ) == Strategy::BA_Cross )
  {
   numbers.push_back(11);
   numbers.push_back(10);
   numbers.push_back(8);
  }
  if ( self_no == 10 and Strategy::i().getPosition( self_no ) == Strategy::BA_DribbleAttack )
  {
   numbers.push_back(11);
   numbers.push_back(8);
  }*/
}


/*!
This function counts the number of opponents
in the specific circlular area
*/
int
Analysis::getOppNumber(rcsc::PlayerAgent * agent,
                             const rcsc::Vector2D &center,
                             const double &r)
{
    const rcsc::WorldModel & wm = agent->world();
    int number = 0;
    double max_dist;
    rcsc::Vector2D v = center - wm.self().pos();
    max_dist = v.length() + r;
    const rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromSelf().end();
    for(rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
        opp != end;
        ++opp)
    {

        if((*opp)->pos().dist(center) <= r)
        {
            number++;
        }
        else if((*opp)->pos().dist(wm.self().pos()) > max_dist)
        {
            break;
        }
    }
    return number;
}

/*!
This function counts the number of opponents
in the specific area
*/
int
Analysis::getOppNumber(rcsc::PlayerAgent * agent,
                             const double &front_x,
                             const double &back_x)
{
    int number;
    double  max_dist, front_difference, back_difference, top_difference, bottom_difference;
    const rcsc::WorldModel & wm = agent->world();
    rcsc::Vector2D v(0.0, 0.0);
    front_difference = std::abs(front_x);
    back_difference = std::abs(back_x);
    top_difference = std::abs(rcsc::ServerParam::i().pitchHalfWidth() - wm.self().pos().y);
    bottom_difference = std::abs(-rcsc::ServerParam::i().pitchHalfWidth() - wm.self().pos().y);
    v.x = (front_difference > back_difference) ? front_difference : back_difference;
    v.y = (top_difference > bottom_difference) ? top_difference : bottom_difference;
    max_dist = v.length();
    number = 0;
    const rcsc::AbstractPlayerObject * abst;
    const rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromSelf().end();
    for(rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
        opp != end;
        ++opp)
    {
      abst = (*opp);
        if((*opp)->pos().x <= wm.self().pos().x + front_x
           && (*opp)->pos().x >= wm.self().pos().x - back_x)
        {
            number++;
        }
        else if((*opp)->pos().dist(wm.self().pos()) > max_dist)
        {
            break;
        }
    }
    return number;
}

/*!
This function counts the number of opponents
in the specific rectangular area
*/
int
Analysis::getOppNumber(rcsc::PlayerAgent * agent,
                             const rcsc::Vector2D &left_top,
                             const double &length,
                             const double &width)
{
    const rcsc::WorldModel & wm = agent->world();
    int number = 0;
    double max_r;
    rcsc::Vector2D left_bottom(left_top.x, left_top.y + width);
    rcsc::Vector2D right_top(left_top.x + length, left_top.y);
    rcsc::Vector2D right_bottom(right_top.x, right_top.y + width);
    max_r = (left_top - wm.ball().pos()).length();
    if(max_r < (left_bottom - wm.ball().pos()).length())
    {
        max_r = (left_bottom - wm.ball().pos()).length();
    }
    if(max_r < (right_top  - wm.ball().pos()).length())
    {
        max_r = (right_top  - wm.ball().pos()).length();
    }
    if(max_r < ( right_bottom - wm.ball().pos()).length())
    {
        max_r = (right_bottom - wm.ball().pos()).length();
    }
    const rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromBall().end();
    for(rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromBall().begin();
        opp != end;
        ++opp)
    {
        if(((*opp)->pos().x >= left_top.x && (*opp)->pos().x <= right_top.x)
           &&((*opp)->pos().y >= left_top.y && (*opp)->pos().y <= left_bottom.y))
        {
            number++;
        }
        else if((*opp)->pos().dist(wm.ball().pos()) > max_r)
        {
            break;
        }
    }
    return number;
}
/*!
This function counts the number of opponents
in the specific four areas

    |
  2 | 3
---------->
  1 | 0
   \|/
*/
std::vector<int>
Analysis::getOppNumberAroundBall(rcsc::PlayerAgent * agent,double dist)

{
    const rcsc::WorldModel & wm = agent->world();
    rcsc::Vector2D v;
    const int all = 4;
    int region[all] = {0, 0, 0, 0};
    double angle;
    const rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromBall().end();
    for(rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromBall().begin();
        opp != end;
        ++opp)
    {
        if((*opp)->distFromBall() <= dist )
        {

            v = (*opp)->pos() - wm.ball().pos();
            angle = rcsc::AngleDeg::normalize_angle(v.th().degree());
            if(angle >= 0.0 && angle <= 90.0)
            {
                region[0]++;

            }
            else if(angle > 90.0 && angle <= 180.0)
            {
                region[1]++;
            }
            else if(angle < 0.0 && angle > -90.0)
            {
                region[3]++;
            }
            else
            {
                region[2]++;
            }
        }
        else
        {
            break;
        }
    }
    int i;
    std::vector<int> opp_list;
    for(i=0; i<all; i++)
    {
        opp_list.push_back(region[i]);
    }
    return opp_list;
}

/*!
This function counts the number of teammates
in the specific circlular area
*/
int
Analysis::getMateNumber(rcsc::PlayerAgent * agent,
                              const rcsc::Vector2D &center,
                              const double &r)
{
   const rcsc::WorldModel & wm = agent->world();
   int number = 0;
   double max_dist;
   rcsc::Vector2D v = center - wm.ball().pos();
   max_dist = v.length() + r;
   v = wm.self().pos() - center;
   const rcsc::PlayerPtrCont::const_iterator end = wm.teammatesFromBall().end();
   for(rcsc::PlayerPtrCont::const_iterator mate = wm.teammatesFromBall().begin();
       mate != end;
       ++mate)
   {
     if((*mate)->pos().dist(center) <= r)
     {
         number++;
     }
     else if((*mate)->distFromBall() > max_dist)
     {
         break;
     }
   }
   return number;
}

/*!
This function counts the number of teammates
in the specific rectangular area
*/
int
Analysis::getMateNumber(rcsc::PlayerAgent * agent,
                              const rcsc::Vector2D &left_top,
                              const double &length,
                              const double &width)
{
    const rcsc::WorldModel & wm = agent->world();
    int number = 0;
    double max_dist;
    rcsc::Vector2D left_bottom(left_top.x, left_top.y + width);
    rcsc::Vector2D right_top(left_top.x + length, left_top.y);
    rcsc::Vector2D right_bottom(right_top.x, right_top.y + width);
    max_dist = (left_top - wm.ball().pos()).length();
    if(max_dist < (left_bottom - wm.ball().pos()).length())
    {
        max_dist = (left_bottom - wm.ball().pos()).length();
    }
    if(max_dist < (right_top  - wm.ball().pos()).length())
    {
        max_dist = (right_top  - wm.ball().pos()).length();
    }
    if(max_dist < ( right_bottom - wm.ball().pos()).length())
    {
        max_dist = (right_bottom - wm.ball().pos()).length();
    }
    const rcsc::PlayerPtrCont::const_iterator end = wm.teammatesFromBall().end();
    for(rcsc::PlayerPtrCont::const_iterator mate = wm.teammatesFromBall().begin();
        mate != end;
        ++mate)
    {
        if(((*mate)->pos().x >= left_top.x && (*mate)->pos().x <= right_top.x)
           &&((*mate)->pos().y >= left_top.y && (*mate)->pos().y <= left_bottom.y))
        {
            number++;
        }
        else if((*mate)->distFromBall() > max_dist)
        {
            break;
        }
    }
    return number;
}

/*!
This function searchs dist from the nearest mate
that is nearest from the point
*/
double
Analysis::getDistFromNearestMate(rcsc::PlayerAgent * agent,
                                      const rcsc::Vector2D &point)
{
    const rcsc::WorldModel & wm = agent->world();
    double dist;
    rcsc::PlayerPtrCont::const_iterator mate = wm.teammatesFromSelf().begin();
    const rcsc::PlayerPtrCont::const_iterator end = wm.teammatesFromSelf().end();
    dist = (*mate)->pos().dist(point);
    mate++;
    while(mate != end)
    {
        if(dist > (*mate)->pos().dist(point))
        {
            dist = (*mate)->pos().dist(point);
        }
        mate++;
    }
    return dist;
}

/*!
This function searchs dist from the nearest opp
that is nearest from the point
*/
double
Analysis::getDistFromNearestOpp(rcsc::PlayerAgent * agent,
                                      const rcsc::Vector2D &point)
{
    const rcsc::WorldModel & wm = agent->world();
    double dist;
    rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
    const rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromSelf().end();
    dist = (*opp)->pos().dist(point);
    opp++;
    while(opp != end)
    {
        if(dist > (*opp)->pos().dist(point))
        {
            dist = (*opp)->pos().dist(point);
        }
        opp++;
    }
    return dist;
}

/*!
This function counts the number of teammates
in the specific quadrangle area
*/
std::list<double>
Analysis::getOppYlist(rcsc::PlayerAgent * agent,
                            const double &length,
                            const double &width)
{
    const rcsc::WorldModel & wm = agent->world();
    std::list<double> l;
    double half_width, max_dist;
    half_width = width / 2;
    rcsc::Vector2D v(length, half_width);
    max_dist = v.length();
    const rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromSelf().end();
    for(rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
        opp != end;
        opp++)
    {
        v = (*opp)->pos() - wm.self().pos();
        if((*opp)->pos().dist(wm.self().pos()) > max_dist)
        {
            break;
        }
        else if((*opp)->pos().x >= wm.self().pos().x
                && (*opp)->pos().x <= wm.self().pos().x + length
                && v.absY() <= half_width)
        {
            l.push_back((*opp)->pos().y);
        }
    }
    l.sort();
    return l;
}

