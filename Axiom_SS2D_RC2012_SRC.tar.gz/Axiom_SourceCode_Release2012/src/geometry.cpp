/**
 * This file is reached from WrightEagleBASE, it uses for PossibilityModel.cpp
 *
 * */
/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "geometry.h"

//==============================================================================
bool Vector::ApproxEqual(const Vector& a) const
{
    return (fabs(mX-a.X()) < FLOAT_EPS && fabs(mY-a.Y()) < FLOAT_EPS) ? true : false;
}

//==============================================================================
/**
 * ÇóÓëÖ±ÏßÊÇ·ñÏàœ»
 * \param l line
 * \param intersection_dist will be set to the distance from origin to
 *                          intersection point
 * \return if intersect
 */
bool Ray::Intersection(const Line & l, double & intersection_dist) const
{
    double tmp = l.A() * std::cos(mDirection) + l.B() * std::sin(mDirection);// l.B() = -1;
        if (fabs(tmp) < FLOAT_EPS)// Èç¹ûÆœÐÐ;
    {
        return false;
    }
    else
    {
        intersection_dist = (-l.C() - l.A() * mOrigin.X() - l.B() * mOrigin.Y()) / tmp;// ÕýÏÒ¶šÀí;
        return intersection_dist >= 0;
    }
}

/**
 * ÇóÓëÖ±ÏßÊÇ·ñÏàœ»
 * \param l line
 * \return -1000 if not intersect
 *         distance from origin to intersection point otherwise
 */
double Ray::Intersection(const Line & l) const
{
        double dist;
        return Intersection(l, dist) ? dist : -1000.0;
}

/**
 * ÇóÓëÖ±ÏßÊÇ·ñÏàœ»
 * \param l line
 * \param point will be set to the intersection point
 * \return if intersect
 */
bool Ray::Intersection(const Line & l, Vector & point) const
{
    double intersection_dist;
    bool intersect = Intersection(l, intersection_dist);
    if (intersect) {
        point = GetPoint(intersection_dist);
    }
    return intersect;
}

/**
 * ÇóÓëÉäÏßÊÇ·ñÏàœ»
 * \param r ray
 * \param point will be set to the intersection point
 * \return if intersect
 */
bool Ray::Intersection(const Ray &r, Vector & point) const
{
    Line l1(*this);
    Line l2(r);

    if (l1.IsSameSlope(l2) == true)
    {
        return false;
    }

    if (l1.Intersection(l2, point) == false)
    {
        return false;
    }

    return (IsInRightDir(point) == false || r.IsInRightDir(point) == false) ? false : true;
}

/**
 * ÇóÓëÉäÏßÊÇ·ñÏàœ»
 * \param r ray
 * \param intersection_dist will be set to the distance from origin to
 *                          intersection point
 * \return if intersect
 */
bool Ray::Intersection(const Ray &r, double & intersection_dist) const
{
        Vector point;
        bool intersect = Intersection(r, point);
    intersection_dist = point.Dist(mOrigin);
    return intersect;
}

/**
 * µÃµœÒ»ÌõÉäÏßÉÏÀëÕâžöµã×îœüµÄµã
 */
Vector Ray::GetClosestPoint(const Vector& point) const
{
    Line l(*this);
    Vector closest_point = l.GetProjectPoint(point);
    return fabs( rcsc::AngleDeg::normalize_angle ((closest_point - mOrigin).Dir() - mDirection)) < 90? closest_point:this->Origin();
}

/**
 * ÅÐ¶ÏÒ»µãµÄŽ¹×ãÊÇ·ñÔÚÁœµãÖ®Œä
 */
bool Line::IsInBetween(Vector pt, const Vector & end1, const Vector & end2) const
{
// 	Assert(IsOnLine(end1) && IsOnLine(end2));

        pt = GetProjectPoint(pt);
        double dist2 = end1.Dist2(end2);

        return (pt.Dist2(end1) < dist2+FLOAT_EPS && pt.Dist2(end2) < dist2+FLOAT_EPS);
}

Vector Line::Intersection(const Line &l) const
{
        Vector ret;
        if (Intersection(l, ret)) {
                return ret;
        }
        return Vector(0.0, 0.0); //as WE2008
}

/**
 * ÇóÓëÖ±ÏßÊÇ·ñÏàœ»
 * \param l line
 * \param point will be set to the intersection point
 * \return if intersect
 */
bool Line::Intersection(const Line & l, Vector & point) const
{
    if (IsSameSlope(l) == true)
    {
        return false;
    }

    if (mB == 0)
    {
        point =  Vector(-mC / mA, l.GetY(-mC / mA));
    }
    else if (l.mB == 0)
    {
        point =  Vector(-l.C() / l.A(), GetY(-l.C() / l.A()));
    }
    else
    {
        point.SetX((mC * l.B() - mB * l.C()) / (l.A() * mB - mA * l.B()));
        point.SetY(GetY(point.X()));
    }
    return true;
}


/**
 * ÇóÓëÉäÏßÊÇ·ñÏàœ»
 * \param r ray
 * \param point will be set to the intersection point
 * \return if intersect
 */
bool Line::Intersection(const Ray & r, Vector & point) const
{
    Line l(r);

    if (IsSameSlope(l) == true)
    {
        return false;
    }

    if (Intersection(l, point) == false)
    {
        return false;
    }
    else
    {
        return (r.IsInRightDir(point) == true);
    }
}

/**
 * µÃµœÖ±ÏßÉÏÁœµãŒäŸàÀëÕâžöµã×îœüµÄµã
 */
Vector Line::GetClosestPointInBetween(const Vector pt, const Vector end1, const Vector end2) const
{
// 	Assert(IsOnLine(end1) && IsOnLine(end2));

        if (IsInBetween(pt, end1, end2))
                return GetProjectPoint(pt);
        else if (end1.Dist2(pt) < end2.Dist2(pt))
                return end1;
        else
                return end2;
}

Vector Rectangular::Intersection(const Ray &r) const
{
        Vector point;
        bool ret = Intersection(r, point);
        if (ret == false) return r.Origin(); //as WE2008
        return point;
}

//==============================================================================
bool Rectangular::Intersection(const Ray &r, Vector &point) const
{
    if (IsWithin(r.Origin()) == false)
    {
        return false; // do not deal with this condition
    }

    int inter_num = 0;
    Vector inter_point[4]; // there may be 4 intersections
    for (int i = 0; i < 4; ++i)
    {
        Vector p;
        if (GetEdge(i).Intersection(r, p) == true)
        {
                    if (IsWithin(p) == true)
            {
                            inter_point[inter_num++] = p;
                    }
        }
    }

    if (inter_num == 0)
    {
        return false;
    }
    else if (inter_num == 1)
    {
        point = inter_point[0];
        return true; // same slope as one pair of edges
    }
    else if (inter_num >= 2)
    {
            int max_idx     = 0;
        double max_dist = 0.0;
        double dist     = 0.0;
            for (int j = 0; j < inter_num; ++j)
        {
            dist = inter_point[j].Dist2(r.Origin());
                    if (dist >= max_dist)
            {
                            max_idx     = j;
                            max_dist    = dist;
                    }
            }

        point = inter_point[max_idx];
            return true;
    }
    return false;
}

//==============================================================================
int	Circle::Intersection(const Ray &r, double &t1, double &t2, double buffer) const
{
    Vector rel_center = (mCenter - r.Origin()).Rotate(-r.Direction());
    if ((mRadius + buffer) <= fabs(rel_center.Y()))
    {
            return 0;
    }
    else if (mRadius <= fabs(rel_center.Y()))
    {
        t1 = rel_center.X() - 0.13;
        t2 = rel_center.X() + 0.13;
            return 2;
    }
    else
    {
        double dis = sqrt(mRadius * mRadius - rel_center.Y() * rel_center.Y());
        t1 = rel_center.X() - dis;
        t2 = rel_center.X() + dis;
            return 2;
    }
}
