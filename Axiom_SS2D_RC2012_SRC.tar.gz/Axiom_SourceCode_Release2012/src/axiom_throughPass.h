/**
 * axiom_throughPass.h
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Authors : Mohammad Ghazanfari, Omid Shirkhorshidi
 * Copyright 2012
 * Allright Reserved
 */

#ifndef THROUGHPASSS_H
#define THROUGHPASSS_H

#include <cmath>
//#include <vector>

using namespace std;

#include <rcsc/player/player_agent.h>
#include <rcsc/geom/vector_2d.h>
#include <rcsc/geom/rect_2d.h>
#include <rcsc/geom/angle_deg.h>
#include <rcsc/geom/line_2d.h>
#include <rcsc/geom/sector_2d.h>
#include <rcsc/geom/polygon_2d.h>
/*
class PlayerAgent;
class Line2D;
class Vector2D;
class AngleDeg;
class PlayerObject;
class sector_2d;
class rect_2d;
*/



class ThroughPass
{
    public:
    ThroughPass()
    {
      //cout << "\n\nKHEILI JADID 3\n\n ";
      nine_area[0] = rcsc::Rect2D(rcsc::Vector2D(10,-32),rcsc::Vector2D(50,-12));
      ten_area[0] = rcsc::Rect2D(rcsc::Vector2D(10,12),rcsc::Vector2D(50,32));
      eleven_area[0] = rcsc::Rect2D(rcsc::Vector2D(4,-12),rcsc::Vector2D(40,12));
      
      int nine_top_left_x=10,nine_bottom_right_x=20,nine_top_left_y=-32,nine_bottom_right_y=-22;
      
      for(int i=0; i<2 ; i++)
      {
	for(int j=0 ; j<4 ; j++)
	{
	  nine_area[(4*i)+j+1] = rcsc::Rect2D( rcsc::Vector2D(nine_top_left_x+(10*j),nine_top_left_y+(10*i)) , rcsc::Vector2D(nine_bottom_right_x+(10*j),nine_bottom_right_y+(10*i)) );
	}
      }

      
      int ten_top_left_x=10,ten_bottom_right_x=20,ten_top_left_y=12,ten_bottom_right_y=22;
      
      for(int i=0; i<2 ; i++)
      {
	for(int j=0 ; j<4 ; j++)
	{
	  ten_area[(4*i)+j+1] = rcsc::Rect2D( rcsc::Vector2D(ten_top_left_x+(10*j),ten_top_left_y+(10*i)) , rcsc::Vector2D(ten_bottom_right_x+(10*j),ten_bottom_right_y+(10*i)) );
	}
      }
      
      int eleven_top_left_x=4,eleven_bottom_right_x=13,eleven_top_left_y=-12,eleven_bottom_right_y=-4;
      
      for(int i=0; i<3 ; i++)
      {
	for(int j=0 ; j<4 ; j++)
	{
	  eleven_area[(4*i)+j+1] = rcsc::Rect2D( rcsc::Vector2D(eleven_top_left_x+(9*j),eleven_top_left_y+(8*i)) , rcsc::Vector2D(eleven_bottom_right_x+(9*j),eleven_bottom_right_y+(8*i)) );
	}
      }
      
      
   
      
      
    }

    bool reciever_execute( rcsc::PlayerAgent * agent);
    bool sender_execute( rcsc::PlayerAgent * agent);
    rcsc::Vector2D getLocalOffsideLine( int area_number, rcsc::PlayerAgent * agent);
    bool canOppIntercept( rcsc::PlayerAgent * agent , rcsc::Vector2D startPoint , rcsc::Vector2D endPoint , double ballSpeed );
    double getBallSpeed( rcsc::PlayerAgent * agent , rcsc::Vector2D recieverPos , rcsc::Vector2D passPoint);
    //bool isOppInPassSector( rcsc::PlayerAgent * agent , rcsc::Vector2D passPoint , double passSpeed );
    double getSituationScore( rcsc::PlayerAgent * agent , rcsc::Vector2D passPoint );
    //int passSafety( rcsc::PlayerAgent * agent , rcsc::Vector2D startPoint , rcsc::Vector2D endPoint , double ballSpeed );
    int getBallReachCycle ( rcsc::Vector2D startPoint , rcsc::Vector2D endPoint , double ballFirstSpeed );
    //bool amIReciever( rcsc::PlayerAgent * agent );
    
    
  private:
    rcsc::Rect2D nine_area[9];
    rcsc::Rect2D ten_area[9];
    rcsc::Rect2D eleven_area[13];
    int nine_local_offside_line , ten_local_offside_line , eleven_local_offside_line;
   
   
};

#endif
