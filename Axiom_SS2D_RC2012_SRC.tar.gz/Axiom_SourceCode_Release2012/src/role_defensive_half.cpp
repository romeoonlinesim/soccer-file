// -*-c++-*-

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 3, or (at your option)
 any later version.

 This code is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this code; see the file COPYING.  If not, write to
 the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "role_defensive_half.h"

#include "bhv_chain_action.h"
#include "bhv_basic_offensive_kick.h"
#include "bhv_basic_move.h"

#include <rcsc/player/player_agent.h>
#include <rcsc/player/debug_client.h>

#include <rcsc/common/logger.h>
#include <rcsc/common/audio_memory.h>
#include <cmath>
#include <vector>


using namespace rcsc;

const std::string RoleDefensiveHalf::NAME( "DefensiveHalf" );

/*-------------------------------------------------------------------*/
/*!

 */
namespace {
rcss::RegHolder role = SoccerRole::creators().autoReg( &RoleDefensiveHalf::create,
                                                       RoleDefensiveHalf::NAME );
}

/*-------------------------------------------------------------------*/
/*!

 */
bool
RoleDefensiveHalf::execute( PlayerAgent * agent )
{
    bool kickable = agent->world().self().isKickable();
    if ( agent->world().existKickableTeammate()
         && agent->world().teammatesFromBall().front()->distFromBall()
         < agent->world().ball().distFromSelf() )
    {
        kickable = false;
    }
    
    // axiom update WM: {OMID}
    const WorldModel &wm = agent->world();
    std::vector<rcsc::AudioMemory::Player> hear = wm.audioMemory().player();
    bool isNinePosHeard = false;
    bool isTenPosHeard = false;
    bool isElvPosHeard = false;

    if (!hear.empty())
    {


        rcsc::Vector2D nine_heard_pos(-100.0,-100.0);
        rcsc::Vector2D ten_heard_pos(-100.0,-100.0);
        rcsc::Vector2D elv_heard_pos(-100.0,-100.0);
	
	
        for (unsigned int i = 0 ; i < hear.size() ; i ++ )
        {

            int tmm_heard_unum = hear.at(i).unum_;
            rcsc::Vector2D tmm_pos = hear.at(i).pos_;
            int tmm_heard_Body = hear.at(i).body_;

            if ( tmm_heard_unum == -1 || tmm_heard_unum > 11 ||wm.audioMemory().playerTime().cycle() < wm.time().cycle()-3 )
                continue;

            if (tmm_heard_unum == 9 && wm.self().unum() != 9)
            {
                isNinePosHeard = true;
                nine_heard_pos = tmm_pos;
            }
            else if (tmm_heard_unum == 10 && wm.self().unum() != 10)
            {
                isTenPosHeard = true;
                ten_heard_pos = tmm_pos;
            }
            else if (tmm_heard_unum == 11 && wm.self().unum() != 11)
            {
                isElvPosHeard = true;
                elv_heard_pos = tmm_pos;
            }
        }



        const PlayerPtrCont::const_iterator t_end = wm.teammatesFromSelf().end();
        for ( PlayerPtrCont::const_iterator it = wm.teammatesFromSelf().begin(); it != t_end; ++it )
        {
            if ( (*it)->posCount() > 0 )
            {
                if( (*it)->unum() == 9 && isNinePosHeard )
		{
		  (*it)->updateByHear(wm.self().side(),9,false,nine_heard_pos);
		}
		if( (*it)->unum() == 10 && isTenPosHeard )
		{
		  (*it)->updateByHear(wm.self().side(),10,false,ten_heard_pos);
		}
		if( (*it)->unum() == 11 && isElvPosHeard )
		{
		  (*it)->updateByHear(wm.self().side(),11,false,elv_heard_pos);
		}
            }
        }

    }
    // End Of Axiom Updating WM !
    

    if ( kickable )
    {
        doKick( agent );
    }
    else
    {
        doMove( agent );
    }
    
    // Omid View:
   // axiom_view().default_execute(agent);

    return true;
}

/*-------------------------------------------------------------------*/
/*!

 */
void
RoleDefensiveHalf::doKick( PlayerAgent * agent )
{
//    if ( Bhv_ChainAction().execute( agent ) )
//    {
//        dlog.addText( Logger::TEAM,
//                      __FILE__": (execute) do chain action" );
//        agent->debugClient().addMessage( "ChainAction" );
//        return;
//    }

    Bhv_BasicOffensiveKick().execute( agent );
}

/*-------------------------------------------------------------------*/
/*!

 */
void
RoleDefensiveHalf::doMove( PlayerAgent * agent )
{
    Bhv_BasicMove().execute( agent );
}
