// -*-c++-*-

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 3, or (at your option)
 any later version.

 This code is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this code; see the file COPYING.  If not, write to
 the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifndef TOKYOTEC_BHV_BASIC_OFFENSIVE_KICK_H
#define TOKYOTEC_BHV_BASIC_OFFENSIVE_KICK_H

#include <rcsc/player/soccer_action.h>


class Bhv_BasicOffensiveKick
    : public rcsc::SoccerBehavior {
private:

public:

    bool execute( rcsc::PlayerAgent * agent );

    bool defensiveWBdecision( rcsc::PlayerAgent * agent );
    bool offensiveWBdecision( rcsc::PlayerAgent * agent );
    bool highOffensiveWBdecision( rcsc::PlayerAgent * agent );
    bool crossOffensiveWBdecision( rcsc::PlayerAgent * agent );
    bool normalDec(rcsc::PlayerAgent* agent);
    bool analysisDec ( rcsc::PlayerAgent * agent );

    bool riskyShoot ( rcsc::PlayerAgent * agent );	/// in function baraye vaghti ast ke dakhele mohavate jarime opp sholooghe va mikhaym shoot konim!
    bool canRiskyShoot ( rcsc::PlayerAgent * agent );  /// in function check mikonad ke zamane monasebi baraye shoote risky hast ya na!!
    bool isDangerMode ( rcsc::PlayerAgent * agent );	/// this finction checks whether the game is in danger mode for us or not!
    bool dangerModeDecision ( rcsc::PlayerAgent * agent );	/// this function tries to do somthing in order to changing game mode and going to normal decision!!:D
    bool AxiomClearBall ( rcsc::PlayerAgent * agent );
    bool indirectModeShoot ( rcsc::PlayerAgent * agent );    /// in function zamani call mishavad ke dar indirect set_play avvalin pass dade shode va mikhahim shoot konim too goal!!

    bool oneToOneToGoalie ( rcsc::PlayerAgent * agent );

    bool isBackDribble( rcsc::PlayerAgent * agent );
};

#endif
