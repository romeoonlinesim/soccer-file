
/*
Axiom Shoot
Author: Mohammad Mahdavi, Mostafa Zamani
M_Mahdavi@comp.iust.ac.ir
ComenMahdavi@gmail.com
Copyright 2012, Allrights Reserved.
*/


#include <rcsc/action/body_smart_kick.h>
#include <rcsc/geom/vector_2d.h>
#include <rcsc/geom/line_2d.h>
#include <rcsc/geom/sector_2d.h>
#include <rcsc/geom/segment_2d.h>
#include <rcsc/action/neck_turn_to_point.h>
#include <rcsc/common/server_param.h>

#include "axiom_shoot.h"

namespace rcsc {

bool
axiom_shoot::execute( PlayerAgent * agent )
{
    const double MIN_X = 20;
    const int MAX_CYCLE = 5;
    const Vector2D T1(52.5,-6.7);
    const Vector2D T2(52.5,6.7);

    double w1, w2, w3, w4;
    double a, d, o1, o2;

    Vector2D self_pos = agent->world().self().pos();
    const rcsc::PlayerObject * opp_goalie = agent->world().getOpponentGoalie();

    if ( self_pos.x < MIN_X || !opp_goalie || opp_goalie->posCount() > MAX_CYCLE || self_pos.absY() > 20 ) return false;

    Line2D l(self_pos,self_pos.th());

    if ( (opp_goalie->pos() - self_pos).th().degree() - (T1 - self_pos).th().degree()  > (T2 - self_pos).th().degree() - (opp_goalie->pos() - self_pos).th().degree() )
    {
        l = Line2D::angle_bisector( self_pos, (T1 - self_pos).th(), (opp_goalie->pos() - self_pos).th() );
        a = (opp_goalie->pos() - self_pos).th().degree() - (T1 - self_pos).th().degree();
    }
    else
    {
        l = Line2D::angle_bisector( self_pos, (opp_goalie->pos() - self_pos).th(), (T2 - self_pos).th() );
        a = (T2 - self_pos).th().degree() - (opp_goalie->pos() - self_pos).th().degree();
    }

    Line2D goal_line( Vector2D(52.5,-10), Vector2D(52.5,10));
    Vector2D inter = l.intersection(goal_line);

    if ( inter.y > 6.7 || inter.y < -6.7 )
        return false;


    d = self_pos.dist(inter);
    o1 = 1;
    o2 = 10;

    std::vector< rcsc::PlayerObject* > opponents;
    rcsc::PlayerPtrCont::const_iterator end = agent->world().opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator it = agent->world().opponentsFromSelf().begin();
            it != end;
            ++it )
    {
        if ( (*it)->posCount() > MAX_CYCLE || (*it)->goalie() )
            continue;

        if ( (*it)->pos().x > self_pos.x && l.dist((*it)->pos()) < o2 )
        {
            o2 = l.dist((*it)->pos());
            o1 = (*it)->pos().dist(self_pos);

        }
    }

    w1 = 10;
    w2 = 1;
    w3 = 1;
    w4 = 5;

    double f = ( w1 * a + w2 * o2 ) / ( w3 * d + w4 * o1 );

   if ( f >= 20 )
   {
     Body_SmartKick( inter, rcsc::ServerParam::i().ballSpeedMax(), rcsc::ServerParam::i().ballSpeedMax() * 0.96, 2 ).execute( agent );
     agent->setNeckAction( new rcsc::Neck_TurnToPoint( agent->world().ball().pos() ) );
     std::cout<<"cycle "<<agent->world().time().cycle()<<"\nGA SHOOOOOT! \n------------------------------------\n";
     return true;
   }
     return false;
}

}
