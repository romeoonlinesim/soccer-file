
/*
Axiom Shoot
Author: Mohammad Mahdavi, Mostafa Zamani
M_Mahdavi@comp.iust.ac.ir
ComenMahdavi@gmail.com
Copyright 2012, Allrights Reserved.
*/

#ifndef AXIOM_SHOOT_H
#define AXIOM_SHOOT_H

#include <rcsc/player/player_agent.h>


namespace rcsc {

class axiom_shoot
{
private:

public:

    axiom_shoot()
      { }

    bool execute( PlayerAgent * agent );
};

}

#endif
