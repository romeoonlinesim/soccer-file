#include "axiom_view.h"
#include "sample_player.h"
#include <rcsc/action/neck_turn_to_point.h>
#include <rcsc/action/view_normal.h>
#include <rcsc/action/view_change_width.h>
#include <rcsc/player/audio_sensor.h>
#include <rcsc/player/free_message.h>
#include <rcsc/player/freeform_parser.h>
#include <rcsc/action/body_turn_to_point.h>

bool axiom_view::default_execute(PlayerAgent* agent)
{
    const rcsc::WorldModel & wm = agent->world();

    ///////////  Center FW     //////////
    if (wm.self().unum() == 11)
    {

        //// Omid Default View ::: ////////////////////////


        const rcsc::WorldModel & wm = agent->world();
        bool isNineRequesting = false;
        bool isTenRequesting = false;
        bool someOneRequesting = false;

        std::vector<rcsc::AudioMemory::Player> hear = wm.audioMemory().player();
	
	rcsc::Vector2D nine_thp_rec_pos(-100.0,-100.0);
        rcsc::Vector2D ten_thp_rec_pos(-100.0,-100.0);
        rcsc::Vector2D elv_thp_rec_pos(-100.0,-100.0);

        if (!(hear.empty() || wm.audioMemory().playerTime().cycle() < wm.time().cycle()-5))
        {

            for (unsigned int i = 0 ; i < hear.size() ; i ++ )
            {

                int thp_rec_unum = hear.at(i).unum_;
                rcsc::Vector2D thp_rec_pos = hear.at(i).pos_;

                if ( thp_rec_unum == -1 || thp_rec_unum > 11 )
                    continue;

                if (thp_rec_unum == 9)
                {
                    isNineRequesting = true;
                    nine_thp_rec_pos = thp_rec_pos;
                }
                else if (thp_rec_unum == 10)
                {
                    isTenRequesting = true;
                    ten_thp_rec_pos = thp_rec_pos;
                }

            }



            if (isNineRequesting || isTenRequesting)
            {
                someOneRequesting = true;
            }
        }

        int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;
        if (wm.self().pos().x > 0 && wm.self().pos().x < 35 && fabs(wm.self().pos().y) < 15 ) // Too Zamine Harif && Vasataye zamin && ghabl az mohavate jarime
        {
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(22,-26)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 0 \n\n" ;
                break;
            case (1) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 1 \n\n" ;
                break;
            case (2) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(22,26)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 2 \n\n" ;
                break;
            case (3) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );

                if ( wm.self().distFromBall() < 3 && someOneRequesting )
                {
                    if (isNineRequesting)
                    {
                        //agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
			//agent->doChangeView(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)); // {OMID}
			agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW));
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(ten_thp_rec_pos.x +15 , ten_thp_rec_pos.y ) ) );
                    }
                    else if ( isTenRequesting )
                    {
                        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(ten_thp_rec_pos.x +15 , ten_thp_rec_pos.y ) ) );
                    }

                }


                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 3 \n\n" ;
                break;
            default :
                break;
            }



        }




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (wm.self().pos().x < 2 && wm.self().pos().x > -35  )           // Too Zamine khodemun  && ghabl az mohavate jarime
        {
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-5,-26)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 0 \n\n" ;
                break;
            case (1) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(+30.0,-20.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 1 \n\n" ;
                break;
            case (2) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(+30.0,20.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 2 \n\n" ;
                break;
            case (3) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-5,26)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 3 \n\n" ;
                break;
            default :
                break;
            }
            /////////////

        }

        ////////////////////////////////////////////////////////// Too mohavate jarimeye harif ::
        if (wm.self().pos().x > 35  && fabs(wm.self().pos().y) < 20 )
        {
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );

                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 0 \n\n" ;
                break;
            case (1) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 1 \n\n" ;
                break;
            case (2) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-52.0,0.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 2 \n\n" ;
                break;
            case (3) :
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 3 \n\n" ;
                break;
            default :
                break;
            }

            if (wm.self().distFromBall() < 8 && !(wm.self().isKickable()) && wm.existKickableOpponent() && wm.self().distFromBall() > 2  )
            {
                if (wm.ball().pos().x > wm.self().pos().x && (Neck_Cycle_mod4%2) == 0)
                {

                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                }

            }

        }


        // GLOBALLY !!! :

        if (wm.ball().posCount() >=3)
        {
            agent->setViewAction(new rcsc::View_Normal());
            agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
        }


//// END OF Omid Default View ::: ////////////////////////





        /// indirect mode view
        if ( agent->world().self().pos().x >= 33 && ((SamplePlayer*) agent)->indirect_mode && agent->world().time().cycle() % 2 )
        {
            agent->setNeckAction(new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52,0)));
            //agent->setViewAction(new rcsc::View_Normal);
        }



	agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW)); // {OMID}
        return true;
    }




    ///////////  Side FW     //////////
    if (wm.self().unum() == 9 || wm.self().unum() == 10 )
    {

        //Omid View !!!!

        bool isElevenRequesting = false;
        bool isOtherSideFWRequesting = false;
        bool someOneRequesting = false;

        rcsc::Vector2D otherSide_thp_rec_pos(-100.0,-100.0);
        rcsc::Vector2D elv_thp_rec_pos(-100.0,-100.0);


        std::vector<rcsc::AudioMemory::Player> hear = wm.audioMemory().player();

        if (!(hear.empty() || wm.audioMemory().playerTime().cycle() < wm.time().cycle()-5))
        {
            

        for (unsigned int i = 0 ; i < hear.size() ; i ++ )
        {

            int thp_rec_unum = hear.at(i).unum_;
            rcsc::Vector2D thp_rec_pos = hear.at(i).pos_;

            if ( thp_rec_unum == -1 || thp_rec_unum > 11 )
                continue;

            if (thp_rec_unum == 9  && wm.self().unum() == 10)
            {
                isOtherSideFWRequesting = true;
                otherSide_thp_rec_pos = thp_rec_pos;
            }
            else if (thp_rec_unum == 10 && wm.self().unum() == 9)
            {
                isOtherSideFWRequesting = true;
                otherSide_thp_rec_pos = thp_rec_pos;
            }
            else if (thp_rec_unum == 11)
            {
                isElevenRequesting = true;
                elv_thp_rec_pos = thp_rec_pos;
            }

        }
	}




        int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;

        if (wm.self().pos().x > -9 ) // && ( wm.self().pos().dist(wm.ball().pos()) ) > 2   )
        {
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(6.0,0.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 0 \n\n" ;
                break;
            case (1) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );

                if ( wm.self().distFromBall() < 3 && someOneRequesting )
                {
                    if (isOtherSideFWRequesting)
                    {
                        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(otherSide_thp_rec_pos.x +15 , otherSide_thp_rec_pos.y ) ) );
                    }
                    else if ( isElevenRequesting )
                    {
                        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(elv_thp_rec_pos.x +10 , elv_thp_rec_pos.y ) ) );
                    }

                }
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 1 \n\n" ;
                break;
            case (2) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(35,0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 2 \n\n" ;
                break;
            case (3) :
                agent->setViewAction(new rcsc::View_Normal());
                if (wm.self().pos().y > 0)
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(44,wm.self().pos().y-5.0)) );
                else
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(44,wm.self().pos().y+5.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 3 \n\n" ;
                break;
            default :
                break;
            }
        }

        else
        {
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-20.0,0.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 0 \n\n" ;
                break;
            case (1) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(10.0,0.0)) );

                if ( wm.self().distFromBall() < 3 && someOneRequesting )
                {
                    if (isOtherSideFWRequesting)
                    {
                        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(otherSide_thp_rec_pos.x +15 , otherSide_thp_rec_pos.y ) ) );
                    }
                    else if ( isElevenRequesting )
                    {
                        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(elv_thp_rec_pos.x +10 , elv_thp_rec_pos.y ) ) );
                    }

                }
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 1 \n\n" ;
                break;
            case (2) :
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(35,0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 2 \n\n" ;
                break;
            case (3) :
                agent->setViewAction(new rcsc::View_Normal());
                if (wm.self().pos().y > 0)
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-44,wm.self().pos().y-5.0)) );
                else
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-44,wm.self().pos().y+5.0)) );
                //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 3 \n\n" ;
                break;
            default :
                break;
            }
        }
        //End OMID

        /// indirect mode view
        if ( agent->world().self().pos().x >= 33 && ((SamplePlayer*) agent)->indirect_mode && agent->world().time().cycle() % 2 )
        {
            agent->setNeckAction(new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52,0)));
            agent->setViewAction(new rcsc::View_Normal());
        }



	agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW)); // {OMID}
        return true;
    }






    ///////////  Offensive Half    //////////
    if (wm.self().unum() == 7 || wm.self().unum() == 8 )
    {

        // Omid Default View

        int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;
        const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();



        if (true)
        {
            agent->setViewAction(new rcsc::View_Normal());
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :


                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                        opp != opp_end;
                        ++ opp )
                {
                    if ( (*opp)->posCount() >= 5)
                    {
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                        break;
                    }
                }

                break;


            case (1) :
                if (wm.self().pos().x < -23)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-32.0,-23.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(35.0,-25.0)) );
                }
                break;


            case (2) :

                if (wm.self().pos().x < -23)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(+52.0,0.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(+52.0,0.0)) );
                }
                break;


            case (3) :
                if (wm.self().pos().x < -23)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-32.0,+23.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(35.0,+25.0)) );
                }
                break;

            default :
                break;
            }



            if (wm.ball().pos().x < -20)
                agent->setViewAction(new rcsc::View_Normal());
            else if (wm.ball().pos().x > 30 && wm.self().pos().x < 10 && wm.self().distFromBall() > 2)
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));

            if (wm.self().distFromBall() < 13 && wm.existKickableOpponent() && !(wm.self().isKickable()) && wm.self().distFromBall() > 2 )
            {
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().distFromBall() < 8 && !(wm.self().isKickable()) && wm.self().distFromBall() > 1 )
            {
                if (wm.ball().pos().x < wm.self().pos().x)
                {
                    if ((Neck_Cycle_mod4%2) == 1)
                    {
                        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                    }
                    else
                    {
                        agent->setViewAction(new rcsc::View_Normal());
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(0.0,0.0)) );
                    }

                }
                else
                {
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                }
            }

            if (wm.self().pos().x < -35 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 1 && !(wm.self().isKickable()) )
            {
                if (Neck_Cycle_mod4 == 1)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,+18.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,-18.0)) );
                }
            }

            if (wm.self().distFromBall() < 8 && wm.existKickableOpponent() && wm.self().distFromBall() > 1)
            {
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }
            // Toye zamine Harif ::

            const rcsc::WorldModel & wm = agent->world();
            bool isNineRequesting = false;
            bool isTenRequesting = false;
            bool isElevenRequesting = false;
            bool someOneRequesting = false;

            std::vector<rcsc::AudioMemory::Player> hear = wm.audioMemory().player();
	    
	    rcsc::Vector2D nine_thp_rec_pos(-100.0,-100.0);
            rcsc::Vector2D ten_thp_rec_pos(-100.0,-100.0);
            rcsc::Vector2D elv_thp_rec_pos(-100.0,-100.0);

            if (!(hear.empty() || wm.audioMemory().playerTime().cycle() < wm.time().cycle()-5))
            {
    

            for (unsigned int i = 0 ; i < hear.size() ; i ++ )
            {

                int thp_rec_unum = hear.at(i).unum_;
                rcsc::Vector2D thp_rec_pos = hear.at(i).pos_;

                if ( thp_rec_unum == -1 || thp_rec_unum > 11 )
                    continue;

                if (thp_rec_unum == 9)
                {
                    isNineRequesting = true;
                    nine_thp_rec_pos = thp_rec_pos;
                }
                else if (thp_rec_unum == 10)
                {
                    isTenRequesting = true;
                    ten_thp_rec_pos = thp_rec_pos;
                }
                else if (thp_rec_unum == 11)
                {
                    isElevenRequesting = true;
                    elv_thp_rec_pos = thp_rec_pos;
                }
            }

            if (isNineRequesting || isTenRequesting || isElevenRequesting)
            {
                someOneRequesting = true;
            }
	    }

            //int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;
            if (wm.self().pos().x > 0 && wm.self().pos().x < 35 && fabs(wm.self().pos().y) < 20 ) // Too Zamine Harif && Vasataye zamin && ghabl az mohavate jarime
            {
                switch ( Neck_Cycle_mod4 )
                {
                case (0) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(22,-26)) );
                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 0 \n\n" ;
                    break;
                case (1) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 1 \n\n" ;
                    break;
                case (2) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(22,26)) );
                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 2 \n\n" ;
                    break;
                case (3) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );

                    if ( wm.self().distFromBall() < 3 && someOneRequesting )
                    {
                        if (isNineRequesting)
                        {
                            agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(nine_thp_rec_pos.x +15 , nine_thp_rec_pos.y ) ) );
                        }
                        else if ( isTenRequesting )
                        {
                            agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(ten_thp_rec_pos.x +15 , ten_thp_rec_pos.y ) ) );
                        }
                        else if (isElevenRequesting)
                        {
                            agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(elv_thp_rec_pos.x +15 , elv_thp_rec_pos.y ) ) );
                        }

                    }

                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 3 \n\n" ;
                    break;
                default :
                    break;
                }

            }

        }

        ///////////////End Zamine Harif


        if (one2one_checker(agent)  && Neck_Cycle_mod4 %2 == 1)
        {
            agent->setViewAction(new rcsc::View_Normal());
            agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
        }



        if (wm.ball().posCount() >=3)
        {
            agent->setViewAction(new rcsc::View_Normal());
            agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
        }


        ///////////////////////////////////////////////////  END View By Omid & Alireza //////////////////////////

        /// indirect mode view
        if ( agent->world().self().pos().x >= 33 && ((SamplePlayer*) agent)->indirect_mode && agent->world().time().cycle() % 2 )
        {
            agent->setNeckAction(new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52,0)));
            agent->setViewAction(new rcsc::View_Normal);
        }

        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW)); // {OMID}
        return true;
    }




    ///////////  Deffensive Half     //////////
    if (wm.self().unum() == 6 )
    {

        int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;
        const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
        //const rcsc::WorldModel & wm = agent->world();


        if (true)
        {
            agent->setViewAction(new rcsc::View_Normal());
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :

                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                        opp != opp_end;
                        ++ opp )
                {
                    if ( (*opp)->posCount() >= 5)
                    {
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                        break;
                    }
                }

                break;


            case (1) :
                if (wm.self().pos().x < -20)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-32.0,-23.0)) );
                }
                else
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(9.0,-23.0)) );
                }
                break;


            case (2) :

                if (wm.self().pos().x < -20)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(+52.0,0.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(+52.0,0.0)) );
                }
                break;


            case (3) :
                if (wm.self().pos().x < -20)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-32.0,+23.0)) );
                }
                else
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(9.0,+23.0)) );
                }
                break;

            default :
                break;
            }



            if (wm.ball().pos().x < -20 )
                agent->setViewAction(new rcsc::View_Normal() );
            else if (wm.ball().pos().x > 20 && wm.self().distFromBall() > 15)
            {
                if (wm.time().cycle() % 2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal() );
            }

            if (wm.self().distFromBall() < 13 && wm.existKickableOpponent() && !(wm.self().isKickable()) && wm.self().distFromBall() > 2)
            {
                if (wm.time().cycle() %2 ==1 )
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal() );

                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().distFromBall() < 8 && !(wm.self().isKickable()) && wm.self().distFromBall() > 2 )
            {
                if (wm.ball().pos().x < wm.self().pos().x)
                {
                    if ((Neck_Cycle_mod4%2) == 1)
                    {
                        //agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setViewAction(new rcsc::View_Normal() );
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                    }
                    else
                    {
                        agent->setViewAction(new rcsc::View_Normal());
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(0.0,0.0)) );
                    }

                }
                else
                {
                    if (wm.time().cycle() %2 == 1)
                        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                    else
                        agent->setViewAction(new rcsc::View_Normal());

                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                }
            }

            if (wm.self().pos().x < -35 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 1 && !(wm.self().isKickable()) )
            {
                if (Neck_Cycle_mod4 == 1)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,+18.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,-18.0)) );
                }
            }

            if (wm.self().distFromBall() < 8 && wm.existKickableOpponent() && wm.self().distFromBall() > 2)
            {
                if (wm.time().cycle() % 2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal());

                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }


            // Toye zamine Harif ::

            const rcsc::WorldModel & wm = agent->world();
            bool isNineRequesting = false;
            bool isTenRequesting = false;
            bool isElevenRequesting = false;
            bool someOneRequesting = false;

            std::vector<rcsc::AudioMemory::Player> hear = wm.audioMemory().player();
	    
	                    

            rcsc::Vector2D nine_thp_rec_pos(-100.0,-100.0);
            rcsc::Vector2D ten_thp_rec_pos(-100.0,-100.0);
            rcsc::Vector2D elv_thp_rec_pos(-100.0,-100.0);

            if (!(hear.empty() || wm.audioMemory().playerTime().cycle() < wm.time().cycle()-5))
            {


            for (unsigned int i = 0 ; i < hear.size() ; i ++ )
            {

                int thp_rec_unum = hear.at(i).unum_;
                rcsc::Vector2D thp_rec_pos = hear.at(i).pos_;

                if ( thp_rec_unum == -1 || thp_rec_unum > 11 )
                    continue;

                if (thp_rec_unum == 9)
                {
                    isNineRequesting = true;
                    nine_thp_rec_pos = thp_rec_pos;
                }
                else if (thp_rec_unum == 10)
                {
                    isTenRequesting = true;
                    ten_thp_rec_pos = thp_rec_pos;
                }
                else if (thp_rec_unum == 11)
                {
                    isElevenRequesting = true;
                    elv_thp_rec_pos = thp_rec_pos;
                }
            }

            if (isNineRequesting || isTenRequesting || isElevenRequesting)
            {
                someOneRequesting = true;
            }
	    }

            //int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;
            if (wm.self().pos().x > 0 && wm.self().pos().x < 35 && fabs(wm.self().pos().y) < 20 ) // Too Zamine Harif && Vasataye zamin && ghabl az mohavate jarime
            {
                switch ( Neck_Cycle_mod4 )
                {
                case (0) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(22,-26)) );
                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 0 \n\n" ;
                    break;
                case (1) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 1 \n\n" ;
                    break;
                case (2) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(22,26)) );
                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 2 \n\n" ;
                    break;
                case (3) :
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );

                    if ( wm.self().distFromBall() < 3 && someOneRequesting )
                    {
                        if (isNineRequesting)
                        {
                            agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(nine_thp_rec_pos.x +15 , nine_thp_rec_pos.y ) ) );
                        }
                        else if ( isTenRequesting )
                        {
                            agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(ten_thp_rec_pos.x +15 , ten_thp_rec_pos.y ) ) );
                        }
                        else if (isElevenRequesting)
                        {
                            agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( rcsc::Vector2D(elv_thp_rec_pos.x +15 , elv_thp_rec_pos.y ) ) );
                        }

                    }

                    //std::cout << "Cycle : " << wm.time().cycle() << " The MOD4 is : 3 \n\n" ;
                    break;
                default :
                    break;
                }

            }



            ///////////////End Zamine Harif

            if (one2one_checker(agent)  && Neck_Cycle_mod4 %2 == 1)
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
            }



            if (wm.ball().posCount() >=3)
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }
        }

        ///////////////////////////////////////////////////  END View By Omid & Alireza //////////////////////////

        /// indirect mode view
        if ( agent->world().self().pos().x >= 33 && ((SamplePlayer*) agent)->indirect_mode && agent->world().time().cycle() % 2 )
        {
            agent->setNeckAction(new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52,0)));
            agent->setViewAction(new rcsc::View_Normal());
        }

        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW)); // {OMID}
        return true;
    }



    ///////////  Side Back     //////////
    if (wm.self().unum() == 4 || wm.self().unum() == 5 )
    {

        // Omid & Alireza : View For SETPlayKICKIN !!!!! ///////////////////////////
        //const rcsc::WorldModel & wm = agent->world();
        int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;
        const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();



        if (true)
        {
            agent->setViewAction(new rcsc::View_Normal());
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :


                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                        opp != opp_end;
                        ++ opp )
                {
                    if ( (*opp)->posCount() >= 5)
                    {
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                        break;
                    }
                }

                break;


            case (1) :
                if (wm.self().pos().x < -14)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-4.0,30.0)) );
                }
                else
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(17.0,-33.0)) );
                }
                break;


            case (2) :

                if (wm.self().pos().x < -14)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(0.0,(wm.self().pos().y)*0.75) ) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(15.0,(wm.self().pos().y)*0.75)) );
                }
                break;


            case (3) :
                if (wm.self().pos().x < -14)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-4.0,-30.0)) );
                }
                else
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(17.0,+33.0)) );
                }
                break;

            default :
                break;
            }



            if (wm.ball().pos().x < -20)
                agent->setViewAction(new rcsc::View_Normal());
            else if (wm.ball().pos().x > 20 && wm.self().distFromBall() > 15)
            {
                if (wm.time().cycle() % 2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal() );
            }

            if (wm.self().distFromBall() < 13 && wm.existKickableOpponent() && !(wm.self().isKickable()) && wm.self().distFromBall() > 2 )
            {
                if (wm.time().cycle() % 2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().distFromBall() < 8 && !(wm.self().isKickable()) )
            {

                if (wm.ball().pos().x < wm.self().pos().x)
                {
                    if ((Neck_Cycle_mod4%2) == 1)
                    {
                        //agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setViewAction(new rcsc::View_Normal());
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );

                        for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                                opp != opp_end;
                                ++ opp )
                        {
                            if ( (*opp)->posCount() >= 3)
                            {
                                agent->setViewAction(new rcsc::View_Normal());
                                agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                                break;
                            }
                        }
                    }
                    else
                    {
                        if ( wm.self().pos().x < -9)
                        {
                            agent->setViewAction(new rcsc::View_Normal());
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(0.0,0.0)) );
                        }
                        else
                        {
                            for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                                    opp != opp_end;
                                    ++ opp )
                            {
                                if ( (*opp)->posCount() >= 3)
                                {
                                    agent->setViewAction(new rcsc::View_Normal());
                                    agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                                    break;
                                }
                            }
                        }


                    }

                }
                else
                {
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );

                    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                            opp != opp_end;
                            ++ opp )
                    {
                        if ( (*opp)->posCount() >= 3 && (*opp)->distFromSelf() < 10)
                        {
                            agent->setViewAction(new rcsc::View_Normal());
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                            break;
                        }
                    }


                }
            }

            if (wm.self().pos().x < -35 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 1 && !(wm.self().isKickable()) )
            {
                if (Neck_Cycle_mod4 == 1)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,+18.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,-18.0)) );
                }
            }

            if (wm.self().distFromBall() < 8 && wm.existKickableOpponent()  && wm.self().distFromBall() > 2)
            {
                if (wm.time().cycle() %2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal());

                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }


            if (wm.self().pos().x < -36 && Neck_Cycle_mod4%2 == 1)
            {
                for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                        opp != opp_end;
                        ++ opp )
                {
                    if ( (*opp)->posCount() >= 2 && (*opp)->distFromSelf() < 10)
                    {
                        agent->setViewAction(new rcsc::View_Normal());
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                        break;
                    }
                }
            }


            ///////////virtual goalie view//////////
            if (wm.self().pos().x < -47 && ( (wm.self().pos().y > -1 && wm.self().unum() ==5) || (wm.self().pos().y < +1 && wm.self().unum() ==4) ) )
            {
                if (wm.time().cycle()%2)
                {
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );

                    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                            opp != opp_end;
                            ++ opp )
                    {
                        if ( (*opp)->posCount() >= 3)
                        {
                            agent->setViewAction(new rcsc::View_Normal());
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                            break;
                        }
                    }
                }
            }
            //////////////////////////////////





            if (wm.ball().posCount() >=3)
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

        }

        ///////////////////////////////////////////////////  END View By Omid & Alireza //////////////////////////

//

        /// indirect mode view
        if ( agent->world().self().pos().x >= 33 && ((SamplePlayer*) agent)->indirect_mode && agent->world().time().cycle() % 2 )
        {
            agent->setNeckAction(new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52,0)));
            agent->setViewAction(new rcsc::View_Normal);
        }

        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW)); // {OMID}
        return true;
    }



    ///////////  Center Back     //////////
    if (wm.self().unum() == 2 || wm.self().unum() == 3 )
    {

        // Omid & Alireza : View For SETPlayKICKIN !!!!! ///////////////////////////
        //const rcsc::WorldModel & wm = agent->world();
        int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;
        const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();



        if (true)
        {
            agent->setViewAction(new rcsc::View_Normal());
            switch ( Neck_Cycle_mod4 )
            {
            case (0) :


                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                        opp != opp_end;
                        ++ opp )
                {
                    if ( (*opp)->posCount() >= 5)
                    {
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                        break;
                    }
                }

                break;


            case (1) :
                if (wm.self().pos().x < -14)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-4.0,30.0)) );
                }
                else
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(17.0,-33.0)) );
                }
                break;


            case (2) :

                if (wm.self().pos().x < -14)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(0.0,(wm.self().pos().y)*0.75) ) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(15.0,(wm.self().pos().y)*0.75)) );
                }
                break;


            case (3) :
                if (wm.self().pos().x < -14)
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-4.0,-30.0)) );
                }
                else
                {
                    //agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(17.0,+33.0)) );
                }
                break;

            default :
                break;
            }



            if (wm.ball().pos().x < -20)
                agent->setViewAction(new rcsc::View_Normal());
            else if (wm.ball().pos().x > 20 && wm.self().distFromBall() > 15)
            {
                if (wm.time().cycle() % 2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal() );
            }

            if (wm.self().distFromBall() < 13 && wm.existKickableOpponent() && !(wm.self().isKickable()) && wm.self().distFromBall() > 2 )
            {
                if (wm.time().cycle() % 2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().distFromBall() < 8 && !(wm.self().isKickable()) )
            {

                if (wm.ball().pos().x < wm.self().pos().x)
                {
                    if ((Neck_Cycle_mod4%2) == 1)
                    {
                        //agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                        agent->setViewAction(new rcsc::View_Normal());
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );

                        for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                                opp != opp_end;
                                ++ opp )
                        {
                            if ( (*opp)->posCount() >= 3)
                            {
                                agent->setViewAction(new rcsc::View_Normal());
                                agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                                break;
                            }
                        }
                    }
                    else
                    {
                        if ( wm.self().pos().x < -9)
                        {
                            agent->setViewAction(new rcsc::View_Normal());
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(0.0,0.0)) );
                        }
                        else
                        {
                            for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                                    opp != opp_end;
                                    ++ opp )
                            {
                                if ( (*opp)->posCount() >= 3)
                                {
                                    agent->setViewAction(new rcsc::View_Normal());
                                    agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                                    break;
                                }
                            }
                        }


                    }

                }
                else
                {
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );

                    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                            opp != opp_end;
                            ++ opp )
                    {
                        if ( (*opp)->posCount() >= 3 && (*opp)->distFromSelf() < 10)
                        {
                            agent->setViewAction(new rcsc::View_Normal());
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                            break;
                        }
                    }


                }
            }

            if (wm.self().pos().x < -35 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 0 && !(wm.self().isKickable()) )
            {
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

            if (wm.self().pos().x < -49 && (Neck_Cycle_mod4%2) == 1 && !(wm.self().isKickable()) )
            {
                if (Neck_Cycle_mod4 == 1)
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,+18.0)) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-21.0,-18.0)) );
                }
            }

            if (wm.self().distFromBall() < 8 && wm.existKickableOpponent()  && wm.self().distFromBall() > 2)
            {
                if (wm.time().cycle() %2 == 1)
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                else
                    agent->setViewAction(new rcsc::View_Normal());

                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }


            if (wm.self().pos().x < -36 && Neck_Cycle_mod4%2 == 1)
            {
                for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                        opp != opp_end;
                        ++ opp )
                {
                    if ( (*opp)->posCount() >= 2 && (*opp)->distFromSelf() < 10)
                    {
                        agent->setViewAction(new rcsc::View_Normal());
                        agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                        break;
                    }
                }
            }


            ///////////virtual goalie view//////////
            if (wm.self().pos().x < -47 && ( (wm.self().pos().y > -1 && wm.self().unum() ==5) || (wm.self().pos().y < +1 && wm.self().unum() ==4) ) )
            {
                if (wm.time().cycle()%2)
                {
                    agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
                }
                else
                {
                    agent->setViewAction(new rcsc::View_Normal());
                    agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );

                    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                            opp != opp_end;
                            ++ opp )
                    {
                        if ( (*opp)->posCount() >= 3)
                        {
                            agent->setViewAction(new rcsc::View_Normal());
                            agent->setNeckAction( new rcsc::Neck_TurnToPoint( (*opp)->pos() ) );
                            break;
                        }
                    }
                }
            }
            //////////////////////////////////





            if (wm.ball().posCount() >=3)
            {
                agent->setViewAction(new rcsc::View_Normal());
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }

        }

        ///////////////////////////////////////////////////  END View By Omid & Alireza //////////////////////////

//

        /// indirect mode view
        if ( agent->world().self().pos().x >= 33 && ((SamplePlayer*) agent)->indirect_mode && agent->world().time().cycle() % 2 )
        {
            agent->setNeckAction(new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52,0)));
            agent->setViewAction(new rcsc::View_Normal);
        }


        agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW)); // {OMID}
        return true;
    }



    //////////    GOALIE   //////////
    if (wm.self().unum() == 1 )
    {

        //Omid !!!
        if (agent->world().ball().pos().x <= -20 && wm.self().distFromBall() < 10)
        {
            agent->setViewAction(new rcsc::View_Normal());
            //agent->setNeckAction( new rcsc::Neck_TurnToPoint(agent->world().ball().pos()) );
        }
        else 
	   agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
	

        if (agent->world().ball().pos().x <= -30 )
        {
            if (agent->world().time().cycle() %2 == 1)
            {
                agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)));
            }
            else
            {
                agent->setViewAction(new rcsc::View_Normal());
            }

            agent->setNeckAction( new rcsc::Neck_TurnToPoint(agent->world().ball().pos()) );

        }

        if (agent->world().ball().posCount() >=2)
        {
            agent->setViewAction(new rcsc::View_ChangeWidth(rcsc::ViewWidth::NARROW));
            agent->setNeckAction( new rcsc::Neck_TurnToPoint(agent->world().ball().pos()) );
        }
        //End OMID

        //agent->doChangeView(rcsc::ViewWidth(rcsc::ViewWidth::NARROW)); // {OMID}
        return true;
    }


    return false;
}



bool axiom_view::one2one_checker(PlayerAgent* agent)
{
    double MIN_X = 8;
    double dir_ther = 11.0;
    const WorldModel & wm = agent->world();
    if ( ( agent->world().self().unum() == 9 || agent->world().self().unum() == 10 ) )// && ! ( wm.opponentTeamName() == "Tempux2D" || wm.opponentTeamName() == "tempux2d" ||  wm.opponentTeamName() == "TempuX2D" ||  wm.opponentTeamName() == "tempux2D" ||  wm.opponentTeamName() == "TEMPUX2D" ||  wm.opponentTeamName() == "Tempux" ||  wm.opponentTeamName() == "tempux" ||  wm.opponentTeamName() == "TempuX" ) )
        MIN_X = 22;

    if ( agent->world().self().pos().x < MIN_X || (wm.self().pos().x > 44  && fabs(wm.self().pos().y) < 12  )  )
        return false;

    rcsc::Vector2D goal( 52.0, 0.0 );

    if ( agent->world().self().unum() == 9 )
        goal = rcsc::Vector2D(46.0, -12.0);
    else if (agent->world().self().unum() == 10)
        goal = rcsc::Vector2D(46.0, 12.0);

    rcsc::Vector2D l( goal - agent->world().ball().pos() );

    if (wm.self().pos().x >= 35)
    {
        dir_ther = 5.0;
    }

    rcsc::Sector2D s( agent->world().ball().pos(), 0.1 , 20 , l.th() - dir_ther, l.th() + dir_ther );
    rcsc::Sector2D ignoreSector( agent->world().ball().pos(), 0.1 , 10 , l.th() + 67.0, l.th() - 67.0 );

    const PlayerPtrCont::const_iterator o_end = agent->world().opponentsFromSelf().end();

    for ( PlayerPtrCont::const_iterator it = agent->world().opponentsFromSelf().begin(); it != o_end; ++it )
    {
        if ( (*it)->pos().x < MIN_X || (*it)->goalie() || ignoreSector.contains( (*it)->pos() ) )
            continue;

        if ( s.contains( (*it)->pos() ) )
            return false;
    }
    return true;


}

bool axiom_view::setPlay_execute(PlayerAgent* agent)
{


    // Omid & Alireza : View For SETPlayKICKIN !!!!! ///////////////////////////
    const rcsc::WorldModel & wm = agent->world();
    int Neck_Cycle_mod4 = wm.time().cycle() % 4 ;

    if (true) // && ( wm.self().pos().dist(wm.ball().pos()) ) > 2   )
    {
        switch ( Neck_Cycle_mod4 )
        {
        case (0) :
            agent->setViewAction(new rcsc::View_Normal());
            if (wm.ball().posCount() >= 2 )
            {
                //rcsc::Body_TurnToPoint(wm.ball().pos()).execute(agent);
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(wm.ball().pos()) );
            }
            else
            {
                //if (wm.self().pos().dist(M_home_pos) < 2)
                //rcsc::Body_TurnToPoint(rcsc::Vector2D(-52.0,0.0)).execute(agent);
                agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(-52.0,0.0)) );
            }
            break;

        case (1) :
//                 if (wm.self().pos().dist(M_home_pos) < 2)
//                     rcsc::Body_TurnToPoint(rcsc::Vector2D(wm.self().pos().x,wm.self().pos().y-10)).execute(agent);
            agent->setViewAction(new rcsc::View_Normal());
            agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(wm.self().pos().x,wm.self().pos().y-10)) );
            break;

        case (2) :
            agent->setViewAction(new rcsc::View_Normal());
            agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(52.0,0.0)) );
            break;

        case (3) :
            agent->setViewAction(new rcsc::View_Normal());
            agent->setNeckAction( new rcsc::Neck_TurnToPoint(rcsc::Vector2D(wm.self().pos().x,wm.self().pos().y+10)) );
            break;

        default :
            break;
        }
    }

    ///////////////////////////////////////////////////  END View By Omid & Alireza //////////////////////////

return true;
}




bool axiom_view::block_execute(PlayerAgent* agent)
{
  return default_execute(agent);
}

bool axiom_view::goalieBackPass_execute(PlayerAgent* agent)
{
  return default_execute(agent);
}

bool axiom_view::indirectMode_execute(PlayerAgent* agent)
{
  return default_execute(agent);
}

bool axiom_view::intercept_execute(PlayerAgent* agent)
{
  return default_execute(agent);
}
bool axiom_view::one2one_execute(PlayerAgent* agent)
{
  return default_execute(agent);
}
bool axiom_view::pass_execute(PlayerAgent* agent)
{
  return default_execute(agent);
}
bool axiom_view::thp_execute(PlayerAgent* agent)
{
  return default_execute(agent);
}