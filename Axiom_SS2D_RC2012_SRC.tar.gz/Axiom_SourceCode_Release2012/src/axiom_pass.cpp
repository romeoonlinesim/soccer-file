/**
 * bhv_axim_pass.cpp
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Authors : Mohammad Ghazanfari, Alireza Beydaghi, Mahta Ghandehari ,Hossein Rahmatizadeh
 * Copyright 2011
 * Allright Reserved
 */

#include "axiom_pass.h"
#include <rcsc/common/server_param.h>
#include <rcsc/player/intercept_table.h>
#include <rcsc/action/body_smart_kick.h>
#include <rcsc/player/say_message_builder.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>
#include <rcsc/action/neck_turn_to_point.h>
#include <rcsc/geom/polygon_2d.h>
#include <rcsc/action/body_kick_one_step.h>
#include "simulator.h"
#include <rcsc/player/soccer_intention.h>

#define LEAD_PASS_2_ENDSPEED 1.2
#define LEAD_PASS_1_ENDSPEED 1.1
#define DIRECT_ENDSPEED 1.0

#define LEAD1_SAFTY_THR1 75
#define LEAD1_SAFTY_THR2 65
#define LEAD2_SAFTY_THR1 80
#define LEAD2_SAFTY_THR2 70
#define	DIRECT_SAFTY_THR 60

#include <vector>
#include <algorithm>
//#include <PercepNetwork.h>
#include <sample_player.h>

using namespace std;

using namespace rcsc;






/*
bool AIcompaire(pair<rcsc::PlayerObject * , double> obj1 ,pair<rcsc::PlayerObject * , double>  *obj2)
{
  double epsilon = 1e-10;
  return (obj1.second - obj2.second) > epsilon;
}
*/




// AIResult readNet(const char* filename)
// {
// 
//     AIResult result;
//     ifstream file(filename);
// 
//     string title;
// 
//     if (file.is_open())
//     {
//         file >> title;//nuberoflayers
//         int num;
//         file >>  num;
// 
//         int numput;
//         file >> title;//inputs
//         file >> numput;
//         for (int i = 0; i < numput * 2; i++)
//         {
//             double minmax;
//             file >> minmax;
//             result.inputsMinMax.push_back(minmax);
//         }
// 
//         file >> title;//outputs
//         file >> numput;
//         for (int i = 0; i < numput * 2; i++)
//         {
//             double minmax;
//             file >> minmax;
//             result.outputsMinMax.push_back(minmax);
//         }
// 
//         file >> title;//layers
//         vector <int> Layer_percep(num);
// 
//         for (int i=0 ; i<num ; i++)
//             file >> Layer_percep[i];
// 
//         result.types.reserve(num);
// 
//         for (int i=0 ; i<num ; i++)
//         {
//             string strType;
//             file >> strType;
// 
//             if (strType == "tansig")
//                 result.types.push_back(TANSIG);
//             else if (strType == "purelin")
//                 result.types.push_back(LINEAR);
//             else
//                 result.types.push_back( LOGSIG);
//         }
// 
// 
//         file >> title;//weights
//         for (unsigned int i=0 ; i< Layer_percep.size() ; i++)
//         {
//             vector<vector<double> > tempPercep;
//             vector<double> tempBiases;
//             for (int j=0 ; j < Layer_percep[i] ; j++)
//             {
//                 int weightNum;
//                 file >> weightNum;
// 
//                 vector<double> tempWeight;
//                 for (int k=0 ; k<weightNum ; k++)
//                 {
//                     double weight;
//                     file >> weight ;
//                     tempWeight.push_back(weight);
//                 }
// 
//                 tempPercep.push_back(tempWeight);
// 
//                 double tempBias;
//                 file >> tempBias;
// 
//                 tempBiases.push_back(tempBias);
//             }
//             result.weights.push_back(tempPercep);
//             result.biases.push_back(tempBiases);
//         }
// 
//     }
//     file.close();
//     return result;
// }

bool Axiom_Pass::execute(rcsc::PlayerAgent* agent , bool pass_mode )
{

    /*		by Hossein and Alireza		*/

    const rcsc::WorldModel & wm = agent->world();
#if 0
    double tetha = 40;
    std::vector<pair< rcsc::PlayerObject * ,double> > AIoppvec ;

    std::vector<double > feature;

    const rcsc::PlayerPtrCont::const_iterator AItmm_end = wm.teammatesFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator AItmm = wm.teammatesFromSelf().begin();
            AItmm != AItmm_end;
            ++ AItmm )
    {
        feature.clear();
        AIoppvec.clear();

        if ( ((*AItmm)->pos().x - wm.self().pos().x > -10 ) && !(*AItmm)->isSelf() && (*AItmm)->unum() != 1 && !(*AItmm)->isGhost() )
        {
            rcsc::Sector2D AIsec(wm.self().pos() , 4 ,20 , ( (*AItmm)->pos() - wm.self().pos() ).th() + tetha ,  ( (*AItmm)->pos() - wm.self().pos() ).th() - tetha );


            // for contains
            const rcsc::PlayerPtrCont::const_iterator AIopp_end = wm.opponentsFromSelf().end();
            for ( rcsc::PlayerPtrCont::const_iterator AIopp = wm.opponentsFromSelf().begin();
                    AIopp != AIopp_end;
                    ++ AIopp )
            {
                if (AIsec.contains((*AIopp)->pos()) )
                {
                    Segment2D AIseg((*AItmm)->pos() ,wm.self().pos());
                    double dist = AIseg.dist((*AIopp)->pos() ) ;
                    cout<<"seg dist is "<<dist<<" cycle "<<agent->world().time().cycle()<<endl;
                    AIoppvec.push_back( pair<rcsc::PlayerObject * , double> (*AIopp , dist ) );
                }

            }


            /*  SORT     */
            //std::sort(AIoppvec.begin() , AIoppvec.end() , AIcompaire);
            for (int i=0 ;i<AIoppvec.size() ; i++)
                for (int j= 0 ;j<AIoppvec.size() ; j++)
                {
                    if (AIoppvec[i].second < AIoppvec[j].second)
                    {
                        pair<rcsc::PlayerObject * , double> temp;

                        temp.first = AIoppvec[i].first;
                        temp.second = AIoppvec[i].second;

                        AIoppvec[i].first = AIoppvec[j].first;
                        AIoppvec[i].second = AIoppvec[j].second;

                        AIoppvec[j].first = temp.first;
                        AIoppvec[j].second = temp.second;
                    }
                }

            for (int i = 0; i < AIoppvec.size() ; i++)
                cout<<"AIoppvec size is "<<AIoppvec.size()<<" after sort "<< i <<" is "<<AIoppvec[i].second<<" and the unum is "<<AIoppvec[i].first->unum()<<" and the cycle is "<<agent->world().time().cycle() <<endl;

            if (AIoppvec.size() >= 3)
            {

                for (int i=0 ; i<3 ; i++)
                {
                    feature.push_back(AIoppvec[i].first->posCount());
                    feature.push_back(AIoppvec[i].first->pos().r());
                    feature.push_back(AIoppvec[i].first->pos().th().degree());
                    feature.push_back(AIoppvec[i].first->angleFromSelf().degree());
                    feature.push_back(AIoppvec[i].first->distFromSelf());
                    feature.push_back(AIoppvec[i].first->distFromBall());
                }

                feature.push_back((*AItmm)->posCount());
                feature.push_back((*AItmm)->pos().r() );
                feature.push_back((*AItmm)->pos().th().degree() );
                feature.push_back((*AItmm)->angleFromSelf().degree());
                feature.push_back((*AItmm)->distFromSelf());
                feature.push_back((*AItmm)->distFromBall());


            }
            else if (AIoppvec.size() == 1) // if size == 0 ?????????????????????
            {



                feature.push_back(AIoppvec[0].first->posCount());
                feature.push_back(AIoppvec[0].first->pos().r());
                feature.push_back(AIoppvec[0].first->pos().th().degree());
                feature.push_back(AIoppvec[0].first->angleFromSelf().degree());
                feature.push_back(AIoppvec[0].first->distFromSelf());
                feature.push_back(AIoppvec[0].first->distFromBall());

                feature.push_back(10);
                feature.push_back((*AItmm)->pos().r() + (20 -(*AItmm)->pos().r()) - 3 );
                feature.push_back(( (*AItmm)->pos() - wm.self().pos()).th().degree() );
                feature.push_back( (*AItmm)->angleFromSelf().degree() );
                feature.push_back( (*AItmm)->distFromSelf() + (20 -(*AItmm)->pos().r()) - 3 );
                feature.push_back( 20 );


                feature.push_back(10);
                feature.push_back((*AItmm)->pos().r() + (20 -(*AItmm)->pos().r()) - 3 );
                feature.push_back(( (*AItmm)->pos() - wm.self().pos()).th().degree() );
                feature.push_back( (*AItmm)->angleFromSelf().degree() );
                feature.push_back( (*AItmm)->distFromSelf() + (20 -(*AItmm)->pos().r()) - 3 );
                feature.push_back( 20 );

                feature.push_back((*AItmm)->posCount());
                feature.push_back((*AItmm)->pos().r() );
                feature.push_back((*AItmm)->pos().th().degree() );
                feature.push_back((*AItmm)->angleFromSelf().degree());
                feature.push_back((*AItmm)->distFromSelf());
                feature.push_back((*AItmm)->distFromBall());

            }
            else if (AIoppvec.size() == 2)
            {


                for (int i = 0 ;i<2 ; i++)
                {
                    feature.push_back(AIoppvec[i].first->posCount());
                    feature.push_back(AIoppvec[i].first->pos().r());
                    feature.push_back(AIoppvec[i].first->pos().th().degree());
                    feature.push_back(AIoppvec[i].first->angleFromSelf().degree());
                    feature.push_back(AIoppvec[i].first->distFromSelf());
                    feature.push_back(AIoppvec[i].first->distFromBall());
                }

                feature.push_back(10);
                feature.push_back((*AItmm)->pos().r() + (20 -(*AItmm)->pos().r()) - 3 );
                feature.push_back(( (*AItmm)->pos() - wm.self().pos()).th().degree() );
                feature.push_back( (*AItmm)->angleFromSelf().degree() );
                feature.push_back( (*AItmm)->distFromSelf() + (20 -(*AItmm)->pos().r()) - 3 );
                feature.push_back( 20 );


                feature.push_back((*AItmm)->posCount());
                feature.push_back((*AItmm)->pos().r() );
                feature.push_back((*AItmm)->pos().th().degree() );
                feature.push_back((*AItmm)->angleFromSelf().degree());
                feature.push_back((*AItmm)->distFromSelf());
                feature.push_back((*AItmm)->distFromBall());


            }


/////////////////////////////////run//////////////////

            cout<<"feature size is "<<feature.size()<<endl;

            if (feature.size() == 24)
            {
                AIResult a = readNet("weight.txt");
                pnet = new PercepNetwork(a.weights, a.biases, a.types, a.inputsMinMax, a.outputsMinMax);



                double maxspeedball =  rcsc::ServerParam::i().ballSpeedMax();
                vector<double> pnetresult;


                pnetresult = pnet->run(feature);

                // cout<<"maxspeedball is "<<maxspeedball<<endl;
                cout<<"pnetresult value is "<<pnetresult[0]<<" in cycle "<<agent->world().time().cycle() <<endl<<endl;

                if (pnetresult[0] > 0.8)
                {
                    if ((*AItmm)->distFromSelf() > 6)
                        if ( (*AItmm)->posCount() < 4  && Body_SmartKick( (*AItmm)->inertiaPoint(1) , maxspeedball ,1 , 1 ).execute(agent) )
                        {
                            cout<<"\nAIpass occured in cylce "<<agent->world().time().cycle()<<"  and my unum is "<<agent->world().self().unum()<<" and tmm pos is "<<(*AItmm)->pos() <<" and tmm unum is "<<(*AItmm)->unum()<<endl<<endl;
                            return true;
                        }
                        else if ((*AItmm)->distFromSelf() < 6)
                            if ((*AItmm)->posCount() < 4 && Body_SmartKick( (*AItmm)->inertiaPoint(1) , maxspeedball - 1.2  ,1 , 1 ).execute(agent)  )
                            {
                                cout<<"\nAIpass occured in cylce "<<agent->world().time().cycle()<<"  and my unum is "<<agent->world().self().unum()<<" and tmm pos is "<<(*AItmm)->pos() <<" and tmm unum is "<<(*AItmm)->unum()<<endl<<endl;
                                return true;
                            }
                }

            }


        }//end if
    }//end for

    return false;

#endif

    /*	By Hossein and Ali 	*/

    int player_no = 0;
    directPassStr passSrtuct[10];
    directPassStr temp;



    const rcsc::PlayerPtrCont::const_iterator tmm_end = wm.teammatesFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator tmm = wm.teammatesFromSelf().begin();
            tmm != tmm_end;
            ++ tmm )
    {
        if (        ( *tmm )->posCount() <= 3
                    and ( *tmm )->unum() > 1
                    and !( *tmm )->goalie()
                    and ( *tmm )->pos().x <= wm.offsideLineX()
                    and !( *tmm )->isSelf()
                    and wm.self().pos().dist((*tmm)->pos()) < 50
                    and wm.self().pos().dist((*tmm)->pos()) > 5) // basic conditions
        {


            passSrtuct[player_no].SituationScore = getSituationScore(agent,(*tmm)->inertiaPoint((*tmm)->posCount()+1),(*tmm)->body());
            passSrtuct[player_no].reciever = (*tmm);




            player_no++;

        }
    }
    if (player_no == 0) return false;

    for ( int i = 0 ; i < player_no - 1 ; i ++ )
    {
        for ( int j = 0 ; j < player_no - 1 ; j ++)
        {
            if ( passSrtuct[j+1].SituationScore  > passSrtuct[j].SituationScore )
            {

                temp = passSrtuct[j];
                passSrtuct[j] = passSrtuct[j+1];
                passSrtuct[j+1] = temp;

            }
        }
    }




    for ( int i = 0 ; i < player_no ; i ++ )
    {
        if ( passSrtuct[i].SituationScore < 30 )
            continue;
        if ( canLeadPass1(agent,passSrtuct[i].reciever,pass_mode))
        {
            return true;
        }
        else if ( canDirectPass(agent,passSrtuct[i].reciever,pass_mode))
        {
            return true;
        }

    }

    return false;
}


rcsc::Vector2D Axiom_Pass::calculateTargetForNeck(rcsc::PlayerAgent* agent , bool pass_mode )
{

    int player_no = 0;
    directPassStr passSrtuct[10];
    directPassStr temp;

    const rcsc::WorldModel & wm = agent->world();

    const rcsc::PlayerPtrCont::const_iterator tmm_end = wm.teammatesFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator tmm = wm.teammatesFromSelf().begin();
            tmm != tmm_end;
            ++ tmm )
    {
        if (        ( *tmm )->posCount() <= 3
                    and ( *tmm )->unum() > 1
                    and !( *tmm )->goalie()
                    and ( *tmm )->pos().x <= wm.offsideLineX()
                    and !( *tmm )->isSelf()
                    and wm.self().pos().dist((*tmm)->pos()) < 50
                    and wm.self().pos().dist((*tmm)->pos()) > 5) // basic conditions
        {


            passSrtuct[player_no].SituationScore = getSituationScore(agent,(*tmm)->inertiaPoint((*tmm)->posCount()+1),(*tmm)->body());
            passSrtuct[player_no].reciever = (*tmm);




            player_no++;

        }
    }
    if (player_no == 0) return rcsc::Vector2D(0,0);

    for ( int i = 0 ; i < player_no - 1 ; i ++ )
    {
        for ( int j = 0 ; j < player_no - 1 ; j ++)
        {
            if ( passSrtuct[j+1].SituationScore  > passSrtuct[j].SituationScore )
            {

                temp = passSrtuct[j];
                passSrtuct[j] = passSrtuct[j+1];
                passSrtuct[j+1] = temp;

            }
        }
    }


    rcsc::Vector2D target_point;

    for ( int i = 0 ; i < player_no ; i ++ )
    {
        if ( passSrtuct[i].SituationScore < 30 )
            continue;
        if ( canLeadPass1Point(agent,passSrtuct[i].reciever,pass_mode).isValid()  )
        {
            return canLeadPass1Point(agent,passSrtuct[i].reciever,pass_mode);
        }
        else if ( canDirectPassPoint(agent,passSrtuct[i].reciever,pass_mode).isValid())
        {
            return canDirectPassPoint(agent,passSrtuct[i].reciever,pass_mode);
        }

    }

}



rcsc::Vector2D
Axiom_Pass::canLeadPass1Point(rcsc::PlayerAgent* agent, rcsc::PlayerObject* rec , bool passMode)
{
    const rcsc::WorldModel & wm = agent->world();
    double leadPassSafetyScore_1 = 0;
    double leadPassSafetyScore_2 = 0;
    double leadPassSafetyScore_3 = 0;
    if (rec->pos().x < -10)
        return rcsc::Vector2D::INVALIDATED;

    rcsc::Vector2D target_1,target_2,target_3;
    rcsc::Sector2D opp_pos_sector_front_1 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 6 , - 45 ,  45);
    rcsc::Sector2D opp_pos_sector_front_2 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 6 , - 105 ,  - 15);
    rcsc::Sector2D opp_pos_sector_front_3 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 6 , 15 ,  105);
    int counter_1 = 0;
    int counter_2 = 0;
    int counter_3 = 0;

    const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
            opp != opp_end;
            ++ opp )
    {
        if ( opp_pos_sector_front_1.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_1 ++;
        if ( opp_pos_sector_front_2.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_2 ++;
        if ( opp_pos_sector_front_3.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_3 ++;
    }
    if (wm.self().pos().dist(rec->inertiaPoint(rec->posCount() + 1)) > 8)
    {
        target_1 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1.5,0 ) );
        target_2 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1.5,-60 ) );
        target_3 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1.5,60 ) );
    }
    else
    {
        target_1 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1,0 ) );
        target_2 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1,-60 ) );
        target_3 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1,60 ) );
    }



    leadPassSafetyScore_1 = getSaftyScore(agent , target_1,rec);
    leadPassSafetyScore_2 = getSaftyScore(agent , target_2,rec);
    leadPassSafetyScore_3 = getSaftyScore(agent , target_3,rec);

    rcsc::Vector2D best_target;
    double best_target_safety;
    int best_target_counter;

    if ( (leadPassSafetyScore_1 >= leadPassSafetyScore_2) and (leadPassSafetyScore_1 >= leadPassSafetyScore_3) )
    {
        best_target = target_1;
        best_target_safety = leadPassSafetyScore_1;
        best_target_counter = counter_1;
    }
    else if ( (leadPassSafetyScore_2 >= leadPassSafetyScore_1) and (leadPassSafetyScore_2 >= leadPassSafetyScore_3) )
    {
        best_target = target_2;
        best_target_safety = leadPassSafetyScore_2;
        best_target_counter = counter_2;
    }
    else
    {
        best_target = target_3;
        best_target_safety = leadPassSafetyScore_3;
        best_target_counter = counter_3;
    }


    if ( (best_target_safety > LEAD1_SAFTY_THR2 and best_target_counter==0) and best_target.isValid() )
    {
        if (passMode==true)
        {
            double second_safety = getSaftyScore(agent,best_target,rec);
            if ( second_safety > LEAD1_SAFTY_THR2)
            {

                return best_target;

            }
        }
        if (passMode==false)
        {
            return best_target;
        }
    }

}




bool Axiom_Pass::canLeadPass2(rcsc::PlayerAgent* agent, rcsc::PlayerObject* rec , bool passMode)
{
    const rcsc::WorldModel & wm = agent->world();
    double leadPassSafetyScore_1 = 0;
    double leadPassSafetyScore_2 = 0;
    double leadPassSafetyScore_3 = 0;
    if (rec->pos().x < 0)
        return false;

    rcsc::Vector2D target_1,target_2,target_3;
    rcsc::Sector2D opp_pos_sector_front_1 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 12 , - 45 ,  45);
    rcsc::Sector2D opp_pos_sector_front_2 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 12 , - 105 ,  - 15);
    rcsc::Sector2D opp_pos_sector_front_3 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 12 , 15 ,  105);
    int counter_1 = 0;
    int counter_2 = 0;
    int counter_3 = 0;

    const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
            opp != opp_end;
            ++ opp )
    {
        if ( opp_pos_sector_front_1.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_1 ++;
        if ( opp_pos_sector_front_2.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_2 ++;
        if ( opp_pos_sector_front_3.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_3 ++;
    }
    if (wm.self().pos().dist(rec->inertiaPoint(rec->posCount() + 1)) > 8)
    {
        target_1 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(5,0 ) );
        target_2 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(5,-60 ) );
        target_3 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(5,60 ) );
    }
    else
    {
        target_1 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(3,0 ) );
        target_2 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(3,-60 ) );
        target_3 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(3,60 ) );
    }



    leadPassSafetyScore_1 = getSaftyScore(agent , target_1,rec);
    leadPassSafetyScore_2 = getSaftyScore(agent , target_2,rec);
    leadPassSafetyScore_3 = getSaftyScore(agent , target_3,rec);
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (leadPassSafetyScore_1 > LEAD2_SAFTY_THR1 and counter_1==0) and target_1.isValid() )
    {
        if (passMode==true)
        {
            //cout<< "\nI wanna lead pass 2 target 1 to target : " << target_1 << endl ;

            if ( Body_SmartKick(target_1,getBallSpeed(wm.self().pos().dist(target_1), LEAD_PASS_2_ENDSPEED),
                                getBallSpeed(wm.self().pos().dist(target_1),LEAD_PASS_2_ENDSPEED) * .98, 1).execute(agent) )
            {
                //cout<< "\n ------------------------------------------------------------------------------------------------------";
                //cout <<"\nTIME : "<< wm.time().cycle() <<" \tTarget : " << target_1 << "\nSafty = " << leadPassSafetyScore_1 << "\tNo = " << rec->unum() << "\n\n";
                //cout<< " ------------------------------------------------------------------------------------------------------\n\n";
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_1 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );
                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_1 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
            ////else passMode = false;

        }
        if (passMode==false)
        {
            if ( Body_KickOneStep(target_1,getBallSpeed_one_step(wm.self().pos().dist(target_1),LEAD_PASS_2_ENDSPEED)).execute(agent) )
            {

                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_1 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_1 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (leadPassSafetyScore_2 > LEAD2_SAFTY_THR1 and counter_2==0) and target_2.isValid() )
    {
        if (passMode==true)
        {

            if ( Body_SmartKick(target_2,getBallSpeed(wm.self().pos().dist(target_2),LEAD_PASS_2_ENDSPEED),
                                getBallSpeed(wm.self().pos().dist(target_2),LEAD_PASS_2_ENDSPEED)
                                * .98, 1).execute(agent) )
            {
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_2 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_2 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }

        }
        if (passMode==false)
        {
            agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

            if ( Body_KickOneStep(target_2,getBallSpeed_one_step(wm.self().pos().dist(target_2),LEAD_PASS_2_ENDSPEED)).
                    execute(agent) )
            {
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_2 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_2 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (leadPassSafetyScore_3 > LEAD2_SAFTY_THR1 and counter_3==0) and target_3.isValid() )
    {
        if (passMode==true)
        {
            //cout<< "\nI wanna lead pass 2 target 3 to target : " <<target_3 <<endl ;

            if ( Body_SmartKick(target_3,getBallSpeed(wm.self().pos().dist(target_3),LEAD_PASS_2_ENDSPEED),
                                getBallSpeed(wm.self().pos().dist(target_3),LEAD_PASS_2_ENDSPEED) * .98, 1)
                    .execute(agent) )
            {
                //cout<< "\n ------------------------------------------------------------------------------------------------------";
                //cout <<"\nTIME : "<< wm.time().cycle() <<" \tTarget : " << target_3 << "\nSafty = " << leadPassSafetyScore_3 << "\tNo = " << rec->unum() << "\n\n";
                //cout<< " ------------------------------------------------------------------------------------------------------\n\n";
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_3 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_3 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }

                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
            //else passMode = false;

        }
        if (passMode==false)
        {
            agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

            if ( Body_KickOneStep(target_3,getBallSpeed_one_step(wm.self().pos().dist(target_3),LEAD_PASS_2_ENDSPEED))
                    .execute(agent) )
            {

                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_3 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_3 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }

                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (leadPassSafetyScore_1 > LEAD2_SAFTY_THR2 and counter_1==0) /*or (leadPassSafetyScore_1 > 79 )*/ and target_1.isValid() )
    {
        if (passMode==true)
        {
            //cout<< "\nI wanna lead pass 2 target 1 to target : " << target_1 << endl ;

            if ( Body_SmartKick(target_1,getBallSpeed(wm.self().pos().dist(target_1),LEAD_PASS_2_ENDSPEED),
                                getBallSpeed(wm.self().pos().dist(target_1),LEAD_PASS_2_ENDSPEED) *
                                .98, 1).execute(agent) )
            {
                //cout<< "\n ------------------------------------------------------------------------------------------------------";
                //cout <<"\nTIME : "<< wm.time().cycle() <<" \tTarget : " << target_1 << "\nSafty = " << leadPassSafetyScore_1 << "\tNo = " << rec->unum() << "\n\n";
                //cout<< " ------------------------------------------------------------------------------------------------------\n\n";
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_1 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_1 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
            //else passMode = false;

        }
        if (passMode==false)
        {
            agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

            if ( Body_KickOneStep(target_1,getBallSpeed_one_step(wm.self().pos().dist(target_1),LEAD_PASS_2_ENDSPEED
                                                                )).execute(agent) )
            {
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_1 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_1 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (leadPassSafetyScore_2 > LEAD2_SAFTY_THR2 and counter_2==0) /*or (leadPassSafetyScore_2 > 79 )*/ and target_2.isValid() )
    {
        if (passMode==true)
        {
            //cout<< "\nI wanna lead pass 2 target 2 to target : " << target_2 << endl ;

            if ( Body_SmartKick(target_2,getBallSpeed(wm.self().pos().dist(target_2),LEAD_PASS_2_ENDSPEED),
                                getBallSpeed(wm.self().pos().dist(target_2),LEAD_PASS_2_ENDSPEED) * .98, 1).execute(agent) )
            {
                //cout<< "\n ------------------------------------------------------------------------------------------------------";
                //cout <<"\nTIME : "<< wm.time().cycle() <<" \tTarget : " << target_2 << "\nSafty = " << leadPassSafetyScore_2 << "\tNo = " << rec->unum() << "\n\n";
                //cout<< " ------------------------------------------------------------------------------------------------------\n\n";
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_2 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_2 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
            //else passMode = false;

        }
        if (passMode==false)
        {
            if ( Body_KickOneStep(target_2,getBallSpeed_one_step(wm.self().pos().dist(target_2),LEAD_PASS_2_ENDSPEED
                                                                )).execute(agent) )
            {

                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_2 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_2 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (leadPassSafetyScore_3 > LEAD2_SAFTY_THR2 and counter_3==0) /*or (leadPassSafetyScore_3 > 79 )*/ and target_3.isValid() )
    {
        if (passMode==true)
        {
            //cout<< "\nI wanna lead pass 2 target 3 to target : " << target_3 << endl ;

            if ( Body_SmartKick(target_3,getBallSpeed(wm.self().pos().dist(target_3),LEAD_PASS_2_ENDSPEED),
                                getBallSpeed(wm.self().pos().dist(target_3),LEAD_PASS_2_ENDSPEED
                                            ) * .98, 1).execute(agent) )
            {
                //cout<< "\n ------------------------------------------------------------------------------------------------------";
                //cout <<"\nTIME : "<< wm.time().cycle() <<" \tTarget : " << target_3 << "\nSafty = " << leadPassSafetyScore_3 << "\tNo = " << rec->unum() << "\n\n";
                //cout<< " ------------------------------------------------------------------------------------------------------\n\n";

                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_3 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_3 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                };
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
            //else passMode = false;
        }
        if (passMode==false)
        {
            if ( Body_KickOneStep(target_3,getBallSpeed_one_step(wm.self().pos().dist(target_3),LEAD_PASS_2_ENDSPEED
                                                                )).execute(agent) )
            {

                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target_3 - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target_3 + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }


    return false;

}



bool Axiom_Pass::canLeadPass1(rcsc::PlayerAgent* agent, rcsc::PlayerObject* rec , bool passMode)
{
    const rcsc::WorldModel & wm = agent->world();
    double leadPassSafetyScore_1 = 0;
    double leadPassSafetyScore_2 = 0;
    double leadPassSafetyScore_3 = 0;
    if (rec->pos().x < -10)
        return false;

    rcsc::Vector2D target_1,target_2,target_3;
    rcsc::Sector2D opp_pos_sector_front_1 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 6 , - 45 ,  45);
    rcsc::Sector2D opp_pos_sector_front_2 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 6 , - 105 ,  - 15);
    rcsc::Sector2D opp_pos_sector_front_3 (rec->inertiaPoint((rec->posCount()) + 1) , .5 , 6 , 15 ,  105);
    int counter_1 = 0;
    int counter_2 = 0;
    int counter_3 = 0;

    const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
            opp != opp_end;
            ++ opp )
    {
        if ( opp_pos_sector_front_1.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_1 ++;
        if ( opp_pos_sector_front_2.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_2 ++;
        if ( opp_pos_sector_front_3.contains((*opp)->inertiaPoint(((*opp)->posCount()) + 1)))
            counter_3 ++;
    }
    if (wm.self().pos().dist(rec->inertiaPoint(rec->posCount() + 1)) > 8)
    {
        target_1 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1.5,0 ) );
        target_2 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1.5,-60 ) );
        target_3 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1.5,60 ) );
    }
    else
    {
        target_1 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1,0 ) );
        target_2 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1,-60 ) );
        target_3 = rcsc::Vector2D ( rec->inertiaPoint(rec->posCount() + 1) +
                                    rcsc::Vector2D().polar2vector(1,60 ) );
    }



    leadPassSafetyScore_1 = getSaftyScore(agent , target_1,rec);
    leadPassSafetyScore_2 = getSaftyScore(agent , target_2,rec);
    leadPassSafetyScore_3 = getSaftyScore(agent , target_3,rec);
    //cout << "Safety for player " << rec->unum() << " and target_1 : " << target_1 << " is " << leadPassSafetyScore_1 << " Lead " << endl;
    //cout << "Safety for player " << rec->unum() << " and target_2 : " << target_2 << " is " << leadPassSafetyScore_2 << " Lead " << endl;
    //cout << "Safety for player " << rec->unum() << " and target_3 : " << target_3 << " is " << leadPassSafetyScore_3 << " Lead " << endl;

    rcsc::Vector2D best_target;
    double best_target_safety;
    int best_target_counter;

    if ( (leadPassSafetyScore_1 >= leadPassSafetyScore_2) and (leadPassSafetyScore_1 >= leadPassSafetyScore_3) )
    {
        best_target = target_1;
        best_target_safety = leadPassSafetyScore_1;
        best_target_counter = counter_1;
    }
    else if ( (leadPassSafetyScore_2 >= leadPassSafetyScore_1) and (leadPassSafetyScore_2 >= leadPassSafetyScore_3) )
    {
        best_target = target_2;
        best_target_safety = leadPassSafetyScore_2;
        best_target_counter = counter_2;
    }
    else
    {
        best_target = target_3;
        best_target_safety = leadPassSafetyScore_3;
        best_target_counter = counter_3;
    }

    //cout << "Safety for player " << rec->unum() << " and best_target : " << best_target << " is " << best_target_safety << " Lead " << endl;

    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );



    if ( (best_target_safety > LEAD1_SAFTY_THR2 and best_target_counter==0) and best_target.isValid() )
    {
        if (passMode==true)
        {
            //cout << "\n\n%%%%%%%%  Before turn neck!\n";
            agent->setNeckAction(new Neck_TurnToPoint(best_target));
            double second_safety = getSaftyScore(agent,best_target,rec);

            if ( second_safety > LEAD1_SAFTY_THR2)
            {

                //cout<< "\nI wanna lead pass 1 to target : " << best_target << endl ;

                if ( Body_SmartKick(best_target,getBallSpeed(wm.self().pos().dist(best_target),LEAD_PASS_1_ENDSPEED),
                                    getBallSpeed(wm.self().pos().dist(best_target),LEAD_PASS_1_ENDSPEED) * .98, 1).execute(agent) )
                {
                    //cout<< "\n ------------------------------------------------------------------------------------------------------";
                    //cout <<"\nTIME : "<< wm.time().cycle() <<" \tTarget : " << best_target << "\nSafty = " << leadPassSafetyScore_1 << "\tNo = " << rec->unum() << "\n\n";
                    //cout<< " ------------------------------------------------------------------------------------------------------\n\n";
                    if ( agent->config().useCommunication()
                            && rec->unum() != Unum_Unknown )
                    {
                        rcsc::Vector2D target_buf = best_target - agent->world().self().pos();
                        target_buf.setLength( 1.0 );

                        agent->addSayMessage( new PassMessage( rec->unum(),
                                                               best_target + target_buf,
                                                               agent->effector().queuedNextBallPos(),
                                                               agent->effector().queuedNextBallVel() ) );
                        return true;
                    }
                    //agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                    return true;
                }
                //else passMode = false;

            }
        }
        if (passMode==false)
        {
            agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

            if ( Body_KickOneStep(best_target,getBallSpeed_one_step(wm.self().pos().dist(best_target),LEAD_PASS_1_ENDSPEED)).
                    execute(agent) )
            {
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = best_target - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           best_target + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }



    return false;

}





rcsc::Vector2D
Axiom_Pass::canDirectPassPoint (rcsc::PlayerAgent * agent ,  rcsc::PlayerObject * rec , bool passMode)
{
    const rcsc::WorldModel & wm = agent->world();
    rcsc::Vector2D target = rec->inertiaPoint(rec->posCount()+1);
    ////cout<< "\n before RATE \n";


    double directPassSafetyScore = getSaftyScore(agent,target,rec);
    //cout << "Safety for player " << rec->unum() << " and target : " << target << " is " << directPassSafetyScore << " Direct " << endl;
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (directPassSafetyScore > DIRECT_SAFTY_THR ) and target.isValid() )
    {
        if (passMode==true)
        {
 
            agent->setNeckAction(new Neck_TurnToPoint(target));
            double second_safety = getSaftyScore(agent,target,rec);

            if ( second_safety > DIRECT_SAFTY_THR )
            {
                return target;
            }
 

        }
        if (passMode==false)
        {
            return target;
        }
    }
    return rcsc::Vector2D::INVALIDATED;

}



bool Axiom_Pass::canDirectPass (rcsc::PlayerAgent * agent ,  rcsc::PlayerObject * rec , bool passMode)
{
    const rcsc::WorldModel & wm = agent->world();
    rcsc::Vector2D target = rec->inertiaPoint(rec->posCount()+1);
    ////cout<< "\n before RATE \n";


    double directPassSafetyScore = getSaftyScore(agent,target,rec);
    //cout << "Safety for player " << rec->unum() << " and target : " << target << " is " << directPassSafetyScore << " Direct " << endl;
    agent->setIntention(  static_cast< rcsc::SoccerIntention * >( 0 ) );

    if ( (directPassSafetyScore > DIRECT_SAFTY_THR ) and target.isValid() )
    {
        if (passMode==true)
        {
            //cout << "\n\n%%%%%%%%%%%  Before turn neck\n";
            ////cout<< "\n target : "<<target;
            agent->setNeckAction(new Neck_TurnToPoint(target));
            double second_safety = getSaftyScore(agent,target,rec);

            if ( second_safety > DIRECT_SAFTY_THR )
            {
                //cout<< "\nI wanna direct pass to target : " << target << endl;
                if ( Body_SmartKick(target,getBallSpeed(wm.self().pos().dist(target),DIRECT_ENDSPEED),
                                    getBallSpeed(wm.self().pos().dist(target),DIRECT_ENDSPEED) * .98, 1).execute(agent) )
                {

                    if ( agent->config().useCommunication()
                            && rec->unum() != Unum_Unknown )
                    {
                        rcsc::Vector2D target_buf = target - agent->world().self().pos();
                        target_buf.setLength( 1.0 );

                        agent->addSayMessage( new PassMessage( rec->unum(),
                                                               target + target_buf,
                                                               agent->effector().queuedNextBallPos(),
                                                               agent->effector().queuedNextBallVel() ) );
                        return true;
                    }
                    agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                    return true;
                }
            }
            //else passMode = false;

        }
        if (passMode==false)
        {
            if ( Body_KickOneStep(target,getBallSpeed_one_step(wm.self().pos().dist(target),DIRECT_ENDSPEED)).execute(agent) )
            {
                if ( agent->config().useCommunication()
                        && rec->unum() != Unum_Unknown )
                {
                    rcsc::Vector2D target_buf = target - agent->world().self().pos();
                    target_buf.setLength( 1.0 );

                    agent->addSayMessage( new PassMessage( rec->unum(),
                                                           target + target_buf,
                                                           agent->effector().queuedNextBallPos(),
                                                           agent->effector().queuedNextBallVel() ) );
                    return true;
                }
                agent->setNeckAction(new Neck_TurnToLowConfTeammate());
                return true;
            }
        }
    }
    return false;

}


double Axiom_Pass::getSituationScore(rcsc::PlayerAgent * agent ,rcsc::Vector2D reciever_point , rcsc::AngleDeg bodyAngle)
{
    const rcsc::WorldModel & wm = agent->world();
    double rate = 0 ; // [0-100]

    // normal conditions
    rate =  getDensityRate(wm,reciever_point,bodyAngle) * getAreaRate(wm.self().pos(),reciever_point);
    if ( wm.self().pos().dist( reciever_point ) > 40 ) rate -= 10;
    if ( wm.self().pos().dist( reciever_point ) < 5 )  rate -= 10;

    switch ( getArea(reciever_point) )
    {

    case AREA_3:
    {
        /*        if ( wm.self().pos().dist( reciver_point ) < 5 )
                    rate -= 5;*/
        if ( reciever_point.x < wm.self().pos().x
                and wm.self().pos().dist( reciever_point ) < 8 )
            rate -= 5;
        if ( reciever_point.x < wm.self().pos().x - 5
                and wm.self().pos().dist( reciever_point ) >= 8 )
            rate -= 5;

        break;
    }
    case AREA_4:
    {
        if ( reciever_point.x < wm.self().pos().x
                and wm.self().pos().dist( reciever_point ) < 8 )
            rate -= 10;
        if ( reciever_point.x < wm.self().pos().x - 5
                and wm.self().pos().dist( reciever_point ) >= 8 )
            rate -= 10;
        break;
    }
    case AREA_6:
    case AREA_5:
    {
        if ( wm.self().pos().dist( reciever_point ) < 10 )
            rate -= 10;
        if ( reciever_point.x < wm.self().pos().x  )
            rate -= 30;

        break;
    }
    case AREA_7:
    {
        if ( reciever_point.x < wm.self().pos().x
                and wm.self().pos().dist( reciever_point ) < 8 )
            rate -= 25;
        if ( reciever_point.x < wm.self().pos().x - 5
                and wm.self().pos().dist( reciever_point ) >= 8 )
            rate -= 25;
        break;
    }
    default:
        rate = rate;
    }


    return rate;
}

double Axiom_Pass::getDensityRate ( const rcsc::WorldModel & wm , rcsc::Vector2D reciever_point , rcsc::AngleDeg bodyAngle )
{
    //cout << "\n**************** Density Rate *******************"<<endl;
    int ball_reach_cycle;
    // rcsc::Sector2D density_area ( rcsc::Vector2D ( reciever_point.x - 10, reciever_point.y ), 6, 20, bodyAngle + 30 , bodyAngle - 30 );
    rcsc::Circle2D density_circle (reciever_point,7.0);
//    if ( wm.self().pos().dist(reciever_point) > 35.0 ) ball_reach_cycle = 50; // edited by MOHAMMAD
//    else
//    {
    ball_reach_cycle = getReachCycle( NULL , wm ,wm.self().pos().dist(reciever_point), 1);
    //cout << "ball reach cycle :" << ball_reach_cycle << endl;
//    }
    std::vector<rcsc::Vector2D> simulated_points;
    std::vector<rcsc::Vector2D> opp_inside_sector;
    int opp_front_number = 0,opp_back_number = 0 , decrease_rate = 0;



    const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
            opp != opp_end;
            ++ opp )
    {
        simulated_points.push_back(  (*opp)->inertiaPoint( ball_reach_cycle )  );
    }


    if ( simulated_points.empty() ) return 50;

    for ( int i = 0 ; i < simulated_points.size()  ; i ++ )
    {

        if ( density_circle.contains(simulated_points.at(i)) )
        {
            if ( simulated_points.at(i).x > reciever_point.x )
            {
                opp_front_number++;

            }
            else if ( simulated_points.at(i).x <= reciever_point.x ) opp_back_number ++;
        }
    }

    //cout << "opp_front_number :" << opp_front_number << "\t opp_back_number : " << opp_back_number << endl;
    decrease_rate = opp_back_number * 4 + opp_front_number * 10;

    //cout << " final Density Rate : " << 50-decrease_rate << endl;
    //cout << "**************** end of density *************\n\n";

    return (50 - decrease_rate);
}



double Axiom_Pass::getSaftyScore(rcsc::PlayerAgent * agent ,const rcsc::Vector2D reciever_point, rcsc::PlayerObject * rec)
{
    //cout <<" ******************* Safety Score  ******************\n";

    const rcsc::WorldModel & wm = agent->world();



#if 1

OLD_PASS:

    rcsc::Polygon2D rects[6];
    double rate = 0;
    double passDist = (reciever_point - wm.self().pos()).r();
    if ( passDist < 15)
    {
        for ( int i = 5 ; i > 0 ; i --)
        {
            rects[5-i] = makePolygon(agent,reciever_point,i+2);
        }
        rects[5] = makePolygon(agent,reciever_point,1);

    }
    else
    {
        for ( int i = 5 ; i > 0 ; i --)
        {
            rects[5-i] = makePolygon(agent,reciever_point,i);
        }
        rects[5] = makePolygon(agent,reciever_point,.5);

    }

    std::vector<rcsc::PlayerObject *> objs;
    const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
            opp != opp_end;
            ++ opp )
    {
        if ( (*opp)->posCount() < 10  )  /*(*opp)->posValid() )*/
        {
            // //cout << " opponent " << (*opp)->unum() << " pushed\n";
            objs.push_back((*opp));
        }

    }

    rcsc::Polygon2D small_rect = makePolygonRect(agent,reciever_point,1.5);
    if (countOppSimulatedIn(wm,small_rect) > 0)
    {
        //cout << "\n opp is in small rect!!!\n";
        return rate = 0 ;
    }


    if ( countOppSimulatedIn(wm ,rects[0]) == 0 )
    {

        rate = 100;
    }
    else
    {
        if ( countOppSimulatedIn(wm ,rects[1]) == 0 )
        {
            rate = 90;
        }
        else
        {
            if ( countOppSimulatedIn(wm /*agent*/,rects[2]) == 0 )
            {
                rate = 70;
            }
            else
            {
                if ( countOppSimulatedIn(wm /*agent*/,rects[3]) == 0 )
                {
                    rate = 50;
                }
                else {
                    if ( countOppSimulatedIn(wm /*agent*/,rects[4]) == 0 )
                    {
                        rate = 30;
                    }
                    else
                    {
                        if ( countOppSimulatedIn( wm /*agent*/,rects[5]) == 0 )
                        {
                            rate = 20;
                        }
                        else
                        {
                            rate = 5;
                        }
                    }
                }
            }
        }
    }

    rcsc::Polygon2D reach_polygon = makePolygon(agent,reciever_point,7);

    rate -= calculateRateForSafty( wm, objs ,reciever_point ,reach_polygon, rec );
    //cout << "**************** end of Safety score *****************\n\n";
    return rate;
#endif

    return 10;
}


int
Axiom_Pass::countOppSimulatedIn( const rcsc::WorldModel & wm, rcsc::Polygon2D poly )
{
    int counter = 0;
    int count_thr = 6;
    const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
            opp != opp_end;
            ++ opp )
        if ( (*opp)->posCount() < count_thr and
                poly.contains ((*opp)->inertiaPoint((*opp)->posCount()+1) ) and !(*opp)->goalie() )
            counter ++;

    return counter;
}


rcsc::Polygon2D
Axiom_Pass::makePolygon( rcsc::PlayerAgent * agent, rcsc::Vector2D reciever /*const rcsc::PlayerObject * rec*/ , double rad )
{
//  //cout << "\n\n================== Make Polygon ================\n";

    const rcsc::WorldModel & wm = agent->world();
    rcsc::Polygon2D poly;
    vector<rcsc::Vector2D> poly_vectors;

    double 		poly_rate = rad/5;
    rcsc::AngleDeg passAngle = (reciever - wm.self().pos()).th();
    reciever = rcsc::Vector2D( reciever + rcsc::Vector2D().polar2vector(3,passAngle));
    //cout << "\n$$$$$$\tnew rec is : " << reciever << endl;

    rcsc::Segment2D 	pass_line ( wm.self().pos(), reciever );
    double		pass_dist = pass_line.length();


    rcsc::Circle2D	circle_dist_1 ( wm.self().pos(), ( (.1) * pass_dist ));
    rcsc::Circle2D	circle_dist_2 ( wm.self().pos(), ( (.8) * pass_dist ));

    rcsc::Vector2D	intersection_c1[2];
    rcsc::Vector2D	intersection_c2[2];

    rcsc::Vector2D intersect_c1,intersect_c2;
    circle_dist_1.intersection(pass_line, &intersection_c1[0], &intersection_c1[1]);
    circle_dist_2.intersection(pass_line, &intersection_c2[0], &intersection_c2[1]);

    if (intersection_c1[0].isValid())
    {
        intersect_c1 = intersection_c1[0];
    }
    else intersect_c1 = intersection_c1[1];

    if (intersection_c2[0].isValid())
    {
        intersect_c2 = intersection_c2[0];
    }
    else intersect_c2 = intersection_c2[1];


    rcsc::Line2D 	perpen_line_self = pass_line.line().perpendicular(wm.self().pos());
    rcsc::Circle2D 	self_circle ( wm.self().pos(), ( (3.0/40.0) * pass_dist * poly_rate ) );
 
    rcsc::Line2D 	perpen_line_tmm = pass_line.line().perpendicular(reciever);
    rcsc::Circle2D 	tmm_circle ( reciever , ( (.1) * pass_dist * poly_rate ) );

    rcsc::Line2D 	perpen_line_step_one = pass_line.line().perpendicular(intersect_c1);
    rcsc::Circle2D 	circle_step_one ( intersect_c1 , ( (.15) * pass_dist * poly_rate ) );
    rcsc::Line2D 	perpen_line_step_two = pass_line.line().perpendicular(intersect_c2);
    rcsc::Circle2D 	circle_step_two ( intersect_c2 , ( (.35) * pass_dist * poly_rate ) );

    rcsc::Vector2D self_around_points[2];
    rcsc::Vector2D tmm_around_points[2];
    rcsc::Vector2D one_step_around_points[2];
    rcsc::Vector2D two_step_around_points[2];

    self_circle.intersection(perpen_line_self,&self_around_points[0],&self_around_points[1]);
    tmm_circle.intersection(perpen_line_tmm,&tmm_around_points[0],&tmm_around_points[1]);
    circle_step_one.intersection(perpen_line_step_one,&one_step_around_points[0],&one_step_around_points[1]);
    circle_step_two.intersection(perpen_line_step_two,&two_step_around_points[0],&two_step_around_points[1]);

    if ( self_around_points[0].dist(one_step_around_points[0]) <
            self_around_points[0].dist(one_step_around_points[1]) )
    {
        poly_vectors.push_back(self_around_points[0]);
        poly_vectors.push_back(one_step_around_points[0]);
        if ( one_step_around_points[0].dist(two_step_around_points[0]) <
                one_step_around_points[0].dist(two_step_around_points[1]) )
        {
            poly_vectors.push_back(two_step_around_points[0]);
            if ( two_step_around_points[0].dist(tmm_around_points[0]) <
                    two_step_around_points[0].dist(tmm_around_points[1]) )
            {
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( two_step_around_points[1]   );
                poly_vectors.push_back( one_step_around_points[1]   );
                poly_vectors.push_back( self_around_points[1] );
            }
            else
            {
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( two_step_around_points[1]   );
                poly_vectors.push_back( one_step_around_points[1]   );
                poly_vectors.push_back( self_around_points[1] );
            }
        }
        else
        {
            poly_vectors.push_back(two_step_around_points[1]);
            if ( two_step_around_points[1].dist(tmm_around_points[0]) <
                    two_step_around_points[1].dist(tmm_around_points[1]) )
            {
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( two_step_around_points[0]   );
                poly_vectors.push_back( one_step_around_points[1]   );
                poly_vectors.push_back( self_around_points[1] );
            }
            else
            {
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( two_step_around_points[0]   );
                poly_vectors.push_back( one_step_around_points[1]   );
                poly_vectors.push_back( self_around_points[1] );
            }
        }
    }
    else
    {
        poly_vectors.push_back(self_around_points[0]);
        poly_vectors.push_back(one_step_around_points[1]);
        if ( one_step_around_points[1].dist(two_step_around_points[0]) <
                one_step_around_points[1].dist(two_step_around_points[1]) )
        {
            poly_vectors.push_back(two_step_around_points[0]);
            if ( two_step_around_points[0].dist(tmm_around_points[0]) <
                    two_step_around_points[0].dist(tmm_around_points[1]) )
            {
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( two_step_around_points[1]   );
                poly_vectors.push_back( one_step_around_points[0]   );
                poly_vectors.push_back( self_around_points[1] );
            }
            else
            {
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( two_step_around_points[1]   );
                poly_vectors.push_back( one_step_around_points[0]   );
                poly_vectors.push_back( self_around_points[1] );
            }
        }
        else
        {
            poly_vectors.push_back(two_step_around_points[1]);
            if ( two_step_around_points[1].dist(tmm_around_points[0]) <
                    two_step_around_points[1].dist(tmm_around_points[1]) )
            {
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( two_step_around_points[0]   );
                poly_vectors.push_back( one_step_around_points[0]   );
                poly_vectors.push_back( self_around_points[1] );
            }
            else
            {
                poly_vectors.push_back( tmm_around_points[1]	);
                poly_vectors.push_back( tmm_around_points[0]	);
                poly_vectors.push_back( two_step_around_points[0]   );
                poly_vectors.push_back( one_step_around_points[0]   );
                poly_vectors.push_back( self_around_points[1] );
            }
        }
    }


    poly.assign(poly_vectors);



    return poly;
}


rcsc::Polygon2D
Axiom_Pass::makePolygonRect( rcsc::PlayerAgent * agent, rcsc::Vector2D reciever /*const rcsc::PlayerObject * rec */ , double rad )
{



    const rcsc::WorldModel & wm = agent->world();
    rcsc::Polygon2D poly;
    rcsc::Segment2D 	pass_line ( wm.self().pos(), reciever );
    double		pass_dist = pass_line.length();

    rcsc::Line2D 	perpen_line = pass_line.line().perpendicular(wm.self().pos());
    rcsc::Circle2D 	self_circle ( wm.self().pos(), rad );

    rcsc::Line2D perpen_line_tmm = pass_line.line().perpendicular(reciever);
    rcsc::Circle2D tmm_circle ( reciever, rad );


    rcsc::Vector2D top_left[3],right_bottom[3];
    self_circle.intersection(perpen_line,&top_left[1],&top_left[2]);
    tmm_circle.intersection(perpen_line_tmm,&right_bottom[1],&right_bottom[2]);


    std::vector<rcsc::Vector2D> poly_vec;
    poly_vec.push_back(top_left[1]);
    poly_vec.push_back(top_left[2]);


    if ( top_left[2].dist(right_bottom[1]) < top_left[2].dist(right_bottom[2]) )
    {
        poly_vec.push_back(right_bottom[1]);
        poly_vec.push_back(right_bottom[2]);
    }
    else
    {
        poly_vec.push_back(right_bottom[2]);
        poly_vec.push_back(right_bottom[1]);
    }

    poly.assign(poly_vec);

    return poly;
}



double
Axiom_Pass::calculateRateForSafty( const rcsc::WorldModel & wm , std::vector<rcsc::PlayerObject *> obj ,
                                   const rcsc::Vector2D tmm_pos, rcsc::Polygon2D rect, rcsc::PlayerObject *rec )
{
    //cout <<"\n$$$$$$$$$$$$$$$$$$$$$$ calculateRateForSafty $$$$$$$$$$$$$$$$$$$$$$\n\n";

    double possibility_model_rate = 0;
    bool possibility_model_success = false;
    for ( uint i = 0 ; i < obj.size() ; i ++ )
    {
        possibility_model_rate = PossibilityModel::instance().CalcDirectPassSuccessRate(wm.ball().pos(), tmm_pos, obj.at(i)->pos() );
        if ( possibility_model_rate > .99 ) possibility_model_success = true;
    }
 


    int counter = 0;
    rcsc::Vector2D opp_pos[obj.size()];
    for ( int i = 0 ; i < obj.size() ; i ++)
    {
        opp_pos[i] = obj.at(i)->pos();
    }
    rcsc::Vector2D tmp( tmm_pos.x - wm.ball().pos().x , tmm_pos.y - tmm_pos.y);
    float currentPassVel = 2.5;
    if (tmp.r() < 15)
        currentPassVel = 2.3;

    if (tmp.r() < 10)
        currentPassVel = 2;

    rcsc::Vector2D ballVel = rcsc::Vector2D::polar2vector (currentPassVel,tmp.dir());
    int tmmFinishTime;
    float tmmFinalX;
    float tmmFinalY;
    int oppFinishTime;
    float oppFinalX;
    float oppFinalY;
    bool success_possib_model = true;

    PossibilityModelStruct possib;
    rcsc::Vector2D player[1] = { tmm_pos };

    possib.objs = player;
    possib.pos = wm.ball().pos();
    possib.vel = ballVel;
    possib.player_no = 1;

    rcsc::Vector2D final_point (0.0 , 0.0 );
    rcsc::Vector2D final_point_opp (0.0 , 0.0 );
    int end_cycle = 0, end_cycle_opp = 0;
 

# if 1
    int ball_cycle = getReachCycle ( NULL,wm, tmm_pos.dist ( wm.ball().pos() ), 1 );
    //cout << "ball reach cycle = " << ball_cycle << endl;
    rcsc::Vector2D target_pos = tmm_pos;
    rcsc::Circle2D back_circle (target_pos,8);
    std::vector< rcsc::PlayerObject* > opponents;
    rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromSelf().end();
    for ( rcsc::PlayerPtrCont::const_iterator it = wm.opponentsFromSelf().begin();
            it != end;
            ++it )
    {

        if ( ( rect.contains(( *it )->inertiaPoint((*it)->posCount())) ) or
                ( back_circle.contains(( *it )->inertiaPoint((*it)->posCount()))) )
        {
            opponents.push_back ( ( *it ) );
        }
    }

    int reach_success = false;
    double ball_speed = getBallSpeed( (wm.self().pos().dist(tmm_pos)), 1.1 );
 
    if ( !opponents.empty() )
    {
        for ( unsigned int i = 0; i < opponents.size(); i++ )
        {
            rcsc::Segment2D ball_to_target ( wm.ball().pos(), target_pos );
            int opp_reach_cycle = 1;
            int ball_reach_cycle = 1;

            rcsc::Vector2D opp_pos = opponents.at ( i )->inertiaPoint(opponents.at ( i )->posCount()+1);

            double opp_dist = ball_to_target.dist ( opp_pos );
            rcsc::Vector2D near_point = ball_to_target.nearestPoint ( opp_pos );
            double ball_dist = near_point.dist ( wm.ball().pos() );
            opp_reach_cycle = getReachCycle(opponents.at ( i ),wm, opp_dist, 2 );
            ball_reach_cycle = getReachCycle(NULL, wm, ball_dist, 1 );

 
            if ( ball_reach_cycle > opp_reach_cycle + 1 )
            {
                reach_success = false;
            }
            else
            {
                reach_success = true;
            }
        }
    }
    else if ( opponents.empty() )
    {
        reach_success = true;
    }
    if ( success_possib_model and reach_success and possibility_model_success )
        return 0.0;

    return 28.0;

#endif
}

/**
 * getReachCycle
 * sum = sum * decay ^ cycle + ... -> geom series
 *
 * obj for object reach cycle ( if mode_number == 2 )
 * wm for self reach cycle ( if mode_number == 3 )
 * first_speed for when first speed will manually apply
 * dist for comparing and finding reach cycle to dist
 * mode_number 	{ if ( 1 ) return ball reach cycle,
 * 		  if ( 2 ) return obj reach cycle,
 * 		  if ( 3 ) return self reach cycle
 * 		}
 *
 * output : cycle to reach dist
 * 
 */
int Axiom_Pass::getReachCycle( rcsc::PlayerObject * obj, const rcsc::WorldModel & wm, double dist, int mode_number)
{

    int i = 1;
    double sum = 0 ;
    double first_speed = 0;
    if ( mode_number == 1 ) first_speed = getBallSpeed(dist,.8);
    if ( mode_number == 1 )
    {
        while ( sum <= dist )
        {
            sum += first_speed;
            first_speed *= rcsc::ServerParam::i().ballDecay();
            i++;
            if ( i > 25 )
            {
                break;
            }

        }
        return i - 1;
    }
    if ( mode_number == 2)
    {
        while ( sum <= dist )
        {
            first_speed += obj->playerTypePtr()->dashPowerRate() * 100;
            if ( first_speed > obj->playerTypePtr()->playerSpeedMax() )
                first_speed = obj->playerTypePtr()->playerSpeedMax();
            sum += first_speed;
            first_speed *= obj->playerTypePtr()->playerDecay();
            i++;
        }
        return i - 1;
    }
    if ( mode_number == 3 )
    {
        while ( sum <= dist )
        {
            first_speed += wm.self().playerTypePtr()->dashPowerRate() * 100;
            if ( first_speed > wm.self().playerTypePtr()->playerSpeedMax() )
                first_speed = wm.self().playerTypePtr()->playerSpeedMax();
            sum += first_speed;
            first_speed *= wm.self().playerTypePtr()->playerDecay();
            i++;
        }
        return i - 1;
    }

}
double Axiom_Pass::getBallSpeed( double pass_dist, double end_speed )
{

    float first_speed = 3;
    while ( end_speed > 0.5 )
    {
        first_speed = calc_first_term_geom_series_last( end_speed , pass_dist ,ServerParam::i().ballDecay() );
        if (first_speed < ServerParam::i().ballSpeedMax() )
            return first_speed;
        end_speed -= 0.1;
    }
    return first_speed;


}

double Axiom_Pass::getBallSpeed_one_step( double pass_dist ,double end_speed )
{
    if ( pass_dist >= 20.0 )
    {
        return 3.0;
    }
    else if ( pass_dist >= 8.0 )
    {
        return 2.5;
    }
    else if ( pass_dist >= 5.0 )
    {
        return 1.6;
    }
    else
    {
        return 1.5;
    }
}

int Axiom_Pass::getArea(rcsc::Vector2D input)
{
    double X = input.x;
    double Y = input.y;
    double Yabs = input.absY();

    if ( X > 40 and Yabs > 10 ) {
        return AREA_1;
    }
    else if (( X > 30 and X < 40 and Yabs < 20 ) or ( X > 40 and Yabs < 10  ) ) {
        return AREA_2;
    }
    else if ( X > 15 and X <= 40 and Yabs >= 20 ) {
        return AREA_3;
    }
    else if (( X > 0 and X <= 18.5 ) or ( X >= 18.5 and X < 30 and Yabs < 20 ) )  {
        return AREA_4;
    }
    else if ( X <= -30 and Yabs < 20 ) {
        return AREA_5;
    }
    else if ( X <-30 and Yabs >= 20 ) {
        return AREA_6;
    }
    else if ( X < 0 and X > -30 ) {
        return AREA_7;
    }
    else return AREA_ILLEGAL;
}


/// TODO: back pass

double Axiom_Pass::getAreaRate ( rcsc::Vector2D agent, rcsc::Vector2D target )
{
    int agent_area = getArea( agent );
    int target_area = getArea( target );
    //cout << "Area " << agent_area << " to Area " << target_area << endl;
    double rate = 0;

    switch ( agent_area )
    {
    case AREA_1:
    {
        switch ( target_area )
        {
        case AREA_1:
            return 1.5;
            break;
        case AREA_2:
            return 2;
            break;
        case AREA_3:
            return 1.25;
            break;
        case AREA_4:
            return .75;
            break;
        default :
            return 1;
            break;
        }
    }
    case AREA_2:
    {
        switch ( target_area )
        {
        case AREA_1:
            return 1.5;
            break;
        case AREA_2:
            return 2;
            break;
        case AREA_3:
            return 1;
            break;
        case AREA_4:
            return .5;
            break;
        default :
            return 1;
            break;
        }
    }
    case AREA_3:
    {
        switch ( target_area )
        {
        case AREA_1:
            return 1.5;
            break;
        case AREA_2:
            return 2.0;
            break;
        case AREA_3:
            return 1;
            break;
        case AREA_4:
            return 1;
            break;
        case AREA_7:
            return .25;
            break;
        default :
            return 1;
            break;
        }
    }
    case AREA_4:
    {
        switch ( target_area )
        {
        case AREA_1:
            return 2;
            break;
        case AREA_2:
            return 2;
            break;
        case AREA_3:
            return 1.5;
            break;
        case AREA_4:
            return 1.25;
            break;
        case AREA_7:
            return .5;
            break;
        default :
            return 1;
            break;
        }
    }
    case AREA_5:
    {
        switch ( target_area )
        {
        case AREA_4:
            return 1.5;
            break;
        case AREA_5:
            return .25;
            break;
        case AREA_6:
            return .75;
            break;
        case AREA_7:
            return 2;
            break;
        default :
            return 1;
            break;
        }
    }
    case AREA_6:
    {
        switch ( target_area )
        {
        case AREA_4:
            return 1.5;
            break;
        case AREA_5:
            return .25;
            break;
        case AREA_6:
            return .5;
            break;
        case AREA_7:
            return 2;
            break;
        default :
            return 1;
            break;
        }
    }
    case AREA_7:
    {
        switch ( target_area )
        {
        case AREA_2:
            return 1.25;
            break;
        case AREA_3:
            return 1.5;
            break;
        case AREA_4:
            return 2;
            break;
        case AREA_5:
            return .1;
            break;
        case AREA_6:
            return .1;
            break;
        case AREA_7:
            return 1;
            break;
        default :
            return 1;
            break;
        }
    }
    default :
        return 1;
        break;
    }
}