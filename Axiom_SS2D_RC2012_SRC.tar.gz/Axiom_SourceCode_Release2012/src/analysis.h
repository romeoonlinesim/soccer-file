#ifndef ANALYSIS_H
#define ANALYSIS_H
#include <rcsc/geom/vector_2d.h>
#include <rcsc/geom/circle_2d.h>

class Analysis{
private:

public:
   std::vector<int> getPairPlayer ( rcsc::PlayerAgent * agent );
   int  getOppNumber(rcsc::PlayerAgent * agent,
                     const rcsc::Vector2D &center,
                     const double &r);
   int getOppNumber(rcsc::PlayerAgent * agent,
                    const double &front_x,
                    const double &back_x);
   int getOppNumber(rcsc::PlayerAgent * agent,
                    const rcsc::Vector2D &left_top,
                    const double &length,
                    const double &width);
   std::vector<int> getOppNumberAroundBall(rcsc::PlayerAgent * agent,double dist);
   int getMateNumber(rcsc::PlayerAgent * agent,
                     const rcsc::Vector2D &center,
                     const double &r);
   int getMateNumber(rcsc::PlayerAgent * agent,
                     const rcsc::Vector2D &left_top,
                     const double &length,
                     const double &width);
   double getDistFromNearestMate(rcsc::PlayerAgent * agent,
                                 const rcsc::Vector2D &point);
   double getDistFromNearestOpp(rcsc::PlayerAgent * agent,
                                const rcsc::Vector2D &point);
   std::list<double> getOppYlist(rcsc::PlayerAgent * agent,
                                 const double &length,
                                 const double &width);

};

#endif
