#include "axiom_positioning.h"
#include "sample_player.h"
#include "strategy.h"

#include <cmath>

#include <vector>
#include <algorithm>
#include <rcsc/soccer_math.h>
#include <rcsc/player/world_model.h>


#include <rcsc/player/audio_sensor.h>
#include <rcsc/player/free_message.h>
#include <rcsc/player/freeform_parser.h>
#include <rcsc/common/server_param.h>
#include <rcsc/player/intercept_table.h>
#include <rcsc/action/body_go_to_point.h>
#include <rcsc/action/body_turn_to_point.h>
#include <rcsc/action/body_intercept.h>
#include "axiom_view.h"




bool axiom_positioning::execute(PlayerAgent* agent)
{
    const rcsc::WorldModel & wm = agent->world();
    Vector2D ball_pos = wm.ball().pos();
    const double max_positioning_dist = 40.0;
    Circle2D positioning_area(ball_pos, max_positioning_dist);

    ball_sectores.clear();

    for (unsigned int i = 0 ; i < 72 ; i++)
    {
        rcsc::Sector2D check_ray (ball_pos,0.0,max_positioning_dist,rcsc::AngleDeg(i*5),rcsc::AngleDeg(i*5 + 4.99)) ;

        if (!is_oppIntheRay(agent,check_ray))
            ball_sectores.push_back(check_ray);

    }

    for (unsigned int k = 0 ; k < ball_sectores.size() ; k++)
    {
        std::cout << "\nOMid clear sector is  : " << ball_sectores.at(k).angleLeftStart() ;
    }



}

bool axiom_positioning::is_oppIntheRay(PlayerAgent* agent , rcsc::Sector2D _ball_sec)
{
    const rcsc::WorldModel & wm = agent->world();
    return wm.existOpponentIn<rcsc::Sector2D>(_ball_sec,5,true);

}


bool axiom_positioning::temp(PlayerAgent* agent)
{
    const rcsc::WorldModel & wm = agent->world();
    /// By Mohammad Ghazanfari && Omid Shirkhothshidi
    ///////////////////////// positioning for recieving pass in opp penalty Area /////////////////////////////////

    rcsc::Circle2D ball_circle (wm.ball().pos(),3);

    if (wm.self().unum() < 7 || !wm.existTeammateIn<Circle2D>(ball_circle,5,false) || wm.self().isKickable() || wm.self().distFromBall() < 3 ) return false;

    rcsc::Vector2D home_pos = Strategy::i().getPosition( agent->world().self().unum() );

    if ( ! home_pos.isValid() ) home_pos.assign( 0.0, 0.0 );

    if (wm.ball().pos().x > 33 && wm.self().pos().x > 30)
    {
        //   std::cout << "\ncycle :" << wm.time().cycle() << "\t**CHANGING POS\tfirst of check, home :" << home_pos << "\tunum :" << wm.self().unum();
        bool flag = true;
        int max_angle_array [9]={0};

        for (int i=0 ; i < 9 ; i++ )
        {
            rcsc::Vector2D clear_point(home_pos.x-4+i,home_pos.y);
            if (clear_point.x > wm.offsideLineX())	continue;
            flag = true;

            for (int j=1 ; j<31 ; j++)
            {
                rcsc::Vector2D clear_line(clear_point - wm.ball().pos());
                if (clear_line.r() < 2.5)  continue;
                rcsc::Sector2D empty_sector(wm.ball().pos(),2,clear_line.r(),clear_line.th()-j,clear_line.th()+j);

                // std::cout << "mostafa\tcycle:"<<wm.time().cycle() <<"\tsector r:"<<shoot_line.r() << "\tsector th:"<<shoot_line.th() << "\tj:"<< j<<"\n";

                const rcsc::PlayerPtrCont::const_iterator end = wm.opponentsFromBall().end();
                for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromBall().begin();
                        opp != end;
                        ++opp )
                {
                    if (empty_sector.contains((*opp)->pos()))
                    {
                        flag = false;
                        if ( (*opp)->goalie() )
                        {
                            max_angle_array[i] = 2*(j-3); /// when opp == goalie we reduce the angle!!!
                        }
                        else
                            max_angle_array[i] = 2*(j-1);
                        break;
                    }
                }
                if (!flag)
                    break;
                else if ( j== 30 )
                {
                    max_angle_array[i] = 60;	/// sector ta akhar baz shode va opp dakhelesh naboode!! akh jooooon!!!
                }
            }
        }


        int best_index = -1, best_angle = 0;
        for (int i=0 ; i<9 ; i++)
        {
            if (max_angle_array[i] > best_angle)
            {
                best_angle = max_angle_array[i];
                best_index = i;
            }
        }

        // std::cout << "\ncycle :" << wm.time().cycle() << "\t**CHANGING POS\tbest angle :" << best_angle << "\t best index :" << best_index << "\tunum :" << wm.self().unum();

        if ( best_index != -1 && best_angle > 10 )
        {
            home_pos = rcsc::Vector2D (home_pos.x-4+best_index , home_pos.y );
            if (( !wm.audioMemory().pass().empty() && wm.audioMemory().pass().front().receiver_ != wm.self().unum() ))
            {
                if (rcsc::Body_GoToPoint( home_pos, 1.5, rcsc::ServerParam::i().maxDashPower()*0.96,100,100,false ).execute( agent ))
                {
                    //std::cout << "\ncycle :" << wm.time().cycle() << "\t**CHANGING POS\tmy home pos changed too " << home_pos << "\tunum :" << wm.self().unum();
                    // Omid View:
                    axiom_view().default_execute(agent);
                    return true;
                }
            }
        }


    }
// Omid View:
    axiom_view().default_execute(agent);
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    return false;
}
