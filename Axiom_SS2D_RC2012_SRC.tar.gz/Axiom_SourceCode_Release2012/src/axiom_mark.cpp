/**********************************
** Authors: Farbod Samsamipour   **
**          Hossein Rahmatizadeh **
** Date   : 26 April 2012        **
**********************************/

#include "axiom_mark.h"

using namespace std;
using namespace rcsc;

bool Axiom_Mark::execute(PlayerAgent *agent)
{
  return false;
}