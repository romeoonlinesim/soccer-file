// -*-c++-*-

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 3, or (at your option)
 any later version.

 This code is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this code; see the file COPYING.  If not, write to
 the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "bhv_basic_offensive_kick.h"

#include <rcsc/action/body_advance_ball.h>
#include <rcsc/action/body_dribble.h>
#include <rcsc/action/body_pass.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>
#include <rcsc/action/body_smart_kick.h>
#include <rcsc/action/body_kick_one_step.h>
#include <rcsc/action/body_go_to_point_dodge.h>
#include <rcsc/action/neck_turn_to_ball_or_scan.h>
#include <rcsc/action/body_clear_ball.h>

#include <rcsc/player/player_agent.h>
#include <rcsc/player/debug_client.h>

#include <rcsc/common/logger.h>
#include <rcsc/common/server_param.h>

#include <rcsc/geom/sector_2d.h>
#include <cmath>


#include "axiom_shoot.h"
#include "bhv_dribble_fast.h"
#include "bhv_dribble_normal.h"
#include "strategy.h"
#include "analysis.h"
#include "axiom_pass.h"
#include "axiom_throughPass.h"
#include "sample_player.h"
#include "axiom_view.h"

using namespace rcsc;
using namespace std;

/*-------------------------------------------------------------------*/
/*!

 */
bool
Bhv_BasicOffensiveKick::execute( rcsc::PlayerAgent * agent )
{
    dlog.addText( Logger::TEAM,
                  __FILE__": Bhv_BasicOffensiveKick" );

    const WorldModel & wm = agent->world();

    /* Axiom strategy [start] */

//     // Omid View:
//     axiom_view().default_execute(agent);

    // indirect mode
    if ( ((SamplePlayer*) agent)->indirect_mode == true  )
    {
        if (indirectModeShoot(agent))
        {
            // TODO: neck
           // std::cout <<"\n cycle : " << wm.time().cycle() << "  indirect Shoot. !!! \n";
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
    }

    // risky shoot
    if ( canRiskyShoot( agent ) )
    {
        if ( riskyShoot( agent ) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            //std::cout <<"\n cycle : " << wm.time().cycle() << "   Risky Shoot. !!! \n";
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
    }

    // virtual goalie mode
    if ( wm.self().pos().x < -46 && ( ( wm.self().pos().y > -3 && wm.self().pos().y < 10 && wm.self().unum() == 5 ) || ( wm.self().pos().y < 3 && wm.self().pos().y > -10 && wm.self().unum() == 4 ) ) )
    {
        if ( AxiomClearBall( agent ) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
    }

    // danger mode
    if ( isDangerMode( agent ) )
    {
        if ( dangerModeDecision( agent ) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            //std::cout <<"\n cycle : " << wm.time().cycle() << "   Danger Mode dec. !!! \n";
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
    }

    // G.A. shoot
    if ( axiom_shoot().execute( agent ) )
    {
        //agent->setNeckAction( new Neck_TurnToBallOrScan() );
        //std::cout <<"\n cycle : " << wm.time().cycle() << "   G.A shoot!!! \n";
        // Omid View:
        axiom_view().default_execute(agent);
        return true;
    }

    // through pass mode 1
    rcsc::Vector2D goal( 52.0, 0.0 );

    if ( agent->world().self().unum() == 9 )
        goal = rcsc::Vector2D(46.0, -12.0);
    else if (agent->world().self().unum() == 10)
        goal = rcsc::Vector2D(46.0, 12.0);

    rcsc::Vector2D forward_Vector( goal - agent->world().ball().pos() );
    rcsc::Sector2D OmidMagicSector_for121 = Sector2D (wm.self().pos(),1.5,5.0,forward_Vector.th()-45.0,forward_Vector.th()+45.0);

    if ( (wm.existOpponentIn<rcsc::Sector2D>(OmidMagicSector_for121,3,false) || wm.self().unum()!=11 ) && ( ( (wm.self().unum()==7 || wm.self().unum() == 8) && wm.self().pos().x < 25) || (wm.self().pos().x > 20 && wm.self().pos().x <= 40 && fabs(wm.self().pos().y) >= 10.5 ) || (wm.self().pos().x <= 20 && wm.self().unum() != 11) ||  (wm.self().pos().x <= 24 && (wm.self().unum() ==  8 || wm.self().unum() == 7)  ) )  )
    {
        if (ThroughPass().sender_execute(agent) )
        {
           // std::cout <<"\n cycle : " << wm.time().cycle() << "   THP !!!! \n";
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
// 	else if ( Axiom_Pass().execute( agent) )
// 	{
// 	  return true;
// 	}

    }

    //pass in pnalty area of opp;
    if (wm.ball().pos().x > 33 && fabs(wm.ball().pos().y) < 25  && !oneToOneToGoalie( agent ) && Axiom_Pass().execute( agent) ) //{OMID}
    {
        //agent->setNeckAction( new Neck_TurnToBallOrScan() );
        // Omid View:
        axiom_view().default_execute(agent);
        return true;
    }

    // one to one to goalie mode
    if ( oneToOneToGoalie( agent ) )
    {
        //std::cout <<"\n cycle : " << wm.time().cycle() << "   One2One !!! \n";
        if (wm.self().pos().x < 35 && Bhv_SelfPass().execute( agent )  )
        {
            // agent->setNeckAction( new Neck_TurnToBallOrScan() );
            //std::cout <<"\n cycle : " << wm.time().cycle() << "   SRP !!! \n";
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
        if ( wm.self().unum() == 9 )
        {
	  if ( wm.self().pos().x < 38)
            rcsc::Body_Dribble( rcsc::Vector2D( 46.0, -12.0 ), 2, ServerParam::i().MAX_DASH_POWER * 0.95, 3 ,false).execute( agent );
	  else
	    rcsc::Body_Dribble( rcsc::Vector2D( 46.0, -10.0 ), 2, ServerParam::i().MAX_DASH_POWER * 0.95, 3 ,false).execute( agent );// {OMID}
            // Omid View:
            axiom_view().default_execute(agent);
	    return true;

            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
        }
        else if ( wm.self().unum() == 10 )
        {
	  if ( wm.self().pos().x < 38)
            rcsc::Body_Dribble( rcsc::Vector2D( 46.0, 12.0 ), 2, ServerParam::i().MAX_DASH_POWER * 0.95, 3 ,false).execute( agent );
	  else
	    rcsc::Body_Dribble( rcsc::Vector2D( 46.0, 10.0 ), 2, ServerParam::i().MAX_DASH_POWER * 0.95, 3 ,false).execute( agent );// {OMID}
            // Omid View:
            axiom_view().default_execute(agent);
	    return true;
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
	    
        }
        else if (wm.self().unum() == 11 || ( (wm.self().unum()==7 || wm.self().unum()==8) && wm.self().pos().x > 28 ))
        {
            rcsc::Body_Dribble( rcsc::Vector2D( 52.0, 0.0 ), 2, ServerParam::i().MAX_DASH_POWER * 0.96, 3, false).execute( agent );
            // Omid View:
            axiom_view().default_execute(agent);
	    return true;
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
        }
        

    }

    // THP
    if ( ThroughPass().sender_execute(agent) )
    {
       // std::cout <<"\n cycle : " << wm.time().cycle() << "   THP !!!! \n";
        // Omid View:
       axiom_view().default_execute(agent);
        return true;
    }

    if (isBackDribble(agent))
    {
      if ( Axiom_Pass().execute(agent) )
      {
	axiom_view().default_execute(agent);
            return true;
      }
      else if (Body_ClearBall().execute(agent))
        {
            //std::cout <<"\n cycle : " << wm.time().cycle() << "   BackdribbleClearball !!! \n";
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
    }

    if ( wm.self().unum() < 9 )
        normalDec( agent );
    else
    {
      //normalDec(agent);		// {OMID}
      
        if ( Strategy::get_ball_area( wm ) == Strategy::BA_Cross )
            normalDec( agent );
        else
            analysisDec( agent );
    }

    // Omid View:
    axiom_view().default_execute(agent);
    return true;

}

bool Bhv_BasicOffensiveKick::oneToOneToGoalie( PlayerAgent * agent )
{
    double MIN_X = 8;
    double dir_ther = 15.5;
    const WorldModel & wm = agent->world();
    if ( ( agent->world().self().unum() == 9 || agent->world().self().unum() == 10 ) )// && ! ( wm.opponentTeamName() == "Tempux2D" || wm.opponentTeamName() == "tempux2d" ||  wm.opponentTeamName() == "TempuX2D" ||  wm.opponentTeamName() == "tempux2D" ||  wm.opponentTeamName() == "TEMPUX2D" ||  wm.opponentTeamName() == "Tempux" ||  wm.opponentTeamName() == "tempux" ||  wm.opponentTeamName() == "TempuX" ) )
        MIN_X = 22;

    if ( agent->world().self().pos().x < MIN_X || (wm.self().pos().x > 44  && fabs(wm.self().pos().y) < 10  )  )
        return false;

    rcsc::Vector2D goal( 52.0, 0.0 );

    if ( agent->world().self().unum() == 9 )
        goal = rcsc::Vector2D(46.0, -12.0);
    else if (agent->world().self().unum() == 10)
        goal = rcsc::Vector2D(46.0, 12.0);
    
    if ( agent->world().self().unum() == 9 && wm.self().pos().x > 38)
        goal = rcsc::Vector2D(46.0, -10.0);
    else if (agent->world().self().unum() == 10 && wm.self().pos().x > 38)
        goal = rcsc::Vector2D(46.0, 10.0);

    rcsc::Vector2D l( goal - agent->world().ball().pos() );

    if (wm.self().pos().x >= 35)
    {
        dir_ther = 7.0;
    }

    rcsc::Sector2D s( agent->world().ball().pos(), 0.1 , 20 , l.th() - dir_ther, l.th() + dir_ther );
    rcsc::Sector2D ignoreSector( agent->world().ball().pos(), 0.1 , 10 , l.th() + 67.0, l.th() - 67.0 );

    const PlayerPtrCont::const_iterator o_end = agent->world().opponentsFromSelf().end();

    for ( PlayerPtrCont::const_iterator it = agent->world().opponentsFromSelf().begin(); it != o_end; ++it )
    {
        if ( (*it)->pos().x < MIN_X || (*it)->goalie() || ignoreSector.contains( (*it)->pos() ) )
            continue;

        if ( s.contains( (*it)->pos() ) )
            return false;
    }
    return true;
}

bool Bhv_BasicOffensiveKick::riskyShoot( PlayerAgent * agent )
{
    const WorldModel & wm = agent->world();
    bool flag = true;
    int max_angle_array [13] = {0};

    for ( int i = 0; i < 13; i++ )
    { // goal ro be 14 part taghsim mikonim va check mikoninm mishavad be anha shoot kard ya na!
        Vector2D shoot_point( 52.5, ( -6 + i ) );
        if ( wm.ball().pos().x < 42 && fabs( shoot_point.y - wm.ball().pos().y ) > 12 )
            continue; // shooti ke kheili arzie nazane chon goalie migire!

        flag = true;
        for ( int j = 1; j < 31; j++ ) // yek sector mikeshim va ta jayi ke opp dakhele sector nis an ra baz mikonim!
        {
            Vector2D shoot_line( shoot_point - wm.ball().pos() );
            Sector2D empty_sector( wm.ball().pos(), 3.5, shoot_line.r(), shoot_line.th() - j, shoot_line.th() + j );

            const PlayerPtrCont::const_iterator end = wm.opponentsFromBall().end();
            for ( PlayerPtrCont::const_iterator opp = wm.opponentsFromBall().begin(); opp != end; ++opp )
            {
                if ( empty_sector.contains( (*opp)->pos() ) )
                {
                    flag = false;
                    if ( (*opp)->goalie() )
                        max_angle_array[i] = 2 * ( j - 3 ); // when opp == goalie we reduce the angle!!!
                    else
                        max_angle_array[i] = 2 * ( j - 1 ); // maximum angle sectore empty baraye shoot be noghte i ra save mikonim ke 2 barabare j e marhale ghabl ast!
                    break;
                }
            }
            if ( ! flag )
                break;
            else if ( j == 30 )
                max_angle_array[i] = 60; // sector ta akhar baz shode va opp dakhelesh naboode!! akh jooooon!!!
        }
    }

    //Vector2D best_target( 0, 0 );
    int best_index = -1, best_angle = 0;
    for ( int i = 0; i < 13; i++ )
    {
        if ( max_angle_array[i] > best_angle )
        {
            best_angle = max_angle_array[i];
            best_index = i;
        }
    }

    Vector2D best_shoot_point( 52.5, ( -6 + best_index ) );
    double shoot_dist = Vector2D( best_shoot_point - wm.ball().pos() ).r();

    if ( shoot_dist > 12 )
    {
        if ( best_angle > 34 && best_index != -1 )
        {
            if ( Body_SmartKick( best_shoot_point, ServerParam::i().ballSpeedMax(), ServerParam::i().ballSpeedMax() * .96, 2 ).execute( agent ) )
            {
                //agent->setNeckAction( new Neck_ScanField() );
                return true;
            }
            else if ( Body_KickOneStep( best_shoot_point, ServerParam::i().ballSpeedMax() ).execute( agent) )
            {
                //agent->setNeckAction(new Neck_ScanField() );
                return true;
            }
        }
    }
    else
    {
        if ( best_angle > 20 && best_index != -1 )
        {
            if ( Body_SmartKick( best_shoot_point, ServerParam::i().ballSpeedMax(), ServerParam::i().ballSpeedMax() * .96, 2 ).execute( agent ) )
            {
                //agent->setNeckAction( new Neck_ScanField() );
                return true;
            }
            else if ( Body_KickOneStep( best_shoot_point, ServerParam::i().ballSpeedMax() ).execute( agent) )
            {
                agent->setNeckAction(new Neck_ScanField() );
                //return true;
            }
        }
    }

    return false;
}


bool Bhv_BasicOffensiveKick::canRiskyShoot( PlayerAgent * agent )
{
    const WorldModel & wm = agent->world();

    if ( wm.ball().pos().x > 38 && wm.ball().pos().absY() < 17 )
        return true;

    rcsc::Vector2D goal( 52.0, 0.0 );
    rcsc::Vector2D l( goal - agent->world().ball().pos() );
    rcsc::Sector2D goalieSector( agent->world().ball().pos(), 0.1 , 10.0 , l.th() + 20.0, l.th() - 20.0 );
    
    if ( wm.ball().pos().x > 35 && wm.ball().pos().absY() < 16 && wm.existOpponentIn<rcsc::Sector2D>(goalieSector,5,true)  )
        return true;
    
    return false;
}

bool Bhv_BasicOffensiveKick::isDangerMode( PlayerAgent * agent )
{
    const WorldModel & wm = agent->world();
    Rect2D dangerArea( Vector2D( -52.5, -20 ), Vector2D( -36, 20 ) );
    int num_of_opp_in_danger_area = 0;
    int num_of_tmm_in_danger_area = 0;
    int oppNo = 3;



    if ( dangerArea.contains( wm.ball().pos() ) )
    {
        const PlayerPtrCont::const_iterator end = wm.opponentsFromBall().end();
        for ( PlayerPtrCont::const_iterator opp = wm.opponentsFromBall().begin(); opp != end; ++opp )
        {
            if ( (*opp)->posCount() > 6 )
                continue;
            if ( dangerArea.contains( (*opp)->pos() ) )
                num_of_opp_in_danger_area++;
        }

        const PlayerPtrCont::const_iterator endTmm = wm.teammatesFromBall().end();
        for ( PlayerPtrCont::const_iterator t = wm.teammatesFromBall().begin(); t != endTmm; ++t )
        {
            if ( (*t)->posCount() > 6 )
                continue;
            if ( dangerArea.contains( (*t)->pos() ) )
                num_of_tmm_in_danger_area++;
        }

        if ( ! wm.self().goalie() && ( num_of_opp_in_danger_area >= oppNo || num_of_opp_in_danger_area >= num_of_tmm_in_danger_area ) )
            return true;
    }
    return false;
}


bool Bhv_BasicOffensiveKick::dangerModeDecision( PlayerAgent * agent )
{
    const WorldModel & wm = agent->world();
    if ( wm.self().goalie() )
        return false;

    if ( AxiomClearBall( agent ) )
    {
        agent->setNeckAction( new Neck_ScanField() );
        return true;
    }
    return false;
}

bool Bhv_BasicOffensiveKick::AxiomClearBall( PlayerAgent * agent )
{
    
    return false;
}

/* *** DECISION TREE *** */

bool Bhv_BasicOffensiveKick::analysisDec ( rcsc::PlayerAgent * agent )
{
    switch ( Strategy::get_ball_area( agent->world() ) )
    {
    case Strategy::BA_CrossBlock:
    case Strategy::BA_Stopper:
    case Strategy::BA_Danger:
    case Strategy::BA_DribbleBlock:
    case Strategy::BA_DefMidField:
        if ( defensiveWBdecision( agent ) )
            return true;
        break;
    case Strategy::BA_DribbleAttack:
    case Strategy::BA_OffMidField:
        if ( offensiveWBdecision( agent ) )
            return true;
        break;
    case Strategy::BA_Cross:
        if ( crossOffensiveWBdecision( agent ) )
            return true;
        break;
    case Strategy::BA_ShootChance:
        if ( highOffensiveWBdecision( agent ) )
            return true;
        break;
    default:
        if ( offensiveWBdecision( agent ) )
            return true;
        break;
    }

    return true;
}

bool Bhv_BasicOffensiveKick::normalDec(rcsc::PlayerAgent* agent)
{
    if ( Axiom_Pass().execute( agent ) )
    {
        //agent->setNeckAction( new Neck_TurnToBallOrScan() );
        axiom_view().default_execute(agent);
        return true;
    }
    else if ( agent->world().ball().pos().x > -5 && Axiom_Pass().execute(agent ) )
    {
      axiom_view().default_execute(agent);
      return true;
    }
    else
    {
        BhvDribble().execute(agent);
        //agent->setNeckAction( new Neck_TurnToBallOrScan() );
	axiom_view().default_execute(agent);
        return true;
    }
}


/*!
*     |
*   2 | 3
* ---------->
*   1 | 0
*    \|/
*/

bool Bhv_BasicOffensiveKick::offensiveWBdecision ( rcsc::PlayerAgent * agent )
{
    std::vector<int> opp_cons = Analysis().getOppNumberAroundBall(agent,8);
    if ( opp_cons.empty() and BhvDribble().execute(agent) ) return true;
    if ( opp_cons[3] != 0 or opp_cons[0] != 0 )
    {
        if (  Axiom_Pass().execute(agent) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            return true;
        }
        else {
            if ( BhvDribble().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
        }
    }
    else {
        if ( BhvDribble().execute(agent) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            return true;
        }
        else
        {
            if ( Axiom_Pass().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
        }
    }
    return false;
}

bool Bhv_BasicOffensiveKick::crossOffensiveWBdecision(rcsc::PlayerAgent* agent)
{
    const rcsc::WorldModel & wm = agent->world();
    std::vector<int> opp_cons = Analysis().getOppNumberAroundBall(agent,8);
    if ( opp_cons.empty() and BhvDribble().execute(agent) ) return true;
    if ( wm.self().pos().y <= 0 )
    {
        if ( opp_cons[3] != 0 or opp_cons[2] != 0 or opp_cons[1] != 0 )
        {
            if (  Axiom_Pass().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
            else {
                if ( BhvDribble().execute(agent) )
                {
                    //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                    return true;
                }
            }
        }
        else {
            if ( BhvDribble().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
            else
            {
                if ( Axiom_Pass().execute(agent) )
                {
                    //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                    return true;
                }
            }
        }
    }

    if ( wm.self().pos().y <= 0 )
    {
        if ( (opp_cons[1] != 0) or (opp_cons[0] != 0) and (opp_cons[2] != 0) )
        {
            if (  Axiom_Pass().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
            else {
                if ( BhvDribble().execute(agent) )
                {
                    //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                    return true;
                }
            }
        }
        else {
            if ( BhvDribble().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
            else
            {
                if ( Axiom_Pass().execute(agent) )
                {
                    //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                    return true;
                }
            }
        }
    }

    return false;
}

bool Bhv_BasicOffensiveKick::highOffensiveWBdecision(rcsc::PlayerAgent* agent)
{
    std::vector<int> opp_cons = Analysis().getOppNumberAroundBall(agent,7);
    if ( opp_cons.empty() and BhvDribble().execute(agent) ) return true;
    if ( opp_cons[3] != 0 or opp_cons[0] != 0 )
    {
        if (  Axiom_Pass().execute(agent) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            return true;
        }
        else {
            if ( BhvDribble().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
        }
    }
    else {
        if ( BhvDribble().execute(agent) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            return true;
        }
        else
        {
            if ( Axiom_Pass().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
        }
    }
    return false;
}

bool Bhv_BasicOffensiveKick::defensiveWBdecision(rcsc::PlayerAgent* agent)
{
    std::vector<int> opp_cons = Analysis().getOppNumberAroundBall(agent,12);
    bool safe_flag = true;

    if ( opp_cons.empty() and BhvDribble().execute(agent) ) return true;

    for ( uint i = 0; i < opp_cons.size() ; i++ )
    {
        if ( opp_cons.at(i) != 0 )
        {
            safe_flag = false;
            break;
        }
    }


    if ( safe_flag )
    {
        if (  Axiom_Pass().execute(agent) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            return true;
        }
        else {
            if ( BhvDribble().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
        }
    }
    else {
        if ( BhvDribble().execute(agent) )
        {
            //agent->setNeckAction( new Neck_TurnToBallOrScan() );
            return true;
        }
        else
        {
            if ( Axiom_Pass().execute(agent) )
            {
                //agent->setNeckAction( new Neck_TurnToBallOrScan() );
                return true;
            }
        }
    }
    return false;
}

bool Bhv_BasicOffensiveKick::indirectModeShoot(rcsc::PlayerAgent* agent)
{
    

    return false;
}

bool Bhv_BasicOffensiveKick::isBackDribble(rcsc::PlayerAgent* agent)
{
    const rcsc::WorldModel &wm = agent->world();

    if (wm.ball().pos().x > -25)
        return false;

    static int cycle_counter = 0;
    static std::vector< pair< int, int > > player_and_ball_pos;

    if (cycle_counter == 4 and player_and_ball_pos.size() == 4)
    {
        if (player_and_ball_pos.at(0).first == wm.self().unum() and
                player_and_ball_pos.at(1).first == wm.self().unum() and
                player_and_ball_pos.at(2).first == wm.self().unum() and
                player_and_ball_pos.at(3).first == wm.self().unum() and
                player_and_ball_pos.at(0).second > player_and_ball_pos.at(1).second and
                player_and_ball_pos.at(1).second > player_and_ball_pos.at(2).second and
                player_and_ball_pos.at(2).second > player_and_ball_pos.at(3).second
           )
        {
            cycle_counter = 0;
            player_and_ball_pos.clear();
            return true;
        }
        else
        {
            cycle_counter = 0;
            player_and_ball_pos.clear();
            return false;
        }
    }
    else
    {
        pair<int, int> pos;
        pos.first = wm.self().unum();
        pos.second = wm.ball().pos().x;
        player_and_ball_pos.push_back(pos);
        cycle_counter++;
    }
    return false;
}