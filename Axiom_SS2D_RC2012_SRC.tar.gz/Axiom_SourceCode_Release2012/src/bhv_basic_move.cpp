// -*-c++-*-

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 3, or (at your option)
 any later version.

 This code is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this code; see the file COPYING.  If not, write to
 the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "bhv_basic_move.h"

#include <rcsc/action/basic_actions.h>
#include <rcsc/action/body_go_to_point.h>
#include <rcsc/action/body_intercept.h>
#include <rcsc/action/neck_turn_to_ball_or_scan.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>

#include <rcsc/player/player_agent.h>
#include <rcsc/player/debug_client.h>
#include <rcsc/player/intercept_table.h>

#include <rcsc/common/logger.h>
#include <rcsc/common/server_param.h>
#include <rcsc/common/audio_memory.h>

#include "neck_offensive_intercept_neck.h"
#include "strategy.h"
#include "bhv_basic_tackle.h"
#include "bhv_block.h"
#include "axiom_mark.h"
#include "bhv_set_play.h"
#include "axiom_throughPass.h"

#include "bhv_danger_area_tackle.h"
#include "axiom_view.h"
#include "axiom_positioning.h"

using namespace rcsc;
using namespace std;

/*-------------------------------------------------------------------*/
/*!

 */
bool
Bhv_BasicMove::execute( PlayerAgent * agent )
{
    // const double MIN_TACKLE_PROB = 0.65;
    const double X1 = -20.0;

    const WorldModel & wm = agent->world();
    const Vector2D target_point = Strategy::i().getPosition( wm.self().unum() );
    double dash_power = Strategy::get_normal_dash_power( wm );

    double dist_thr = wm.ball().distFromSelf() * 0.1;
    if ( dist_thr < 1.0 ) dist_thr = 1.0;

    Vector2D homePos = target_point;
    Vector2D ballPos = wm.ball().pos();
    Vector2D me = wm.self().pos();
    int num = wm.self().unum();

    const int self_min = wm.interceptTable()->selfReachCycle();
    const int mate_min = wm.interceptTable()->teammateReachCycle();
    const int opp_min = wm.interceptTable()->opponentReachCycle();

    dlog.addText( Logger::TEAM,
                  __FILE__": Bhv_BasicMove" );


    // sending self information for requesting THP!
    ThroughPass().reciever_execute(agent);

//     // Omid View:
    axiom_view().default_execute(agent);

    // Omid Positioning:
    if (axiom_positioning().temp(agent))
    {
        //std::cout <<"\n cycle : " << wm.time().cycle() << "  POSITIONING 11 !!! ";
        return true;
    }

    // Obvious Itercept
    if ( amIIntercepter( agent ) )
    {
        // Omid View:
        axiom_view().default_execute(agent);
        return true;
    }


    // Positioning for THP receiving... By Omid




    if ( ( !wm.audioMemory().pass().empty() && wm.audioMemory().pass().front().receiver_ != wm.self().unum() )&&( num > 8 && ballPos.x < 40 && ballPos.x > -10 && me.dist( homePos ) < 10 &&
            me.x < wm.offsideLineX() - 2  &&  mate_min < opp_min && self_min > mate_min && wm.self().stamina() > 3500 /* {OMID} */
            && wm.self().distFromBall() > 3 ))
    {
        rcsc::Vector2D  home_omid_Pos = rcsc::Vector2D(wm.offsideLineX()-1.5,wm.self().pos().y) ;
        if (rcsc::Body_GoToPoint( home_omid_Pos, 1.5, rcsc::ServerParam::i().maxDashPower()*0.9,90,3,false ).execute( agent ))
        {
            // Omid View:
            axiom_view().default_execute(agent);
            return true;
        }
        

    }

    // End of Positioning for THP receiving... By Omid
    //-----------------------------------------------


    // tackle

    if (wm.ball().pos().x < -34 && fabs(wm.ball().pos().y)<17 && Bhv_DangerAreaTackle().execute( agent ) )
    {
        std::cout <<"\n cycle : " << wm.time().cycle() << "  Bhv_DangerAreaTackle_khatte 124 b_move. !!! ";
        // Omid View:
        axiom_view().default_execute(agent);
        return true;
    }

    if ( ! wm.existKickableTeammate() && wm.self().distFromBall() < 1.5 && wm.self().tackleProbability() > 0.85 )
    {
        if (  Bhv_BasicTackle( wm.self().tackleProbability(), 60.0 ).execute( agent ) )
        {
            std::cout <<"\n cycle : " << wm.time().cycle() << "  basic tackle  khatte 132 B-Move. !!! \n";

            axiom_view().default_execute(agent);
            return true;
        }
    }

    rcsc::Circle2D tackleOmidCircle = rcsc::Circle2D (wm.self().pos(),4);
    
 
    if ( wm.self().tackleProbability() > 0.78 && wm.self().distFromBall() < 1.5 )
    {
        if ( !(wm.self().pos().x > 5 && !wm.existOpponentIn<rcsc::Circle2D>(tackleOmidCircle,10,true) )
                && agent->world().ball().pos().x < X1 and Bhv_BasicTackle( wm.self().tackleProbability(), 60 ).execute(agent) ) //{OMID}
        {
    
            axiom_view().default_execute(agent);
            return true;
        }
    }

    // block
    if ( axiom_block( homePos ).execute( agent ) )
    {
        // Omid View:
        axiom_view().default_execute(agent);
        return true;
    }

   

    if ( ! wm.existKickableTeammate() &&  self_min <= mate_min && self_min < opp_min + 3 )
    {
        if (Body_Intercept().execute( agent ))
        {
            agent->setNeckAction( new Neck_OffensiveInterceptNeck() );
            return true;
        }
    }



    // mark
    if (Axiom_Mark().execute(agent))
        return true;







    // getBack when ja moondi!
    const double distFromHomePos = 10.0;
    if ( wm.ball().pos().x < wm.self().pos().x  && homePos.dist(wm.self().pos()) > distFromHomePos
            && wm.self().unum() < 6  && wm.self().unum() != 1 && ! wm.existKickableTeammate())
    {
        if (Body_GoToPoint( homePos, 0.3, ServerParam::i().maxDashPower() ,-1.0 ,100,false ).execute( agent ))
        {
            // Omid View:
            axiom_view().default_execute(agent);
            //std::cout<<" UNUM "<<wm.self().unum()<<" CYCLE "<<wm.time().cycle()<< " bodyGoToPoint homePos kharaki:D " <<std::endl;
            return true;
        }
    }

    // agha naro home pos to mohavate
    if ( wm.ball().pos().x < -36.0 and wm.ball().pos().absY() < 20.0
            and  ! wm.existKickableTeammate() and !wm.existKickableOpponent()  and self_min <= mate_min )
    {
        Body_GoToPoint( wm.ball().inertiaPoint(opp_min) , 0.3, ServerParam::i().maxDashPower() ,-1.0 ,100,false ).execute( agent );
        //  cout<<"naraftan be home pos to mohavate UNUM "<<agent->world().self().unum() << " cycle "<<agent->world().time().cycle()<<endl;
    }

    if ( ! Body_GoToPoint( homePos, dist_thr, dash_power ).execute( agent ) )
    {
        Body_TurnToBall().execute( agent );
        // Omid View:
        axiom_view().default_execute(agent);
    }

    if ( wm.existKickableOpponent() && wm.ball().distFromSelf() < 18.0 )
    {
        //agent->setNeckAction( new Neck_TurnToBall() );
        axiom_view().default_execute(agent);
    }


   return true;
}

bool Bhv_BasicMove::amIIntercepter(PlayerAgent* agent)
{
    const double X = 0.1;

    int self_min = agent->world().interceptTable()->selfReachCycle();
    int mate_min = agent->world().interceptTable()->teammateReachCycle();
    int opp_min = agent->world().interceptTable()->opponentReachCycle();
    const double mindistfromball = 3.0;
    if ( agent->world().ball().inertiaPoint(self_min).x > X && agent->world().self().unum() < 6 )
        return false;

    if ( agent->world().self().distFromBall() > mindistfromball )
    {

        if ( !(agent->world().existKickableOpponent()) && !(agent->world().existKickableTeammate()) && self_min <= opp_min  && self_min <= mate_min )
        {
            if ( Body_GoToPoint( agent->world().ball().inertiaPoint(self_min) , .3, ServerParam::i().maxDashPower() ,-1.0 ,100 ,false ,15.0 ).execute(agent) )
            {

                agent->setNeckAction( new Neck_TurnToBall() );
                return true;
            }
        }
    }
    else if ( !(agent->world().existKickableOpponent()) && !(agent->world().existKickableTeammate()) && self_min <= opp_min  && self_min <= mate_min )
    {
        if (Body_Intercept().execute( agent ))
        {

            agent->setNeckAction( new Neck_OffensiveInterceptNeck() );
            return true;
        } else if ( Body_GoToPoint( agent->world().ball().inertiaPoint(self_min) , .3, ServerParam::i().maxDashPower() ,-1.0 ,100 ,false ,15.0 ).execute(agent) )
        {

            agent->setNeckAction( new Neck_TurnToBall() );
            return true;
        }
    }
    return false;
}



