/**
 * DribbleNormal class
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Authors :  Mohammad Ghazanfari - Farbod Samsamipour
 * Copyright 2012
 * Allright Reserved
 */

#include <rcsc/action/body_stop_ball.h>
#include <rcsc/action/body_dribble.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/body_intercept.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/body_stop_ball.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/view_wide.h>
#include <rcsc/action/body_turn_to_point.h>
#include <rcsc/action/body_smart_kick.h>
#include <rcsc/action/neck_turn_to_ball_or_scan.h>
#include <rcsc/action/body_turn_to_ball.h>
#include <rcsc/action/body_kick_to_relative.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/body_clear_ball.h>

#include <rcsc/player/player_agent.h>
#include <rcsc/player/intercept_table.h>
#include <rcsc/player/debug_client.h>
#include <rcsc/player/ball_object.h>

#include <rcsc/common/logger.h>
#include <rcsc/common/logger.h>
#include <rcsc/common/server_param.h>

#include <rcsc/geom/sector_2d.h>

#include "bhv_dribble_normal.h"
#include "bhv_dribble_fast.h"
#include "strategy.h"

using namespace rcsc;
using namespace std;


// #include "dribble.h"
#include <rcsc/common/logger.h>
#include <rcsc/action/body_stop_ball.h>
// #include <rcsc/action/body_advance_ball.h>
#include <rcsc/action/body_dribble.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/body_intercept.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/body_stop_ball.h>
#include <rcsc/player/player_agent.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/view_wide.h>
#include <rcsc/player/intercept_table.h>
#include <rcsc/action/body_turn_to_point.h>
#include <rcsc/player/debug_client.h>
#include <rcsc/player/ball_object.h>
#include <rcsc/common/logger.h>
#include <rcsc/action/body_smart_kick.h>
#include <rcsc/action/neck_turn_to_ball_or_scan.h>
#include <rcsc/common/server_param.h>
#include <rcsc/geom/sector_2d.h>
#include <rcsc/action/body_turn_to_ball.h>
#include <rcsc/action/body_kick_to_relative.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/body_clear_ball.h>
#include "bhv_dribble_normal.h"
#include "bhv_dribble_fast.h"
#include "strategy.h"

using namespace rcsc;
using namespace std;

#if 0
bool BhvDribble::execute( rcsc::PlayerAgent * agent )
{
        const rcsc::WorldModel & wm = agent->world();
        rcsc::Vector2D target ( 52,0 );

        if ( Bhv_SelfPass().execute(agent) ) return true;
        target.assign(getTarget(agent).x, getTarget(agent).y );
        const int max_dash_step = wm.self().playerType().cyclesToReachDistance( wm.self().pos().dist( target ) );
        if ( dribble_fast(agent)) return true; /// do fast dribble

           if ( rcsc::Body_Dribble( target,
                            4.0,
                            rcsc::ServerParam::i().maxPower(),
                            std::min( 5, max_dash_step )
                            ).execute( agent ) )
           {
                        agent->setNeckAction( new rcsc::Neck_TurnToLowConfTeammate() );
             return true;
           }
           else {


// 	if (SRPDribble(agent,target,Vector2D (wm.self().pos().x+6, wm.self().pos().y ) ).execute( agent ) ) return true;
        const rcsc::PlayerObject * opp = wm.getOpponentNearestToSelf( 5 , true );
        if( opp->isTackling() || opp->kickRate() > 0.6 )
        {
                Vector2D newVec = rcsc::Vector2D::polar2vector( 3.0 , agent->world().self().body() );
                Vector2D newDribble = wm.self().pos() + newVec;
                if ( newDribble.absX() > 51.0 or newDribble.absY() > 33.0 )
                        newVec.setDir ( AngleDeg ( 0.0 ) );

                rcsc::Body_Dribble( wm.self().pos() + newVec, 0.4 , 70 , 3 , false );
                agent->setNeckAction( new rcsc::Neck_TurnToLowConfTeammate() );
                return true;
        }

        rcsc::Vector2D home_pos = Strategy::i().getPosition( agent->world().self().unum() );
        if ( ! home_pos.isValid() ) home_pos.assign( 0.0, 0.0 );

        double dist;



        switch ( Strategy::get_ball_area( wm.self().pos() ) ) {
        case Strategy::BA_CrossBlock:
        case Strategy::BA_Stopper:
        case Strategy::BA_Danger:
        case Strategy::BA_DribbleBlock:
        case Strategy::BA_DefMidField:
        case Strategy::BA_DribbleAttack:	dist = 5;
        case Strategy::BA_OffMidField:		dist = 3.5;
        case Strategy::BA_Cross:		dist = 3;
        case Strategy::BA_ShootChance:		dist = 2;
        default: 				dist = 4;
            break;
        }

        rcsc::Vector2D vec = get_avoid_point( agent, dist );
        if( vec == rcsc::Vector2D::INVALIDATED )
                vec = target;
        if ( dribble_fast ( agent ) ) return true;

        if ( vec.absX() > 50.0 || vec.absY() > 31 )
        {
                doRelaxDribble(agent);
                agent->setNeckAction( new rcsc::Neck_ScanField() );
                return true;
        }
        Vector2D target_all ( 49, 0 );
        const rcsc::PlayerObject * nearest_opp = wm.getOpponentNearestToSelf( 5 );
        const double nearest_opp_dist = ( nearest_opp
                                      ? nearest_opp->distFromSelf()
                                      : 1000.0 );
        const rcsc::Vector2D nearest_opp_pos = ( nearest_opp
                                             ? nearest_opp->pos()
                                             : rcsc::Vector2D( -1000.0, 0.0 ) );
        rcsc::Circle2D CIR( wm.self().pos() , 4 );
        //if ( doRelaxDribble( agent, nearest_opp ) )    return true; /// do relax dribble
        if ( (wm.self().pos().y > 41 or wm.self().pos().y < -41) and ( wm.self().pos().x > 48 ) )  /// do cross dribble
        {
          rcsc::Body_Dribble( target_all,
                            1.0,
                            rcsc::ServerParam::i().maxPower(),
                            2
                            ).execute( agent );
        }
        if ( dribble_fast(agent)) return true; /// do fast dribble
        else {
                doRelaxDribble(agent);
            const int max_dash_step = wm.self().playerType().cyclesToReachDistance( wm.self().pos().dist( vec ) );

        if ( wm.self().unum() != 2 or
             wm.self().unum() != 4 or
             wm.self().unum() != 3 or
// 	     wm.self().unum() != 6 or
             wm.self().unum() != 5 )
        {
            rcsc::Body_Dribble( target_all,
                            1.0,
                            rcsc::ServerParam::i().maxPower(),
                            std::min( 5, max_dash_step )
                            ).execute( agent );
                }
        }




        return true;
           }
}
#endif
bool BhvDribble::can_kick_after_dash( rcsc::PlayerAgent * agent , double & p )
{
        const rcsc::WorldModel & wm = agent->world();
        double max_dist				= wm.self().playerType().kickableArea();

        // create ball + vel & self + vel
        // check now and after distance
    rcsc::AngleDeg accel_angle = ( p < 0.0
                             ? wm.self().body() - 180.0
                             : wm.self().body() );
        const double max_accel_mag = ( std::fabs( p ) * wm.self().playerType().dashPowerRate() * wm.self().effort() );
        double accel_mag = max_accel_mag;
        if ( wm.self().playerType().normalizeAccel( wm.self().vel() , accel_angle, &accel_mag ) )
                    p *= accel_mag / max_accel_mag;
        rcsc::Vector2D dash_accel = rcsc::Vector2D::polar2vector( accel_mag, accel_angle );

        rcsc::Vector2D vel_self 	= wm.self().pos() + wm.self().vel();
        rcsc::Vector2D vel_ball 	= wm.ball().pos() + wm.ball().vel();
        if( dash_accel.dist( wm.self().pos() ) < max_dist && wm.ball().distFromSelf() < max_dist && std::fabs( ((vel_ball - wm.self().pos() ).th() - accel_angle).degree() ) < 150 )
                return true;
        return false;
}

bool BhvDribble::do_turn_without_ball( rcsc::PlayerAgent * agent , const rcsc::AngleDeg ang )
{
        const rcsc::WorldModel & wm = agent->world();
        if( agent->doTurn( ang - wm.self().body() ) )
        {
                agent->setNeckAction( new rcsc::Neck_TurnToLowConfTeammate() );
                return true;
        }
        return false;
}


bool BhvDribble::kick_ball_avoid( rcsc::PlayerAgent* agent )
{
        const rcsc::WorldModel & wm = agent->world();
        rcsc::AngleDeg ang_kick		= find_avoid_angle( agent );

}

rcsc::AngleDeg BhvDribble::find_avoid_angle( rcsc::PlayerAgent * agent )
{
        const rcsc::WorldModel & wm = 	agent->world();
        const rcsc::PlayerObject * opp  = static_cast< rcsc::PlayerObject * >( 0 ) ;
        opp = wm.getOpponentNearestToSelf( 8 , true );
        if( opp == static_cast< rcsc::PlayerObject * >( 0 ) )
        {
                //std::cout<<" [Dribble] -> NO OBJECT FOUND ...\n";
                return 0.0;
        }
        rcsc::AngleDeg ang_opp		= 	opp->angleFromSelf();
        rcsc::AngleDeg ang_rel_goal =   ( rcsc::Vector2D( 50.0 , 0.0 ) - wm.self().pos() ).th();
        rcsc::AngleDeg ang 			= ang_opp - ang_rel_goal;
        double dist					=	opp->distFromSelf();
        rcsc::AngleDeg rel			=	0.0;
        double sign					=   ang.degree() < 0 ? -1 : 1;
        rcsc::Vector2D pos_opp 		= opp->pos();
        if( dist < 4.0 )
                rel = sign == 1 ? ang_opp - 120 : ang_opp + 120 ;
        else if( std::fabs( ang.degree() ) > 120 )
                rel = ang_rel_goal ;
        else if( std::fabs( ang.degree() ) > 70 )
                rel = sign == 1 ? ang - 100 : ang + 100;
        else if( std::fabs( ang.degree() ) > 40 )
                rel = sign == 1 ? ang - 90 : ang + 90;
        else
                rel = sign == 1 ? ang - 40 : ang + 40;
        rel = rel.normalize_angle( rel.degree() );
        return rel;
}

rcsc::Vector2D
BhvDribble::get_avoid_point( rcsc::PlayerAgent * agent, double polar_dist )
{
        const rcsc::WorldModel & wm = agent->world();
        rcsc::Vector2D send = rcsc::Vector2D::INVALIDATED;
        rcsc::Vector2D goal( 50.0 , 0.0 );
        rcsc::AngleDeg ang = (goal - wm.self().pos() ).th();
        rcsc::Segment2D seg( wm.self().pos() , 10 , ang );
        rcsc::Vector2D pos_opp , vel_opp;
        rcsc::PlayerPtrCont opps = wm.opponentsFromBall();
        if( opps.empty() )
                return send;
        rcsc::PlayerPtrCont::const_iterator end = opps.end();
        bool isGood = true;
        /*for( rcsc::PlayerPtrCont::const_iterator t = opps.begin() ; t != end ; t++ )
        {
                //if( !(*t)->posValid() ) continue;
                if( (*t)->posCount() > 9 ) continue;
                if( (*t)->isGhost() ) continue;
                if( (*t)->pos().x < wm.self().pos().x ) continue;
                if( (*t)->isTackling() ) return wm.self().pos() + rcsc::Vector2D::polar2vector( 3.0 , 170 );
                if( (*t)->distFromBall() > 20 ) break;

                pos_opp = (*t)->pos();
                vel_opp = (*t)->velValid() ? (*t)->vel() : rcsc::Vector2D::polar2vector( 1.0 , 0.0 );
                rcsc::AngleDeg angel = ang.degree() < 0 ? ang + 90 : ang - 90 ;
                rcsc::Line2D line( pos_opp + vel_opp , angel );
                rcsc::Vector2D inter = seg.intersection( line );
                if( inter == rcsc::Vector2D::INVALIDATED ) continue;
                else if( inter.dist( pos_opp + vel_opp ) < 5.0 )
                        isGood = false;
        }
        if( isGood )
                return wm.self().pos() + rcsc::Vector2D::polar2vector( 4 , ang );
        */// no any found , so start other

/*	pos_opp = wm.interceptTable()->fastestOpponent()->pos();
        vel_opp = wm.interceptTable()->fastestOpponent()->vel();
        if( pos_opp.dist( wm.ball().pos() ) < 5.0 )
        {
                if( ! pos_opp.valid() ) return wm.self().inertiaFinalPoint();
                rcsc::Circle2D my( wm.self().pos() , 8 );
                rcsc::Circle2D op( pos_opp + vel_opp , 7 );
                rcsc::Vector2D int1 , int2;
                my.intersection( op , &int1 , &int2 );
                if( int2.x > int1.x ) int1 = int2;
                rcsc::AngleDeg a = ( int1 - wm.self().pos() ).th();
                return wm.self().pos() + rcsc::Vector2D::polar2vector( 4.0 , a );
                //return wm.self().pos() + rcsc::Vector2D::polar2vector( 4.0 , 0.0 );
        }*/

        //else
                return wm.self().pos() + rcsc::Vector2D::polar2vector( polar_dist , find_avoid_angle( agent ) );
}

bool
BhvDribble::dribble_fast( rcsc::PlayerAgent* agent )
{

    const rcsc::WorldModel & wm = agent->world();
    const rcsc::PlayerObject * nearest_opp = wm.getOpponentNearestToSelf( 5 );
    const double nearest_opp_dist = ( nearest_opp
                                      ? nearest_opp->distFromSelf()
                                      : 1000.0 );
    const rcsc::Vector2D nearest_opp_pos = ( nearest_opp
                                             ? nearest_opp->pos()
                                             : rcsc::Vector2D( -1000.0, 0.0 ) );

    rcsc::Vector2D  ball_pos = wm.ball().pos();

    rcsc::Vector2D drib_target( 49.0, wm.self().pos().absY() );
//     if ( ball_pos.x > 36.0 )
//     {
//         if ( ball_pos.absY() > 17.0 )
//         {
//
// 	      drib_target.x = 52;
// 	      drib_target.y = 24;
//
//         }
//         else
//         {
// 	      drib_target.x = 52;
// 	      drib_target.y = 8;
//
//         }
//     }
//     else if ( ball_pos.x > -1.0 )
//     {
//         if ( ball_pos.absY() > 17.0 )
//         {
// 	      drib_target.x = 52;
// 	      drib_target.y = 24;
//         }
//         else
//         {
//
// 	      drib_target.x = 0;
// 	      drib_target.y = 24;
//
//         }
//     }
//     else if ( ball_pos.x > -30.0 )
//     {
//         if ( ball_pos.absY() > 17.0 )
//         {
//             rcsc::dlog.addText( rcsc::Logger::TEAM,
//                                 __FILE__": get_ball_area: DribbleBlock" );
//             return BA_DribbleBlock;
//         }
//         else
//         {
//             rcsc::dlog.addText( rcsc::Logger::TEAM,
//                                 __FILE__": get_ball_area: DefMidField" );
//             return BA_DefMidField;
//         }
//     }
//     else if ( ball_pos.x > -36.5 )
//     {
//         if ( ball_pos.absY() > 17.0 )
//         {
// 	      drib_target.x = 52;
// 	      drib_target.y = 24;
//
//         }}
    if ( drib_target.y > 20.0 )
          drib_target.y = 20.0;
    else if ( drib_target.y > 10.0 )
          drib_target.y = 10.0;
    if ( wm.self().pos().x > 25.0 )
          drib_target.y = 5.0;
    if ( wm.self().pos().y < 0.0 )
          drib_target.y *= -1.0;


/*        else
        {
            rcsc::dlog.addText( rcsc::Logger::TEAM,
                                __FILE__": get_ball_area: Stopper" );
            return BA_Stopper;
        }
    }*/
//     else
//     {
//         if ( ball_pos.absY() > 17.0 )
//         {
//             rcsc::dlog.addText( rcsc::Logger::TEAM,
//                                 __FILE__": get_ball_area: CrossBlock" );
//             return BA_CrossBlock;
//         }
//         else
//         {
//             rcsc::dlog.addText( rcsc::Logger::TEAM,
//                                 __FILE__": get_ball_area: Danger" );
//             return BA_Danger;
//         }
//     }
//
//     rcsc::dlog.addText( rcsc::Logger::TEAM,
//                         __FILE__": get_ball_area: unknown area" );
//     return BA_None;



    const rcsc::AngleDeg drib_angle = ( drib_target - wm.self().pos() ).th();
    if ( nearest_opp_pos.x < wm.self().pos().x
         || ( nearest_opp_dist > 2.0
              && nearest_opp_pos.x < wm.self().pos().x + 1.0 )
         )
    {
        const rcsc::Sector2D sector( wm.self().pos(),
                                     0.5, 15.0,
                                     drib_angle - 30.0,
                                     drib_angle + 30.0 );
        if ( ! wm.existOpponentIn( sector, 10, true ) )
        {
            const int max_dash_step
                = wm.self().playerType()
                .cyclesToReachDistance( wm.self().pos().dist( drib_target ) );
            if ( wm.self().pos().x > 35.0 )
            {
            drib_target.x = 47;
            drib_target.y *= ( 10.0 / fabs(drib_target.y) );
            }
            rcsc::Body_Dribble( drib_target,
                                    1.0,
                                    rcsc::ServerParam::i().maxPower(),
                                    std::min( 5, max_dash_step )
                                    ).execute( agent );
                agent->setNeckAction( new rcsc::Neck_ScanField() );
        return true;
        }
        else
        {
            rcsc::Body_Dribble( drib_target,
                                    1.0,
                                    rcsc::ServerParam::i().maxPower(),
                                    2
                                    ).execute( agent );

        }
        agent->setNeckAction( new rcsc::Neck_ScanField() );
        return true;
    }


return false;
}
bool
BhvDribble::doRelaxDribble( rcsc::PlayerAgent * agent )
{
    const rcsc::WorldModel & wm = agent->world();
    const rcsc::Vector2D body_dir_drib_target
        = wm.self().pos()
        + rcsc::Vector2D::polar2vector( 5.0, wm.self().body() );

    if ( body_dir_drib_target.x > rcsc::ServerParam::i().pitchHalfLength() - 1.0
         || body_dir_drib_target.absY() > rcsc::ServerParam::i().pitchHalfWidth() - 1.0  )
    {
        return false;
    }

    int max_dir_count = 0;
    wm.dirRangeCount( wm.self().body(), 20.0, &max_dir_count, NULL, NULL );
    if ( max_dir_count >= 4 )
    {
        return false;
    }
    const rcsc::Sector2D sector( wm.self().pos(),
                                 0.5, 10.0,
                                 wm.self().body() - 30.0,
                                 wm.self().body() + 30.0 );
    if ( wm.existOpponentIn( sector, 10, true ) )
    {
        return false;
    }

    Vector2D target_ ( 49, 0 );
//     Vector2D up ( 48, 30 );
//     Vector2D down ( 48, -30 );
  if ( (wm.self().pos().y > 41 or wm.self().pos().y < -41) and ( wm.self().pos().x > 48 ) )
{    rcsc::Body_Dribble( target_,
                            1.0,
                            rcsc::ServerParam::i().maxPower(),
                            2
                            ).execute( agent );
   agent->setNeckAction( new rcsc::Neck_ScanField() );
}

// if ( wm.self().pos().dist( up  ) < 5 )  body_dir_drib_target.y = 0;
// if ( wm.self().pos().dist( down  ) < 5 )  body_dir_drib_target.y = 0 ;

    rcsc::Body_Dribble( body_dir_drib_target,
                            1.0,
                            rcsc::ServerParam::i().maxPower(),
                            1
                            ).execute( agent ); //cout<<"AVOID"<<endl;

    agent->setNeckAction( new rcsc::Neck_ScanField() );
    return true;
}

rcsc::Vector2D
BhvDribble::getTarget( rcsc::PlayerAgent * agent )
{

      Vector2D pos_agent=agent->world().self().pos();
      Vector2D target_point (52.5 , 0.0);
    if (pos_agent.x < 52.5 and pos_agent.x >36.5 and pos_agent.y < 17 and pos_agent.y >-17)

        Vector2D target_point(52.5 , 0.0);

    if (pos_agent.x < 52.5 and pos_agent.x >36.5 and pos_agent.y < -17 and pos_agent.y >-34)

        Vector2D target_point(49.0 , -5.0);

    if (pos_agent.x < 52.5 and pos_agent.x >36.5 and pos_agent.y < 34 and pos_agent.y >17)

        Vector2D target_point(49.0 , 5.0);

    if (pos_agent.x < 36.5 and pos_agent.x >0 and pos_agent.y < -15 and pos_agent.y >-34)

        Vector2D target_point(45.5 , -25.0);

    if (pos_agent.x < 36.5 and pos_agent.x >0 and pos_agent.y < 34 and pos_agent.y > 15)

        Vector2D target_point(45.5 , 25.0);

    if (pos_agent.x < 36.5 and pos_agent.x > 0 and pos_agent.y < 15 and pos_agent.y >-15)

        Vector2D target_point((pos_agent.x+10.0),pos_agent.y);

    return target_point;

}

// 7 April
#if 1
bool BhvDribble::execute( rcsc::PlayerAgent * agent )
{
    const rcsc::WorldModel & wm = agent->world();
    rcsc::Vector2D target ( 52,0 );

    if ( Bhv_SelfPass().execute(agent) ) // check SRP dribble (Bhv_SelfPass)
      return true;

    target = findBestVec(agent);
    if ( wm.ball().pos().x > 40 )
    {
      if ( rcsc::Body_Dribble(  rcsc::Vector2D( 52,0 ) , 0.3,
                    rcsc::ServerParam::i().maxDashPower(), 2 ).execute(agent))
      {
        agent->setNeckAction(new rcsc::Neck_ScanField() );
        return true;
      }
    }
    
    
    /****************************** Mohammad **************************/
    
    if ( wm.self().pos().x > 5 && wm.self().pos().x < 35 && wm.self().pos().absY() < 15 )
    {
        int num_of_opp_forward = 0;
        const PlayerPtrCont::const_iterator o_end = wm.opponentsFromSelf().end();
        for ( PlayerPtrCont::const_iterator it = wm.opponentsFromSelf().begin(); it != o_end; ++it )
        {
	    if ( (*it)->goalie() )	continue;
	    if ( (*it)->posCount() > 5 )	continue;
	    
	    if ( (*it)->pos().x > wm.self().pos().x + 1 )
	    {
	      num_of_opp_forward++;
	    }
        }
        
        if( num_of_opp_forward > 1 )
	{
	  Sector2D dribble_sector( wm.self().pos() , 0.5 , 12 , wm.self().body()-20 , wm.self().body()+20 );
	  if ( wm.existOpponentIn<Sector2D>(dribble_sector,5,false) )
	  {
	    Vector2D target(wm.self().pos().x + 3 , wm.self().pos().y < 0 ? wm.self().pos().y-7 : wm.self().pos().y+7 );
	    if ( target.absY() < 20 )
	    {
	      if ( rcsc::Body_Dribble(  target  , 0.3,
                  rcsc::ServerParam::i().maxDashPower(), 2 ).execute(agent))
	      {
		  agent->setNeckAction(new rcsc::Neck_ScanField());
		  return true;
	      }
	    }
// 	    else
// 	    {
// 	      target.y = wm.self().pos().y < 0 ? wm.self().pos().y+7 : wm.self().pos().y-7;
// 	      if ( rcsc::Body_Dribble(  target  , 0.3,
//                   rcsc::ServerParam::i().maxDashPower(), 2 ).execute(agent))
// 	      {
// 		  agent->setNeckAction(new rcsc::Neck_ScanField());
// 		  return true;
// 	      }
// 	    }
	  }
	}
        
//         const PlayerPtrCont::const_iterator t_end = wm.teammatesFromSelf().end();
//         for ( PlayerPtrCont::const_iterator it = wm.teammatesFromSelf().begin(); it != t_end; ++it )
//         {
// 	    
// 	}
    }
    
    
    /***************************** end of Mohammad ********************/
    
    
    // {OMID}

    rcsc::Circle2D emptyCircle (wm.self().pos(),9.0) ;
    
    if(wm.self().pos().x > 0 && !wm.existOpponentIn<rcsc::Circle2D>(emptyCircle,10,true) )
    {
      if(rcsc::Body_HoldBall(true,rcsc::Vector2D(52.0,0.0)).execute(agent))
	return true;
    }
    
      
    // {END OF OMID}
    
    
    
    if ( rcsc::Body_Dribble(  target + wm.self().pos() , 0.3,
                  rcsc::ServerParam::i().maxDashPower(), 2 ).execute(agent))
    {
      agent->setNeckAction(new rcsc::Neck_ScanField());
      return true;
    }

    return false;

}

rcsc::Vector2D
BhvDribble::findBestVec( rcsc::PlayerAgent * agent )
{
      const rcsc::WorldModel & wm = agent->world();
      rcsc::Vector2D vertex [5];
      rcsc::Vector2D target = wm.self().pos();

      vertex[0] =
      rcsc::Vector2D::polar2vector( 5, ( rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() );

      vertex[1] =
      rcsc::Vector2D::polar2vector( 5, ( rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() + 30 );

      vertex[2] =
      rcsc::Vector2D::polar2vector( 5, ( rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() + 60 );

      vertex[3] =
      rcsc::Vector2D::polar2vector( 5, ( rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() - 30 );

      vertex[4] =
      rcsc::Vector2D::polar2vector( 5, ( rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() - 60 );

      std::vector<rcsc::Vector2D> V[3];
      V[0].push_back(vertex[0]);
      V[0].push_back(vertex[1]);
      V[0].push_back(vertex[3]);

      V[1].push_back(vertex[0]);
      V[1].push_back(vertex[1]);
      V[1].push_back(vertex[2]);

      V[2].push_back(vertex[0]);
      V[2].push_back(vertex[3]);
      V[2].push_back(vertex[4]);


      rcsc::Polygon2D tri_0 (  V[0] ); // center
      rcsc::Polygon2D tri_1 (  V[1] ); // up
      rcsc::Polygon2D tri_2 (  V[2] ); // down

      std::pair < rcsc::Polygon2D , rcsc::Vector2D > triangle_targets[3];
      triangle_targets[0].first = tri_0;
      triangle_targets[0].second =
      rcsc::Vector2D::polar2vector( 5, (rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() );

      triangle_targets[1].first = tri_1;
      triangle_targets[1].second =
      rcsc::Vector2D::polar2vector( 5, (rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() + 60 );

      triangle_targets[2].first = tri_2;
      triangle_targets[2].second =
      rcsc::Vector2D::polar2vector( 5, (rcsc::Vector2D( 52, wm.self().pos().y ) - wm.self().pos()  ).th() - 60 );

      std::pair< std::pair< rcsc::Polygon2D, rcsc::Vector2D > , std::pair< double ,int > > targets[3];
      std::pair< std::pair< rcsc::Polygon2D, rcsc::Vector2D > , std::pair< double ,int > > temp;
      targets[0].first.first = triangle_targets[0].first;
      targets[0].first.second = triangle_targets[0].second;
      targets[0].second.first = triangle_targets[0].second.dist( rcsc::Vector2D( 52, 0 ) );
      targets[0].second.second = wm.countOpponentsIn(triangle_targets[0].first,15,false);

      targets[1].first.first = triangle_targets[1].first;
      targets[1].first.second = triangle_targets[1].second;
      targets[1].second.first = triangle_targets[1].second.dist( rcsc::Vector2D( 52, 0 ) );
      targets[1].second.second = wm.countOpponentsIn(triangle_targets[1].first,15,false);

      targets[2].first.first = triangle_targets[2].first;
      targets[2].first.second = triangle_targets[2].second;
      targets[2].second.first = triangle_targets[2].second.dist( rcsc::Vector2D( 52, 0 ) );
      targets[2].second.second = wm.countOpponentsIn(triangle_targets[2].first,15,false);
      /*
      if ( wm.self().pos().x > 30 )
      {
        if ( wm.self().pos().absY() <= 17 )
        {
          if ( targets[0].second.second == 0 )
          {
            target = targets[0].first.second;
          }

          else if ( targets[1].second.second == 0 and targets[2].second.second == 0 and
            targets[1].second.first < targets[2].second.first )
          {
            target = targets[1].first.second;
          }
          else if ( targets[2].second.second == 0 )
          {
            target = targets[2].first.second;
          }
        }
        if ( wm.self().pos().y > 17 )
        {
          if ( targets[0].second.second == 0 and
               targets[1].second.second == 0  and
               targets[2].second.second == 0  )
          {
              for ( int i = 0 ; i < 3 - 1 ; i ++ )
              {
                  for ( int j = 0 ; j < 3 - 1 ; j ++)
                  {
                      if ( targets[j+1].second.first  > targets[j].second.first )
                      {

                          temp = targets[j];
                          targets[j] = targets[j+1];
                          targets[j+1] = targets;

                      }
                  }
              }
          }
          target = targets[2].first.second;
        }
        if ( wm.self().pos().y < -17 )
        {
          if ( targets[1].second.second == 0 )
          {
            target = targets[1].first.second;
          }
          else if ( targets[2].second.second == 0 and targets[0].second.second == 0 and
            targets[0].second.first < targets[2].second.first )
          {
            target = targets[0].first.second;
          }
          else if ( targets[2].second.second == 0 )
          {
            target = targets[2].first.second;
          }
        }
      }
      else
      {
          if ( targets[0].second.second == 0 )
          {
            target = targets[0].first.second;
          }
          else if (  targets[1].second.second == 0 and targets[2].second.second == 0 and
            targets[1].second.first < targets[2].second.first )
          {
            target = targets[1].first.second;
          }
          else if ( targets[2].second.second == 0 )
          {
            target = targets[2].first.second;
          }
      }
      */

          {
              for ( int i = 0 ; i < 3  ; i ++ )
              {
                  for ( int j = 0 ; j < 3  ; j ++)
                  {
                      if ( targets[j+1].second.first  > targets[j].second.first )
                      {

                          temp = targets[j];
                          targets[j] = targets[j+1];
                          targets[j+1] = temp;

                      }
                  }
              }
          }
          if ( targets[2].second.second == 0 )
            target = targets[2].first.second ;
          else if ( targets[1].second.second == 0 ) target = targets[1].first.second ;
          else if ( targets[0].second.second == 0 ) target = targets[0].first.second ;


      return target;
}


rcsc::Vector2D
BhvDribble::pointExecuter( rcsc::PlayerAgent * agent )
{
    const rcsc::WorldModel & wm = agent->world();
    rcsc::Vector2D target ( 52,0 );
    target = findBestVec(agent);
    return ( target + wm.self().pos() );
}
#endif
