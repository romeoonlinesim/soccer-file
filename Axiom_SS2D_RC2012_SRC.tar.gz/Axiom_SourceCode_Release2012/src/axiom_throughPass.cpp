
/**
 * bhv_through_pass.cpp
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Authors : Mohammad Ghazanfari, Omid Shirkhorshidi
 * Copyright 2012
 * Allright Reserved
 */

#include "axiom_throughPass.h"
#include <rcsc/common/server_param.h>
#include <rcsc/player/intercept_table.h>
#include <rcsc/player/say_message_builder.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>
#include <rcsc/action/neck_turn_to_point.h>
#include <rcsc/geom/polygon_2d.h>
#include <rcsc/geom/segment_2d.h>
#include <rcsc/geom/circle_2d.h>
#include <rcsc/action/body_kick_one_step.h>
#include <rcsc/action/body_smart_kick.h>
#include <rcsc/action/body_go_to_point.h>
#include <rcsc/action/body_turn_to_point.h>
#include <rcsc/action/body_intercept.h>
#include <rcsc/player/soccer_intention.h>
#include <rcsc/player/player_object.h>
#include <rcsc/player/free_message.h>
#include <string.h>
#include <rcsc/player/audio_sensor.h>

#include "sample_player.h"
#include <rcsc/action/view_wide.h>
#include<sample_communication.h>


using namespace std;

using namespace rcsc;


bool ThroughPass::reciever_execute(rcsc::PlayerAgent* agent)
{

    const rcsc::WorldModel & wm = agent->world();
    if (wm.self().unum() >= 9 )
    {
        agent->addSayMessage( new SelfMessage(wm.self().pos(), wm.self().body(), wm.self().stamina()));
        return true;
    }

    return false;
}

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
////////////////////////            SENDER           ////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

bool ThroughPass::sender_execute(rcsc::PlayerAgent* agent)
{

    const rcsc::WorldModel & wm = agent->world();

    if ( wm.self().pos().x <= -17 || ( wm.self().pos().x > 35.5 && fabs(wm.self().pos().y) < 18 )  )
    {
        return false;
    }

    bool isNineRequesting = false;
    bool isTenRequesting = false;
    bool isElevenRequesting = false;

    rcsc::Vector2D nine_bestPassPoint(-52,-30);
    bool nine_bestPassPoint_isFound = false;

    rcsc::Vector2D ten_bestPassPoint(-52,-30);
    bool ten_bestPassPoint_isFound = false;

    rcsc::Vector2D eleven_bestPassPoint(-52,-30);
    bool eleven_bestPassPoint_isFound = false;

    std::vector<rcsc::AudioMemory::Player> hear = wm.audioMemory().player();

    if (hear.empty())
    {
        return false;
    }

    rcsc::Vector2D nine_thp_rec_pos(-100.0,-100.0);
    rcsc::Vector2D ten_thp_rec_pos(-100.0,-100.0);
    rcsc::Vector2D elv_thp_rec_pos(-100.0,-100.0);

    for (unsigned int i = 0 ; i < hear.size() ; i ++ )
    {

        int thp_rec_unum = hear.at(i).unum_;
        rcsc::Vector2D thp_rec_pos = hear.at(i).pos_;
        int thp_rec_stamina = hear.at(i).stamina_;

        if ( thp_rec_unum == -1 || thp_rec_unum > 11 || thp_rec_stamina < 1500 ||   wm.audioMemory().playerTime().cycle() < wm.time().cycle()-3 )
            continue;

        if (thp_rec_unum == 9 && wm.self().unum() != 9)
        {
            isNineRequesting = true;
            nine_thp_rec_pos = thp_rec_pos;
        }
        else if (thp_rec_unum == 10 && wm.self().unum() != 10)
        {
            isTenRequesting = true;
            ten_thp_rec_pos = thp_rec_pos;
        }
        else if (thp_rec_unum == 11 && wm.self().unum() != 11)
        {
            isElevenRequesting = true;
            elv_thp_rec_pos = thp_rec_pos;
        }
    }
    
    if( wm.self().pos().x > 29 && fabs(wm.self().pos().y) > 19 )
    {
      isNineRequesting = false;
      nine_thp_rec_pos = rcsc::Vector2D(-52.0,-30.0);
      isTenRequesting = false;
      ten_thp_rec_pos = rcsc::Vector2D(-52.0,-30.0);
    }


    double first_Ball_Speed = 0;
    bool flag = false;

    double distDifference =  0.0;
    double max_distDifference = -1000.0;
    double * distFromThpPointToNearestOpp = NULL;


    // NINE REQUESTING PART :


    if ( isNineRequesting && nine_thp_rec_pos.x < wm.offsideLineX() && (wm.self().unum() != 9) )
    {

        // for priority No.2
        for (double j = 30+1.666 ; j < 50 && !(nine_bestPassPoint_isFound) ; j += 3.333 )
        {
            for (double i = -12-1.666 ; i > -22 && !(nine_bestPassPoint_isFound) ; i -= 3.333 )
            {
                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , nine_thp_rec_pos , rcsc::Vector2D(j,i) );
		

                if ( (rcsc::Vector2D(j,i).dist(nine_thp_rec_pos)<22 ) && (j > getLocalOffsideLine(9,agent).x ) &&  !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > nine_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  nine_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        nine_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }


            }
        }

        if ( nine_bestPassPoint.x != -52 )
        {
            nine_bestPassPoint_isFound = true;
        }

        flag = false;
        // for priority No.3
        for (double j = 30-1.666 ; j > 10 && !(nine_bestPassPoint_isFound) ; j -= 3.333 )
        {
            for (double i = -12-1.666 ; i > -32 && !(nine_bestPassPoint_isFound) ; i -= 3.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , nine_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (rcsc::Vector2D(j,i).dist(nine_thp_rec_pos)<22 ) && (j > getLocalOffsideLine(9,agent).x ) && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > nine_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45))
                {

                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  nine_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        nine_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( nine_bestPassPoint.x != -52 )
        {
            nine_bestPassPoint_isFound = true;
        }

        flag = false;
        // for priority No.5
        for (double j = 30+1.666 ; j < 50 && !(nine_bestPassPoint_isFound)  ; j += 3.333 )
        {
            for (double i = -22-1.666 ; i > -32 && !(nine_bestPassPoint_isFound)  ; i -= 3.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , nine_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (rcsc::Vector2D(j,i).dist(nine_thp_rec_pos)<22 ) && (j > getLocalOffsideLine(9,agent).x ) && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > nine_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45)  )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  nine_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        nine_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( nine_bestPassPoint.x != -52 )
        {
            nine_bestPassPoint_isFound = true;
        }

    }


    /////////////End Of NineRequestin PART !!! ///////////////////////////
    /////////////End Of NineRequestin PART !!! ///////////////////////////
    /////////////End Of NineRequestin PART !!! ///////////////////////////
    /////////////End Of NineRequestin PART !!! ///////////////////////////


    // TEN REQUESTING PART :
    distDifference = 0.0;
    max_distDifference = -1000.0;
    flag = false;

    if ( isTenRequesting && ten_thp_rec_pos.x < wm.offsideLineX() && (wm.self().unum() != 10) )
    {

        // for priority No.2
        for (double j = 30+1.666 ; j < 50 && !(ten_bestPassPoint_isFound) ; j += 3.333 )
        {
            for (double i = 12+1.666 ; i < 22 && !(ten_bestPassPoint_isFound)  ; i += 3.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , ten_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (rcsc::Vector2D(j,i).dist(ten_thp_rec_pos)<22 ) && (j > getLocalOffsideLine(10,agent).x ) &&  !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > ten_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  ten_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        ten_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }


            }
        }


        if ( ten_bestPassPoint.x != -52 )
        {
            ten_bestPassPoint_isFound = true;
        }

        flag = false;
        // for priority No.3
        for (double j = 30-1.666 ; j > 10 && !(ten_bestPassPoint_isFound)  ; j -= 3.333 )
        {
            for (double i = 12+1.666 ; i < 32 && !(ten_bestPassPoint_isFound)  ; i += 3.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , ten_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (rcsc::Vector2D(j,i).dist(ten_thp_rec_pos)<22 ) && (j > getLocalOffsideLine(10,agent).x ) && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed ))  && ( j > ten_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  ten_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        ten_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( ten_bestPassPoint.x != -52 )
        {
            ten_bestPassPoint_isFound = true;
        }



        flag = false;
        // for priority No.5
        for (double j = 30+1.666 ; j < 50 && !(ten_bestPassPoint_isFound)  ; j += 3.333 )
        {
            for (double i = 22+1.666 ; i < 32 && !(ten_bestPassPoint_isFound)  ; i += 3.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , ten_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (rcsc::Vector2D(j,i).dist(ten_thp_rec_pos)<22 ) && (j > getLocalOffsideLine(10,agent).x ) && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed ))  && ( j > ten_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  ten_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        ten_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( ten_bestPassPoint.x != -52 )
        {
            ten_bestPassPoint_isFound = true;
        }


    }

    /////////////End Of TenRequestin PART !!! ///////////////////////////

#if 1
    // Eleven REQUESTING PART :

    distDifference = 0.0;
    max_distDifference = -1000.0;
    flag = false;



    if (  isElevenRequesting && elv_thp_rec_pos.x < wm.offsideLineX() && !(eleven_bestPassPoint_isFound) && (wm.self().unum() != 11) )
    {

        // 1) for priority No.1 : 11.7 , 11.8
        for (double j = 23.5 ; j < 40 && !(eleven_bestPassPoint_isFound)  ; j += 3.0 )
        {
            for (double i = 4-1.333 ; i > -4 && !(eleven_bestPassPoint_isFound)  ; i -= 1.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , elv_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (j > getLocalOffsideLine(11,agent).x )-7 && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed ))  && ( j > elv_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {



                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  elv_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        eleven_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }


        if ( eleven_bestPassPoint.x != -52 )
        {
            eleven_bestPassPoint_isFound = true;
        }



        flag = false;
        // 2) for priority No.1 : 11.12
        for (double j = 32.5 ; j < 40 && !(eleven_bestPassPoint_isFound)  ; j += 3.0 )
        {
            for (double i = 12-1.333 ; i > 4 && !(eleven_bestPassPoint_isFound)  ; i -= 1.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , elv_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (j > getLocalOffsideLine(11,agent).x )-7 && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > elv_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  elv_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        eleven_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( eleven_bestPassPoint.x != -52 )
        {
            eleven_bestPassPoint_isFound = true;
        }

        flag = false;
        // 3) for priority No.1 : 11.4
        for (double j = 32.5 ; j < 40 && !(eleven_bestPassPoint_isFound)  ; j += 3.0 )
        {
            for (double i = -4-1.333 ; i > -12 && !(eleven_bestPassPoint_isFound)  ; i -= 1.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , elv_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (j > getLocalOffsideLine(11,agent).x )-7 && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > elv_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  elv_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        eleven_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( eleven_bestPassPoint.x != -52 )
        {
            eleven_bestPassPoint_isFound = true;
        }

        flag = false;
        // 4) for priority No.2 : 11.3
        for (double j = 29.5 ; j > 22 && !(eleven_bestPassPoint_isFound)  ; j -= 3.0 )
        {
            for (double i = -4-1.333 ; i > -12 && !(eleven_bestPassPoint_isFound)  ; i -= 1.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , elv_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (j > getLocalOffsideLine(11,agent).x )-7 && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > elv_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {



                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  elv_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        eleven_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }


        if ( eleven_bestPassPoint.x != -52 )
        {
            eleven_bestPassPoint_isFound = true;
        }

        flag = false;
        // 5) for priority No.2 : 11.11
        for (double j = 29.5 ; j > 22 && !(eleven_bestPassPoint_isFound)  ; j -= 3.0 )
        {
            for (double i = 4+1.333 ; i < 12 && !(eleven_bestPassPoint_isFound)  ; i += 1.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , elv_thp_rec_pos , rcsc::Vector2D(j,i) );

                if ( (j > getLocalOffsideLine(11,agent).x )-7 && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > elv_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {

                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  elv_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        eleven_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( eleven_bestPassPoint.x != -52 )
        {
            eleven_bestPassPoint_isFound = true;
        }


        flag = false;
        // 6) for priority No.4
        for (double j = 20.5 ; j > 4 && !(eleven_bestPassPoint_isFound)  ; j -= 3.0 )
        {
            for (double i = 12-1.333 ; i > -12 && !(eleven_bestPassPoint_isFound)  ; i -= 1.333 )
            {

                if (flag)
                    continue;

                first_Ball_Speed = getBallSpeed( agent , elv_thp_rec_pos , rcsc::Vector2D(j,i) );

                if (  (j > getLocalOffsideLine(11,agent).x )-7 && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ( j > elv_thp_rec_pos.x + 4) &&  (wm.self().pos().dist(rcsc::Vector2D(j,i)) <= 45) )
                {


                    const rcsc::PlayerObject * nearest_opp;

                    if ( wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp) != NULL )
                    {
                        nearest_opp = wm.getOpponentNearestTo(rcsc::Vector2D(j,i),15,distFromThpPointToNearestOpp);
                    }
                    else
                        continue;

                    if ( !nearest_opp->pos().isValid() )
                    {
                        continue;
                    }

                    distDifference =  (   (  nearest_opp->pos().dist(rcsc::Vector2D(j,i)) )  -  (  elv_thp_rec_pos.dist(rcsc::Vector2D(j,i))  ) ) ;

                    if (       distDifference < -1.5    )
                    {
                        continue;
                    }
                    else if (    max_distDifference < distDifference    )
                    {
                        max_distDifference = distDifference;
                        eleven_bestPassPoint = rcsc::Vector2D(j,i);
                    }

                    if (distDifference >= 2)
                        flag=true;

                }

            }
        }

        if ( eleven_bestPassPoint.x != -52 )
        {
            eleven_bestPassPoint_isFound = true;
        }


    }
#endif


    rcsc::Vector2D bestPassPoint(-52,-32);
    int chosenPlayerUnum=-1;
    rcsc::Vector2D chosenRecieverPos(0,0);
    double nine_bestPassPointDistToGoal = (nine_bestPassPoint - rcsc::Vector2D(52.0,0.0)).length();
    double ten_bestPassPointDistToGoal = (ten_bestPassPoint - rcsc::Vector2D(52.0,0.0)).length();
    double eleven_bestPassPointDistToGoal = (eleven_bestPassPoint - rcsc::Vector2D(52.0,0.0)).length();



    double minDistToGoal = 1000;




    if (  nine_bestPassPointDistToGoal  <= minDistToGoal && nine_bestPassPoint_isFound   )
    {
        minDistToGoal = nine_bestPassPointDistToGoal;
        bestPassPoint = nine_bestPassPoint;
        chosenPlayerUnum = 9;
        chosenRecieverPos = nine_thp_rec_pos;
    }

    if (  ten_bestPassPointDistToGoal  <= minDistToGoal && ten_bestPassPoint_isFound  )
    {
        minDistToGoal = ten_bestPassPointDistToGoal;
        bestPassPoint = ten_bestPassPoint;
        chosenPlayerUnum = 10;
        chosenRecieverPos = ten_thp_rec_pos;
    }

    if (  eleven_bestPassPointDistToGoal  <= minDistToGoal+10  && eleven_bestPassPoint_isFound )
    {
        minDistToGoal = eleven_bestPassPointDistToGoal;
        bestPassPoint = eleven_bestPassPoint;
        chosenPlayerUnum = 11;
        chosenRecieverPos = elv_thp_rec_pos;
    }

    
    if ( nine_bestPassPoint_isFound || ten_bestPassPoint_isFound || eleven_bestPassPoint_isFound )
    {
        double speed = getBallSpeed(agent,chosenRecieverPos,bestPassPoint) ;

        if (rcsc::Body_SmartKick(bestPassPoint,speed,speed*0.96,3).execute(agent))
        {


            if ( agent->config().useCommunication() && chosenPlayerUnum != Unum_Unknown )
            {
                rcsc::Vector2D target_buf = bestPassPoint - agent->world().self().pos();
                target_buf.setLength( 1.0 );

                agent->addSayMessage( new PassMessage( chosenPlayerUnum, bestPassPoint + target_buf, agent->effector().queuedNextBallPos(), agent->effector().queuedNextBallVel() ) );
            }

            return true;


        }



    }


    return false;


}




// int ThroughPass::passSafety(rcsc::PlayerAgent* agent, rcsc::Vector2D startPoint, rcsc::Vector2D endPoint, double ballSpeed)
// {
//     return 2;
// }



rcsc::Vector2D ThroughPass::getLocalOffsideLine(int area_number, rcsc::PlayerAgent * agent)
{
    const rcsc::WorldModel & wm = agent->world();

    rcsc::Vector2D LocalOffsideLine(4,0);

    if (area_number == 9)
    {

        const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
        for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                opp != opp_end;
                ++ opp )
        {
            if ( ((*opp)->pos().y < -7) && (*opp)->pos().x > LocalOffsideLine.x )
            {
                LocalOffsideLine = (*opp)->pos();
            }
        }

    }

    else if (area_number == 10)
    {

        const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
        for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                opp != opp_end;
                ++ opp )
        {
            if ( ((*opp)->pos().y > 7) && (*opp)->pos().x > LocalOffsideLine.x )
            {
                LocalOffsideLine = (*opp)->pos();
            }
        }

    }
    else if (area_number == 11)
    {
        const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();
        for ( rcsc::PlayerPtrCont::const_iterator opp = wm.opponentsFromSelf().begin();
                opp != opp_end;
                ++ opp )
        {
            if ( (fabs((*opp)->pos().y) < 17)  && (*opp)->pos().x > LocalOffsideLine.x )
            {
                LocalOffsideLine = (*opp)->pos();
            }
        }
    }
    else
      return LocalOffsideLine;




    return LocalOffsideLine;

}



//Tarigheye Seda Zadan ! ::: && !(canOppIntercept(agent , wm.self().pos() , rcsc::Vector2D(j,i) , first_Ball_Speed )) && ...

bool ThroughPass::canOppIntercept( rcsc::PlayerAgent * agent , rcsc::Vector2D startPoint, rcsc::Vector2D endPoint, double ballSpeed)
{

    const rcsc::WorldModel & wm = agent->world();

    rcsc::Segment2D thpSegment ( startPoint , endPoint);
    if (thpSegment.length() < 7)
        return true;

    rcsc::Sector2D safetySector  (wm.ball().pos(),3.0,thpSegment.length()+2.0,thpSegment.direction()-13.0,thpSegment.direction()+13.0);
    rcsc::Sector2D safetySector2 (wm.ball().pos(),0.0,thpSegment.length()+2.0,thpSegment.direction()-21.0,thpSegment.direction()+21.0);

    rcsc::Circle2D safetyCircle (wm.ball().pos() , 7);
    rcsc::Circle2D safetyCircle2 (wm.ball().pos() , 8);
    rcsc::Circle2D ignoreCircle (wm.ball().pos() , 9.5);
    rcsc::Circle2D CompletelyIgnoreCircle (wm.ball().pos() , 4.5);

    rcsc::Sector2D safetySector3  (wm.ball().pos(),3.0,thpSegment.length()+1.0,thpSegment.direction()-7.0,thpSegment.direction()+7.0);
    rcsc::Sector2D safetySector_big  (wm.ball().pos(),0.0,thpSegment.length()+1.0,thpSegment.direction()-23.0,thpSegment.direction()+23.0);

    const rcsc::PlayerPtrCont::const_iterator opp_end = wm.opponentsFromSelf().end();


    for ( rcsc::PlayerPtrCont::const_iterator opponent = wm.opponentsFromSelf().begin();
            opponent != opp_end;
            ++ opponent )
    {
        rcsc::Segment2D opponentBodyDirectionSegment(  (*opponent)->pos() , 30.0 , (*opponent)->body()  );
        rcsc::Segment2D opponentVel_DirectionSegment(  (*opponent)->pos() , 15.0 , (*opponent)->vel().th()  );

        rcsc::Vector2D inertiaOppPos (0.0,0.0);
        if ( (*opponent)->posCount() <= 2  )
        {
            inertiaOppPos = (*opponent)->pos();
	    
	 if (thpSegment.dist((*opponent)->inertiaPoint(1)) - thpSegment.dist((*opponent)->pos()) < -0.4 && thpSegment.dist((*opponent)->pos()) < 5)   
	    inertiaOppPos = (*opponent)->inertiaPoint(1);
	    
	    
        }
        else
        {
            inertiaOppPos = (*opponent)->inertiaPoint( (*opponent)->posCount()  )  ;
        }

	if ( (thpSegment.dist((*opponent)->inertiaPoint(1)) - thpSegment.dist((*opponent)->pos()) > 0.4 && thpSegment.dist((*opponent)->pos()) > 2 ) && (safetyCircle2.contains(inertiaOppPos)) &&  (*opponent)->posCount() <= 1 )
	  continue;

        if (  !(  ( CompletelyIgnoreCircle.contains( inertiaOppPos ) ) &&    ( !( thpSegment.intersection(opponentBodyDirectionSegment,true).isValid() ) ||  !( thpSegment.intersection(opponentVel_DirectionSegment,true).isValid() ) )      &&      (*opponent)->posCount() <= 2     )  &&  (  ( safetySector.contains( inertiaOppPos ) ) || ( safetySector.contains( inertiaOppPos ) ) || ( ( safetySector2.contains( inertiaOppPos) )   &&  !(safetyCircle2.contains(inertiaOppPos)) ) )        )
        {

            return true;
        }

        if ( !(  ( CompletelyIgnoreCircle.contains( inertiaOppPos ) ) &&    ( !( thpSegment.intersection(opponentBodyDirectionSegment,true).isValid() ) ||  !( thpSegment.intersection(opponentVel_DirectionSegment,true).isValid() ) )      &&      (*opponent)->posCount() <= 2     ) && (    ( (*opponent)->posCount() > 2 && ( safetySector_big.contains( inertiaOppPos ) )  )   || ( ((*opponent)->posCount() < 3) && ( thpSegment.intersection(opponentVel_DirectionSegment,true).isValid() ) && ( (*opponent)->vel().length() > (rcsc::ServerParam::i().DEFAULT_PLAYER_SPEED_MAX)*0.20) && ( ( safetySector.contains( (*opponent)->inertiaPoint( 2 ) ) ) ) && !(safetyCircle2.contains(inertiaOppPos))   )  ))
        {
            return true;
        }

        if (   !(  ( CompletelyIgnoreCircle.contains( inertiaOppPos ) ) &&    ( !( thpSegment.intersection(opponentBodyDirectionSegment,true).isValid() ) ||  !( thpSegment.intersection(opponentVel_DirectionSegment,true).isValid() ) )      &&      (*opponent)->posCount() <= 2     ) && (   (*opponent)->distFromBall() > 14   &&     ( thpSegment.intersection(opponentVel_DirectionSegment,true).isValid() )  &&    ( thpSegment.intersection(opponentBodyDirectionSegment,true).isValid() )  &&   ( (*opponent)->posCount() < 3 && ( safetySector_big.contains( (*opponent)->inertiaPoint((*opponent)->posCount()) ) )  )  ) )
        {
            return true;
        }

    }

    return false;

}




double ThroughPass::getBallSpeed(rcsc::PlayerAgent* agent, rcsc::Vector2D recieverPos, rcsc::Vector2D passPoint)
{

    int recieverReachCycle = 100;
    const rcsc::WorldModel & wm = agent->world();
    const double max_kick_speed = rcsc::ServerParam::i().ballSpeedMax();

    recieverReachCycle = ceil( ( ( (passPoint - recieverPos).r() ) / ( (rcsc::ServerParam::i().DEFAULT_PLAYER_SPEED_MAX)* 0.78 ) )+1.3) ;

    for ( double ballSpeed = max_kick_speed ; ballSpeed > 0 ; ballSpeed -= 0.05)
    {
        if ( getBallReachCycle( wm.self().pos() , passPoint , ballSpeed) >=  recieverReachCycle )
        {
            if ( ( ballSpeed* pow(rcsc::ServerParam::i().ballDecay() , getBallReachCycle( wm.self().pos() , passPoint , ballSpeed)) ) <= 1.0 )
            {
                return ballSpeed;
            }
        }
    }
    return 0;
}




int ThroughPass::getBallReachCycle(rcsc::Vector2D startPoint, rcsc::Vector2D endPoint, double ballFirstSpeed)
{
    double deltaX= (startPoint - endPoint).r();
    double traveledDist = 0;
    for ( int BallReachCycle = 0 ; BallReachCycle < 100 ; BallReachCycle++ )
    {
        traveledDist += ballFirstSpeed* pow(rcsc::ServerParam::i().ballDecay(),BallReachCycle);
        if (traveledDist >= deltaX )
        {
            return BallReachCycle;
        }
    }

    return 1000;
}



