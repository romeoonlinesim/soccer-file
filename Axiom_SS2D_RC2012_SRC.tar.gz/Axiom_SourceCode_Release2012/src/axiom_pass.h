/**
 * bhv_axim_pass.h
 * 
 * Iran University of Science and Technology (IUST)- Tehran 
 * Authors : Mohammad Ghazanfari, Alireza Beydaghi, Mahta Ghandehari, Hossein Rahmatizadeh
 * Copyright 2011
 * Allright Reserved
 */

#ifndef AXIMPASS_H_
#define AXIMPASS_H_

#include <cmath>

#include <rcsc/player/player_agent.h>
#include <rcsc/geom/vector_2d.h>
#include <rcsc/geom/angle_deg.h>
#include <rcsc/geom/line_2d.h>
#include <rcsc/geom/sector_2d.h>
#include <rcsc/geom/polygon_2d.h>

#include <vector>
//#include <PercepNetwork.h>

using namespace std;
using namespace rcsc;

// class PlayerAgent;
// class Line2D;
// class Vector2D;
// class AngleDeg;
// class PlayerObject;
// class sector_2d;


#define AREA_1 1
#define AREA_2 2
#define AREA_3 3
#define AREA_4 4
#define AREA_5 5
#define AREA_6 6
#define AREA_7 7
#define AREA_ILLEGAL 0

/*
struct AIResult
{
	vector<vector<vector<double> > > weights;
	vector<vector<double> > biases;
	vector<transferType> types;
	vector<double> inputsMinMax;
	vector<double> outputsMinMax;
};*/






class Axiom_Pass {
  public:
    

    bool execute( rcsc::PlayerAgent * agent , bool pass_mode = true );
    bool canLeadPass2(rcsc::PlayerAgent * agent , rcsc::PlayerObject * rec , bool passMode);
    bool canLeadPass1(rcsc::PlayerAgent * agent , rcsc::PlayerObject * rec , bool passMode);
    bool canDirectPass(rcsc::PlayerAgent * agent ,  rcsc::PlayerObject * rec , bool passMode);
    
    rcsc::Vector2D calculateTargetForNeck(rcsc::PlayerAgent* agent , bool pass_mode ); // for neck
    rcsc::Vector2D canLeadPass1Point(rcsc::PlayerAgent* agent, rcsc::PlayerObject* rec , bool passMode); // for neck
    rcsc::Vector2D canDirectPassPoint (rcsc::PlayerAgent * agent ,  rcsc::PlayerObject * rec , bool passMode); // for neck
    
    int getArea(Vector2D point);
    
    double 	getSaftyScore( rcsc::PlayerAgent * agent,const rcsc::Vector2D reciever_point, rcsc::PlayerObject * reciever);
    double 	getSituationScore(rcsc::PlayerAgent * agent , const rcsc::Vector2D reciever_point , const rcsc::AngleDeg bodyAngle);
    double 	calculateRateForSafty(  const rcsc::WorldModel & wm, std::vector<rcsc::PlayerObject *> obj ,  
					const rcsc::Vector2D  tmm_pos, rcsc::Polygon2D rect, rcsc::PlayerObject *rec) ;  
    int 	getReachCycle( rcsc::PlayerObject * obj, const rcsc::WorldModel & wm, double dist, int mode_number);
    double 	getBallSpeed( double pass_dist ,double end_speed );
    double 	getBallSpeed_one_step( double pass_dist ,double end_speed );
    double 	getDensityRate ( const rcsc::WorldModel & wm , rcsc::Vector2D reciever_point , const rcsc::AngleDeg bodyAngle);
    AngleDeg 	angleFromPassLine(PlayerObject opp,Line2D passLine);
    rcsc::Polygon2D
		makePolygon( rcsc::PlayerAgent * agent, rcsc::Vector2D reciever /*const rcsc::PlayerObject * rec*/ , double rad );

    rcsc::Polygon2D
		makePolygonRect( rcsc::PlayerAgent * agent, rcsc::Vector2D reciever /*const rcsc::PlayerObject * rec */ , double rad );


    int 	countOppSimulatedIn( const rcsc::WorldModel & wm /*rcsc::PlayerAgent *agent*/, rcsc::Polygon2D poly );

private :
  
  // hossein ali
  
//  PercepNetwork *pnet;
  
  //
   // int getArea ( rcsc::Vector2D input ) ;
    double getAreaRate ( rcsc::Vector2D agent, rcsc::Vector2D target ) ;
    double getDensityRate ( );
    
  private:
    PlayerAgent *sender;
    PlayerAgent *reciever;

    rcsc::Vector2D targetPoint;
    double speed;
    
    struct directPassStr {
      directPassStr() {}
      rcsc::PlayerObject * reciever;
      double SituationScore;
      int rec_no;
      bool operator () (const directPassStr lhs , const directPassStr rhs) const
      {
	return lhs.SituationScore > rhs.SituationScore;
      }
    };
    
        struct StrCompare {
        const directPassStr _sitScore;

    private:
        StrCompare();
    public:

        StrCompare( const directPassStr & sitScore )
            : _sitScore( sitScore )
          { }

        bool operator()( const directPassStr & lhs,
                         const directPassStr & rhs ) const
          {
              return lhs.SituationScore < rhs.SituationScore ;
          }

    };

    
    
   
};

#endif