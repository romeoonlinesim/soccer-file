/**
 * axiom_view.h
 *
 * Iran University of Science and Technology (IUST)- Tehran
 * Author : Omid Shirkhorshidi
 * Copyright 2012
 * Allright Reserved
 */

#ifndef VIEW_H
#define VIEW_H

#include <cmath>
#include <rcsc/player/player_agent.h>
#include <rcsc/geom/vector_2d.h>
#include <rcsc/geom/rect_2d.h>
#include <rcsc/geom/ray_2d.h>
#include <rcsc/geom/angle_deg.h>
#include <rcsc/geom/line_2d.h>
#include <rcsc/geom/sector_2d.h>
#include <rcsc/geom/polygon_2d.h>

using namespace std;
using namespace rcsc;


class axiom_view
{
public:
  axiom_view ()
  {}
  bool default_execute(rcsc::PlayerAgent* agent);
  bool thp_execute(rcsc::PlayerAgent* agent);
  bool pass_execute(rcsc::PlayerAgent* agent);
  bool block_execute(rcsc::PlayerAgent* agent);
  bool goalieBackPass_execute(rcsc::PlayerAgent* agent);
  bool intercept_execute(rcsc::PlayerAgent* agent);
  bool indirectMode_execute(rcsc::PlayerAgent* agent);
  bool one2one_execute(rcsc::PlayerAgent* agent);
  bool setPlay_execute(rcsc::PlayerAgent* agent);
  bool one2one_checker(rcsc::PlayerAgent* agent);
  
private:
  
};

#endif
